import React, { useState, useRef } from 'react';
import { X } from 'lucide-react';
import { MarketingNavbar, MarketingTab } from './components/marketing/MarketingNavbar';
import { MarketingFooter } from './components/marketing/MarketingFooter';
import { AboutUsView } from './components/marketing/AboutUsView';
import { ServicesView } from './components/marketing/ServicesView';
import { PortfolioView } from './components/marketing/PortfolioView';
import { BlogsView } from './components/marketing/BlogsView';
import { StyleGuideView } from './components/marketing/StyleGuideView';
import { CeoView } from './components/marketing/CeoView';
import { TeamView } from './components/marketing/TeamView';
import { AgentsView } from './components/marketing/AgentsView';
import { ChatbotWidget } from './components/marketing/ChatbotWidget';
import { PromptHeader } from './components/PromptHeader';
import { PromptBox } from './components/PromptBox';
import { WorkspaceColumns } from './components/WorkspaceColumns';
import { LivePreviewContainer } from './components/LivePreviewContainer';
import { StrategySection } from './components/StrategySection';
import { ProjectsView } from './components/ProjectsView';
import { VisualCanvasStudio } from './components/VisualCanvasStudio';
import { FileViewerModal } from './components/FileViewerModal';
import { AppCategory, AppFile, AgentActivityStep, PipelineStep, GeneratedApp, BuildMode, BuildType, ProductionReadinessReport } from './types/promptBuilder';
import { APP_PRESETS, generateProductionReadinessReport } from './data/appPresets';
import { WorkspaceSettingsModal, WorkspaceTab } from './components/pricing/WorkspaceSettingsModal';
import { PricingView } from './components/pricing/PricingView';
import { OthersView } from './components/marketing/OthersView';
import { ConceptShowcaseBar } from './components/marketing/ConceptShowcaseBar';
import { DYNAMIC_CONCEPTS, DynamicConcept } from './data/dynamicConcepts';
import { ProductionReadinessPanel } from './components/readiness/ProductionReadinessPanel';
import { EvolveModal } from './components/evolve/EvolveModal';
import { GrowthCommandCenterModal } from './components/growth/GrowthCommandCenterModal';
import { ScoutModal } from './components/scout/ScoutModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<MarketingTab>('home');
  const [activeMode, setActiveMode] = useState<'scratch' | 'transform'>('scratch');
  const [selectedCategory, setSelectedCategory] = useState<AppCategory>('Trading Platform');
  const [prompt, setPrompt] = useState('Build a trading platform with live dashboards and user accounts');
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'phone'>('desktop');
  const [selectedFile, setSelectedFile] = useState<AppFile | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);

  // APPMORA Build Configuration States
  const [buildMode, setBuildMode] = useState<BuildMode>('production');
  const [buildType, setBuildType] = useState<BuildType>('Web');

  // APPMORA Engine Modals
  const [isReadinessModalOpen, setIsReadinessModalOpen] = useState(false);
  const [isEvolveModalOpen, setIsEvolveModalOpen] = useState(false);
  const [isGrowthModalOpen, setIsGrowthModalOpen] = useState(false);
  const [isScoutModalOpen, setIsScoutModalOpen] = useState(false);
  const [isFixingReadiness, setIsFixingReadiness] = useState(false);

  // Workspace Modal & Pricing States
  const [isWorkspaceModalOpen, setIsWorkspaceModalOpen] = useState(false);
  const [workspaceTab, setWorkspaceTab] = useState<WorkspaceTab>('pricing');

  // Auto-Changing Concept Engine States
  const [currentConceptIndex, setCurrentConceptIndex] = useState(0);
  const [isAutoChanging, setIsAutoChanging] = useState(true);
  const currentConcept = DYNAMIC_CONCEPTS[currentConceptIndex];

  // Stored projects
  const [projects, setProjects] = useState<GeneratedApp[]>([
    APP_PRESETS.trading,
    APP_PRESETS.ai,
    APP_PRESETS.saas,
    APP_PRESETS.social,
    APP_PRESETS.delivery,
  ]);

  // Current active app in live sandbox
  const [currentApp, setCurrentApp] = useState<GeneratedApp>(APP_PRESETS.trading);

  // Production Readiness Report state
  const [readinessReport, setReadinessReport] = useState<ProductionReadinessReport>(() => 
    generateProductionReadinessReport(APP_PRESETS.trading.title, true, APP_PRESETS.trading.category)
  );

  // Agent activity logs
  const [agentSteps, setAgentSteps] = useState<AgentActivityStep[]>([
    { id: '1', title: 'Simeon Jr Studios Core Engine initialized', timestamp: '12:00:00', status: 'completed' },
    { id: '2', title: 'Autonomous Multi-Agent Fleet connected', timestamp: '12:00:01', status: 'completed' },
    { id: '3', title: 'Universal TypeScript AST compiler active', timestamp: '12:00:02', status: 'completed' },
    { id: '4', title: 'Interactive sandbox live at 127.0.0.1:8787/preview', timestamp: '12:00:03', status: 'completed' },
  ]);

  // Factory CI/CD Pipeline
  const [pipelineSteps, setPipelineSteps] = useState<PipelineStep[]>([
    { id: 'plan', stepNum: '01', name: 'PLAN', desc: 'Requirements & architecture', status: 'done' },
    { id: 'build', stepNum: '02', name: 'BUILD', desc: 'Generate application', status: 'done' },
    { id: 'test', stepNum: '03', name: 'TEST', desc: 'Validate the project', status: 'done' },
    { id: 'fix', stepNum: '04', name: 'FIX', desc: 'Zero errors detected', status: 'done' },
    { id: 'preview', stepNum: '05', name: 'PREVIEW', desc: 'Live runtime active', status: 'done' },
  ]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const previewRef = useRef<HTMLDivElement>(null);

  // Handle prompt submission & build
  const handleBuildApp = (customPrompt?: string) => {
    const targetPrompt = customPrompt || prompt;
    if (!targetPrompt.trim() || isGenerating) return;

    if (customPrompt) {
      setPrompt(customPrompt);
    }

    setIsGenerating(true);
    setActiveTab('home');

    // Reset pipeline steps
    setPipelineSteps([
      { id: 'plan', stepNum: '01', name: 'PLAN', desc: 'Analyzing architecture...', status: 'running' },
      { id: 'build', stepNum: '02', name: 'BUILD', desc: 'Pending generation', status: 'idle' },
      { id: 'test', stepNum: '03', name: 'TEST', desc: 'Pending validation', status: 'idle' },
      { id: 'fix', stepNum: '04', name: 'FIX', desc: 'Pending linter', status: 'idle' },
      { id: 'preview', stepNum: '05', name: 'PREVIEW', desc: 'Pending deploy', status: 'idle' },
    ]);

    setAgentSteps([
      { id: '1', title: `Agent Alpha: Analyzing prompt "${targetPrompt.slice(0, 30)}..."`, timestamp: 'Just now', status: 'active' },
    ]);

    // Simulated multi-stage prompt generation pipeline by Simeon Jr Studios Agents
    setTimeout(() => {
      setAgentSteps((prev) => [
        { id: '1', title: 'Agent Alpha: Architecture planned & AST structured', timestamp: 'Step 1', status: 'completed' },
        { id: '2', title: 'Agent Beta: Synthesizing reactive components & state', timestamp: 'Step 2', status: 'active' },
      ]);
      setPipelineSteps((prev) =>
        prev.map((s) =>
          s.id === 'plan'
            ? { ...s, status: 'done' }
            : s.id === 'build'
            ? { ...s, status: 'running', desc: 'Synthesizing TSX & Tailwind...' }
            : s
        )
      );
    }, 700);

    setTimeout(() => {
      setAgentSteps((prev) => [
        ...prev.slice(0, 2).map((s) => ({ ...s, status: 'completed' as const })),
        { id: '3', title: 'Agent Gamma & Delta: TypeScript verify & security audit', timestamp: 'Step 3', status: 'active' },
      ]);
      setPipelineSteps((prev) =>
        prev.map((s) =>
          s.id === 'build'
            ? { ...s, status: 'done' }
            : s.id === 'test'
            ? { ...s, status: 'running', desc: 'Verifying compiler...' }
            : s
        )
      );
    }, 1400);

    setTimeout(() => {
      const promptLower = targetPrompt.toLowerCase();
      let matchedApp: GeneratedApp;

      if (
        promptLower.includes('trading') ||
        promptLower.includes('crypto') ||
        promptLower.includes('stock') ||
        promptLower.includes('exchange')
      ) {
        matchedApp = {
          ...APP_PRESETS.trading,
          prompt: targetPrompt,
          id: `app-trade-${Date.now()}`,
          createdAt: Date.now(),
        };
      } else if (
        promptLower.includes('chat') ||
        promptLower.includes('ai') ||
        promptLower.includes('assistant') ||
        promptLower.includes('gpt') ||
        promptLower.includes('gemini')
      ) {
        matchedApp = {
          ...APP_PRESETS.ai,
          prompt: targetPrompt,
          id: `app-ai-${Date.now()}`,
          createdAt: Date.now(),
        };
      } else if (
        promptLower.includes('saas') ||
        promptLower.includes('crm') ||
        promptLower.includes('billing') ||
        promptLower.includes('dashboard')
      ) {
        matchedApp = {
          ...APP_PRESETS.saas,
          prompt: targetPrompt,
          id: `app-saas-${Date.now()}`,
          createdAt: Date.now(),
        };
      } else if (
        promptLower.includes('social') ||
        promptLower.includes('community') ||
        promptLower.includes('feed') ||
        promptLower.includes('posts')
      ) {
        matchedApp = {
          ...APP_PRESETS.social,
          prompt: targetPrompt,
          id: `app-social-${Date.now()}`,
          createdAt: Date.now(),
        };
      } else if (
        promptLower.includes('delivery') ||
        promptLower.includes('food') ||
        promptLower.includes('courier') ||
        promptLower.includes('restaurant')
      ) {
        matchedApp = {
          ...APP_PRESETS.delivery,
          prompt: targetPrompt,
          id: `app-delivery-${Date.now()}`,
          createdAt: Date.now(),
        };
      } else {
        matchedApp = {
          id: `custom-app-${Date.now()}`,
          title: targetPrompt.length > 35 ? `${targetPrompt.slice(0, 32)}... App` : targetPrompt,
          type: selectedCategory,
          category: selectedCategory,
          prompt: targetPrompt,
          description: `Universal production software generated dynamically from prompt: "${targetPrompt}"`,
          previewUrl: `http://127.0.0.1:8787/preview/custom-${Date.now()}`,
          createdAt: Date.now(),
          files: [
            {
              name: 'App.tsx',
              path: 'src/App.tsx',
              language: 'typescript',
              size: '4.2 KB',
              content: `import React, { useState } from 'react';\n// Universal application generated from prompt: ${targetPrompt}\nexport default function App() {\n  return (\n    <div className="min-h-screen bg-slate-900 text-white p-8">\n      <h1 className="text-2xl font-bold">${targetPrompt}</h1>\n      <p className="text-slate-400 mt-2">Synthesized cleanly by APPMORA - Simeon Intelligence Software Factory</p>\n    </div>\n  );\n}`,
            },
            {
              name: 'schema.ts',
              path: 'src/data/schema.ts',
              language: 'typescript',
              size: '2.1 KB',
              content: `export interface AppRecord {\n  id: string;\n  title: string;\n  timestamp: number;\n}`,
            },
            {
              name: 'package.json',
              path: 'package.json',
              language: 'json',
              size: '680 B',
              content: `{\n  "name": "universal-app",\n  "version": "1.0.0"\n}`,
            },
          ],
        };
      }

      // Attach current build config
      matchedApp = {
        ...matchedApp,
        buildMode,
        buildType,
      };

      setCurrentApp(matchedApp);
      setProjects((prev) => [matchedApp, ...prev.filter((p) => p.id !== matchedApp.id)]);

      // Generate accurate 18-point Production Readiness Report
      const newReport = generateProductionReadinessReport(
        matchedApp.title,
        buildMode === 'production',
        matchedApp.category
      );
      setReadinessReport(newReport);

      setAgentSteps([
        { id: '1', title: 'Agent Alpha: Spec & schema verified', timestamp: 'Step 1', status: 'completed' },
        { id: '2', title: 'Agent Beta: Synthesized reactive components', timestamp: 'Step 2', status: 'completed' },
        { id: '3', title: 'Agent Gamma: Compiler pass (0 warnings)', timestamp: 'Step 3', status: 'completed' },
        { id: '4', title: 'Agent Epsilon: Universal sandbox live', timestamp: 'Now', status: 'completed' },
      ]);

      setPipelineSteps([
        { id: 'plan', stepNum: '01', name: 'PLAN', desc: 'Requirements & architecture', status: 'done' },
        { id: 'build', stepNum: '02', name: 'BUILD', desc: 'Generate application', status: 'done' },
        { id: 'test', stepNum: '03', name: 'TEST', desc: 'Validate the project', status: 'done' },
        { id: 'fix', stepNum: '04', name: 'FIX', desc: 'Zero errors detected', status: 'done' },
        { id: 'preview', stepNum: '05', name: 'PREVIEW', desc: 'Live runtime active', status: 'done' },
      ]);

      setIsGenerating(false);
      showToast(`Generated & launched ${matchedApp.title}! (Readiness: ${newReport.score}/100)`);

      setTimeout(() => {
        previewRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }, 2200);
  };

  const handleLaunchProject = (projectToLaunch: GeneratedApp) => {
    setCurrentApp(projectToLaunch);
    setPrompt(projectToLaunch.prompt);
    setSelectedCategory(projectToLaunch.category);
    if (projectToLaunch.buildMode) setBuildMode(projectToLaunch.buildMode);
    if (projectToLaunch.buildType) setBuildType(projectToLaunch.buildType);
    
    // Update readiness report for loaded project
    const newReport = generateProductionReadinessReport(
      projectToLaunch.title,
      projectToLaunch.buildMode !== 'prototype',
      projectToLaunch.category
    );
    setReadinessReport(newReport);

    setActiveTab('home');
    showToast(`Loaded ${projectToLaunch.title} into sandbox (Readiness: ${newReport.score}/100)`);
    setTimeout(() => {
      previewRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 150);
  };

  const handleDeleteProject = (id: string) => {
    setProjects(projects.filter((p) => p.id !== id));
    showToast('Project removed');
  };

  const handleNewApp = () => {
    setActiveTab('home');
    setPrompt('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSendPromptFromBot = (promptText: string) => {
    setPrompt(promptText);
    setActiveTab('home');
    setIsChatbotOpen(false);
    handleBuildApp(promptText);
  };

  const handleFixAllIssues = () => {
    setIsFixingReadiness(true);
    setTimeout(() => {
      setReadinessReport((prev) => ({
        ...prev,
        score: 100,
        checks: prev.checks.map((c) => ({
          ...c,
          status: 'pass' as const,
          details: 'Verified & hardened with strict AST checks and zero compiler warnings.',
        })),
      }));
      setIsFixingReadiness(false);
      showToast('All 18 production readiness checks passed! Application is 100% production ready.');
    }, 1200);
  };

  const handleApplyEvolution = (recommendationIds: string[]) => {
    showToast(`Applying ${recommendationIds.length} autonomous performance & security upgrades...`);
    setTimeout(() => {
      setAgentSteps((prev) => [
        {
          id: String(Date.now()),
          title: `APPMORA Evolve: Applied ${recommendationIds.length} optimizations to AST`,
          timestamp: 'Just now',
          status: 'completed',
        },
        ...prev,
      ]);
      setReadinessReport((prev) => ({
        ...prev,
        score: 100,
        checks: prev.checks.map((c) => ({ ...c, status: 'pass' as const })),
      }));
      setIsEvolveModalOpen(false);
      showToast(`Successfully evolved ${currentApp.title}! Performance & security profile upgraded.`);
    }, 1200);
  };

  const handleRollback = (pointId: string) => {
    showToast(`Restored snapshot ${pointId}. AST rolled back safely.`);
  };

  const handleSelectScoutOpportunity = (scoutPrompt: string, scoutCategory: string) => {
    setIsScoutModalOpen(false);
    setPrompt(scoutPrompt);
    setSelectedCategory(scoutCategory as AppCategory);
    setActiveTab('home');
    handleBuildApp(scoutPrompt);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col antialiased selection:bg-indigo-600 selection:text-white relative overflow-x-hidden">
      {/* Auto-Changing Dynamic Concept Ambient Gradient Aura */}
      <div
        className={`pointer-events-none fixed inset-0 opacity-40 transition-all duration-1000 bg-gradient-to-b ${currentConcept.glowClass} -z-10`}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-950 text-white text-xs font-semibold px-5 py-2.5 rounded-full shadow-2xl flex items-center gap-2.5 border border-indigo-500/40 backdrop-blur-md animate-in fade-in slide-in-from-top-4 duration-200">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Marketing Top Navigation */}
      <MarketingNavbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenChatbot={() => setIsChatbotOpen(true)}
        onStartBuild={handleNewApp}
        onOpenWorkspaceModal={(tab) => {
          setWorkspaceTab((tab as WorkspaceTab) || 'pricing');
          setIsWorkspaceModalOpen(true);
        }}
      />

      {/* Page Content Container */}
      <main className="flex-1 flex flex-col">
        {/* VIEW 1: HOME (Hero + Prompt Engine + Sandbox + Columns + Pipeline + Strategy) */}
        {activeTab === 'home' && (
          <div className="p-4 sm:p-8 space-y-10 max-w-7xl mx-auto w-full">
            {/* Auto-Changing Frontend Concepts Showcase Bar */}
            <ConceptShowcaseBar
              currentConcept={currentConcept}
              onSelectConcept={(c) => {
                const idx = DYNAMIC_CONCEPTS.findIndex((item) => item.id === c.id);
                if (idx !== -1) setCurrentConceptIndex(idx);
              }}
              isAutoChanging={isAutoChanging}
              onToggleAutoChanging={() => setIsAutoChanging(!isAutoChanging)}
            />

            {/* Top Bar and Hero */}
            <PromptHeader
              activeMode={activeMode}
              onSelectMode={setActiveMode}
              onQuickCategoryClick={(cat) => {
                setSelectedCategory(cat as AppCategory);
                if (cat === 'Trading Platform') {
                  setPrompt('Build a trading platform with live dashboards and user accounts');
                } else if (cat === 'AI Chat App') {
                  setPrompt('Create a multi-app AI platform like ChatGPT and Gemini in one app');
                } else if (cat === 'Multi-App Suite') {
                  setPrompt('Build an enterprise multi-app suite with analytics and customer CRM');
                }
              }}
            />

            {/* Prompt Box with Categories & Suggestions */}
            <PromptBox
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                if (cat === 'Trading Platform') {
                  setPrompt('Build a trading platform with live dashboards and user accounts');
                } else if (cat === 'AI Chat App') {
                  setPrompt('Create a multi-app AI platform like ChatGPT and Gemini in one app');
                } else if (cat === 'SaaS Dashboard') {
                  setPrompt('Create a SaaS business app with dashboard, CRM, and billing');
                } else if (cat === 'Social Platform') {
                  setPrompt('Build a social network with chat, profiles, and communities');
                } else if (cat === 'Mobile App' || cat === 'APK / Android App') {
                  setPrompt('Build a mobile app and web app for a delivery service');
                }
              }}
              prompt={prompt}
              onChangePrompt={setPrompt}
              onBuild={() => handleBuildApp()}
              isGenerating={isGenerating}
              buildMode={buildMode}
              onSelectBuildMode={setBuildMode}
              buildType={buildType}
              onSelectBuildType={setBuildType}
            />

            {/* 3 Columns: Agent Activity, Project Files, Builder Tools */}
            <WorkspaceColumns
              agentSteps={agentSteps}
              isGenerating={isGenerating}
              files={currentApp.files}
              activeFile={selectedFile}
              onSelectFile={setSelectedFile}
              onRefreshPreview={() => showToast('Refreshed live sandbox instance')}
              onStartAnother={handleNewApp}
              previewDevice={previewDevice}
            />

            {/* Live Preview Container (Real Interactive Applications) */}
            <div ref={previewRef}>
              <LivePreviewContainer
                appType={currentApp.type}
                appTitle={currentApp.title}
                prompt={currentApp.prompt}
                isGenerating={isGenerating}
                pipelineSteps={pipelineSteps}
                device={previewDevice}
                onSelectDevice={setPreviewDevice}
                onRefresh={() => showToast('Recompiled live preview sandbox')}
                buildMode={buildMode}
                buildType={buildType}
                readinessScore={readinessReport.score}
                onOpenReadiness={() => setIsReadinessModalOpen(true)}
                onOpenEvolve={() => setIsEvolveModalOpen(true)}
                onOpenGrowth={() => setIsGrowthModalOpen(true)}
              />
            </div>

            {/* Strategy & Commercial Models Section */}
            <StrategySection onGetStarted={handleNewApp} />
          </div>
        )}

        {/* VIEW 2: ABOUT US */}
        {activeTab === 'about' && (
          <AboutUsView
            onStartBuilding={handleNewApp}
            onExploreAgents={() => setActiveTab('agents')}
          />
        )}

        {/* VIEW 3: SERVICES */}
        {activeTab === 'services' && (
          <ServicesView
            onStartBuilding={handleNewApp}
            onOpenChatbot={() => setIsChatbotOpen(true)}
          />
        )}

        {/* VIEW 4: PORTFOLIO */}
        {activeTab === 'portfolio' && (
          <PortfolioView
            onLaunchInSandbox={handleLaunchProject}
            onInspectCode={(file) => setSelectedFile(file)}
          />
        )}

        {/* VIEW 5: PROJECTS (User Repo) */}
        {activeTab === 'projects' && (
          <div className="p-6 sm:p-10 max-w-7xl mx-auto w-full">
            <ProjectsView
              projects={projects}
              onLaunchProject={handleLaunchProject}
              onDeleteProject={handleDeleteProject}
              onNewApp={handleNewApp}
            />
          </div>
        )}

        {/* VIEW: PRICING (Universal App Production Plans) */}
        {activeTab === 'pricing' && (
          <PricingView
            onOpenWorkspaceModal={(tab) => {
              setWorkspaceTab((tab as WorkspaceTab) || 'pricing');
              setIsWorkspaceModalOpen(true);
            }}
            onSelectPlan={(plan, credits) => {
              showToast(`Selected ${plan} (${credits.toLocaleString()} tokens/mo)`);
              setWorkspaceTab('pricing');
              setIsWorkspaceModalOpen(true);
            }}
          />
        )}

        {/* VIEW: OTHERS (Settings, Integrations, Secrets, Compute & Multi-Cloud) */}
        {activeTab === 'others' && (
          <OthersView
            onOpenWorkspaceTab={(tab) => {
              setWorkspaceTab(tab);
              setIsWorkspaceModalOpen(true);
            }}
          />
        )}

        {/* VIEW 6: BLOGS */}
        {activeTab === 'blogs' && <BlogsView />}

        {/* VIEW 7: STYLE (Design System) */}
        {activeTab === 'style' && (
          <StyleGuideView onOpenCanvas={() => setActiveTab('canvas')} />
        )}

        {/* VIEW 8: CEO */}
        {activeTab === 'ceo' && <CeoView />}

        {/* VIEW 9: OUR TEAM */}
        {activeTab === 'team' && <TeamView />}

        {/* VIEW 10: AGENTS */}
        {activeTab === 'agents' && (
          <AgentsView onStartBuilding={handleNewApp} />
        )}

        {/* VIEW 11: VISUAL CANVAS */}
        {activeTab === 'canvas' && (
          <div className="h-[calc(100vh-4rem)] w-full">
            <VisualCanvasStudio />
          </div>
        )}

        {/* VIEW: PRODUCTION READINESS AUDIT */}
        {activeTab === 'readiness' && (
          <div className="p-6 sm:p-10 max-w-7xl mx-auto w-full">
            <ProductionReadinessPanel
              report={readinessReport}
              appName={currentApp.title}
              isProduction={buildMode === 'production'}
              isFixing={isFixingReadiness}
              onFixAllIssues={handleFixAllIssues}
              onRollback={handleRollback}
            />
          </div>
        )}

        {/* VIEW: EVOLVE ENGINE */}
        {activeTab === 'evolve' && (
          <div className="p-6 sm:p-10 max-w-7xl mx-auto w-full">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
              <EvolveModal
                isOpen={true}
                onClose={() => setActiveTab('home')}
                appName={currentApp.title}
                onApplyRecommendations={handleApplyEvolution}
              />
            </div>
          </div>
        )}

        {/* VIEW: GROWTH COMMAND CENTER */}
        {activeTab === 'growth' && (
          <div className="p-6 sm:p-10 max-w-7xl mx-auto w-full">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
              <GrowthCommandCenterModal
                isOpen={true}
                onClose={() => setActiveTab('home')}
                appName={currentApp.title}
                appDescription={currentApp.description}
              />
            </div>
          </div>
        )}

        {/* VIEW: SCOUT MARKET INTELLIGENCE */}
        {activeTab === 'scout' && (
          <div className="p-6 sm:p-10 max-w-7xl mx-auto w-full">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
              <ScoutModal
                isOpen={true}
                onClose={() => setActiveTab('home')}
                onSelectOpportunityForBuild={handleSelectScoutOpportunity}
              />
            </div>
          </div>
        )}
      </main>

      {/* APPMORA Production Readiness Audit Modal */}
      {isReadinessModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 relative">
            <button
              onClick={() => setIsReadinessModalOpen(false)}
              className="absolute top-6 right-6 text-slate-400 hover:text-white p-2 z-10"
            >
              <X size={20} />
            </button>
            <ProductionReadinessPanel
              report={readinessReport}
              appName={currentApp.title}
              isProduction={buildMode === 'production'}
              isFixing={isFixingReadiness}
              onFixAllIssues={handleFixAllIssues}
              onRollback={handleRollback}
            />
          </div>
        </div>
      )}

      {/* APPMORA Evolve Engine Modal */}
      <EvolveModal
        isOpen={isEvolveModalOpen}
        onClose={() => setIsEvolveModalOpen(false)}
        appName={currentApp.title}
        onApplyRecommendations={handleApplyEvolution}
      />

      {/* APPMORA Growth Command Center Modal */}
      <GrowthCommandCenterModal
        isOpen={isGrowthModalOpen}
        onClose={() => setIsGrowthModalOpen(false)}
        appName={currentApp.title}
        appDescription={currentApp.description}
      />

      {/* APPMORA Scout Market Intelligence Modal */}
      <ScoutModal
        isOpen={isScoutModalOpen}
        onClose={() => setIsScoutModalOpen(false)}
        onSelectOpportunityForBuild={handleSelectScoutOpportunity}
      />

      {/* Code Inspector Modal */}
      <FileViewerModal
        file={selectedFile}
        onClose={() => setSelectedFile(null)}
      />

      {/* Workspace & Account Modal (Pricing, Cloud Deployments, Secrets, Team) */}
      <WorkspaceSettingsModal
        isOpen={isWorkspaceModalOpen}
        onClose={() => setIsWorkspaceModalOpen(false)}
        initialTab={workspaceTab}
        onUpgradePlan={(plan) => {
          showToast(`Plan successfully switched to ${plan}!`);
        }}
      />

      {/* Marketing Footer (on all standard pages) */}
      {activeTab !== 'canvas' && (
        <MarketingFooter
          onSelectTab={setActiveTab}
          onOpenChatbot={() => setIsChatbotOpen(true)}
        />
      )}

      {/* CHATBOT POWERED BY SIMEONJRSTUDIOS AND TECHNOLOGIES */}
      <ChatbotWidget
        isOpen={isChatbotOpen}
        onToggle={() => setIsChatbotOpen(!isChatbotOpen)}
        onSendPromptToBuilder={handleSendPromptFromBot}
      />
    </div>
  );
}
