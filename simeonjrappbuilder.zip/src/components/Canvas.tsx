import React, { useState } from 'react';
import { 
  ArrowUp, ArrowDown, Copy, Trash2, Search, 
  ChevronRight, AlertCircle, Sparkles, Check, 
  ExternalLink, Layers, Plus
} from 'lucide-react';
import { AppScreen, AppElement, DeviceType } from '../types';

interface CanvasProps {
  screen: AppScreen;
  selectedElementId: string | null;
  onSelectElement: (id: string) => void;
  onMoveElement: (id: string, direction: 'up' | 'down') => void;
  onDuplicateElement: (id: string) => void;
  onDeleteElement: (id: string) => void;
  onAddElement: (type: any) => void;
  activeDevice: DeviceType;
  previewMode: boolean;
  onNavigateScreen: (screenId: string) => void;
  onTriggerToast: (msg: string) => void;
}

export const Canvas: React.FC<CanvasProps> = ({
  screen,
  selectedElementId,
  onSelectElement,
  onMoveElement,
  onDuplicateElement,
  onDeleteElement,
  onAddElement,
  activeDevice,
  previewMode,
  onNavigateScreen,
  onTriggerToast,
}) => {
  // Local interactive states for preview mode
  const [tabStates, setTabStates] = useState<Record<string, number>>({});
  const [toggleStates, setToggleStates] = useState<Record<string, boolean>>({});
  const [inputValues, setInputValues] = useState<Record<string, string>>({});

  const handleAction = (el: AppElement) => {
    if (!previewMode) return;
    const { actionType, targetScreenId, actionMessage, actionUrl } = el.props;

    if (actionType === 'navigate' && targetScreenId) {
      onNavigateScreen(targetScreenId);
      onTriggerToast(`Navigated to ${targetScreenId}`);
    } else if (actionType === 'toast' && actionMessage) {
      onTriggerToast(actionMessage);
    } else if (actionType === 'alert' && actionMessage) {
      onTriggerToast(`Alert: ${actionMessage}`);
    } else if (actionType === 'openUrl' && actionUrl) {
      onTriggerToast(`Simulating URL open: ${actionUrl}`);
    } else {
      onTriggerToast(`Clicked: ${el.name}`);
    }
  };

  // Device width wrapper
  const getDeviceFrameStyles = () => {
    switch (activeDevice) {
      case 'mobile':
        return 'w-[390px] min-h-[720px] rounded-[36px] shadow-2xl border-8 border-neutral-800 my-6';
      case 'tablet':
        return 'w-[740px] min-h-[820px] rounded-[28px] shadow-2xl border-8 border-neutral-800 my-6';
      case 'desktop':
      default:
        return 'w-full max-w-4xl min-h-[800px] rounded-xl shadow-lg border border-neutral-800 my-6';
    }
  };

  return (
    <main className="flex-1 bg-neutral-950 overflow-y-auto flex flex-col items-center justify-start p-4 relative">
      {/* Active Mode Notice */}
      {previewMode && (
        <div className="sticky top-2 z-40 bg-amber-500/90 text-neutral-950 font-semibold text-xs px-4 py-1.5 rounded-full shadow-lg flex items-center gap-2 backdrop-blur-xs">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Live Interactive Preview — All buttons, inputs & navigations active</span>
        </div>
      )}

      {/* Frame Container */}
      <div 
        className={`${getDeviceFrameStyles()} transition-all duration-300 flex flex-col overflow-hidden bg-white text-neutral-900 relative`}
        style={{ backgroundColor: screen.bgColor || '#f8fafc' }}
      >
        {/* Device Status Bar Mock for Mobile */}
        {activeDevice === 'mobile' && (
          <div className="h-9 bg-neutral-900 text-neutral-300 px-6 flex items-center justify-between text-[11px] font-medium shrink-0 select-none">
            <span>9:41</span>
            <div className="w-20 h-4 bg-neutral-950 rounded-full mx-auto" />
            <div className="flex items-center gap-1.5">
              <span>5G</span>
              <div className="w-4 h-2 border border-neutral-400 rounded-xs relative">
                <div className="h-full w-3/4 bg-neutral-400" />
              </div>
            </div>
          </div>
        )}

        {/* Screen Header Bar */}
        <div className="px-4 py-2 border-b border-neutral-200/60 bg-white/70 backdrop-blur-xs flex items-center justify-between text-xs text-neutral-500">
          <span className="font-semibold text-neutral-800">{screen.name}</span>
          <span className="text-[11px] font-mono">{screen.elements.length} elements</span>
        </div>

        {/* Elements Canvas */}
        <div className="flex-1 p-4 md:p-6 space-y-4">
          {screen.elements.length === 0 ? (
            <div className="h-96 border-2 border-dashed border-neutral-300 rounded-2xl flex flex-col items-center justify-center p-6 text-center text-neutral-400">
              <Layers className="w-10 h-10 mb-2 stroke-1 text-neutral-400" />
              <div className="font-medium text-neutral-700 text-sm">This screen is empty</div>
              <p className="text-xs text-neutral-500 max-w-xs mt-1">
                Select elements from the catalog on the left to start composing this screen.
              </p>
              <button
                onClick={() => onAddElement('header')}
                className="mt-4 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Header Block</span>
              </button>
            </div>
          ) : (
            screen.elements.map((el, index) => {
              const isSelected = !previewMode && el.id === selectedElementId;
              return (
                <div
                  key={el.id}
                  onClick={(e) => {
                    if (!previewMode) {
                      e.stopPropagation();
                      onSelectElement(el.id);
                    }
                  }}
                  className={`relative group transition rounded-xl ${
                    !previewMode
                      ? `cursor-pointer ${
                          isSelected
                            ? 'ring-2 ring-indigo-500 shadow-md ring-offset-2'
                            : 'hover:ring-1 hover:ring-indigo-300'
                        }`
                      : ''
                  }`}
                >
                  {/* Action Toolbar on Selected Element */}
                  {isSelected && (
                    <div className="absolute -top-9 right-0 z-30 flex items-center gap-1 bg-neutral-900 text-white px-2 py-1 rounded-lg shadow-xl text-xs font-medium">
                      <span className="text-[10px] text-indigo-300 px-1 border-r border-neutral-700 font-mono">
                        {el.type}
                      </span>
                      <button
                        onClick={(e) => { e.stopPropagation(); onMoveElement(el.id, 'up'); }}
                        disabled={index === 0}
                        className="p-1 hover:text-indigo-400 disabled:opacity-30"
                        title="Move Up"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); onMoveElement(el.id, 'down'); }}
                        disabled={index === screen.elements.length - 1}
                        className="p-1 hover:text-indigo-400 disabled:opacity-30"
                        title="Move Down"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); onDuplicateElement(el.id); }}
                        className="p-1 hover:text-indigo-400"
                        title="Duplicate"
                      >
                        <Copy className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); onDeleteElement(el.id); }}
                        className="p-1 hover:text-rose-400"
                        title="Delete"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  {/* Render Component Body */}
                  <ElementRenderer
                    element={el}
                    previewMode={previewMode}
                    tabState={tabStates[el.id] ?? el.props.activeTabIndex ?? 0}
                    onTabChange={(idx) => setTabStates((prev) => ({ ...prev, [el.id]: idx }))}
                    toggleState={toggleStates[el.id] ?? el.props.checked ?? false}
                    onToggleChange={(val) => setToggleStates((prev) => ({ ...prev, [el.id]: val }))}
                    inputValue={inputValues[el.id] ?? ''}
                    onInputChange={(val) => setInputValues((prev) => ({ ...prev, [el.id]: val }))}
                    onAction={() => handleAction(el)}
                  />
                </div>
              );
            })
          )}
        </div>
      </div>
    </main>
  );
};

// Sub-component to render each individual UI block
interface ElementRendererProps {
  element: AppElement;
  previewMode: boolean;
  tabState: number;
  onTabChange: (idx: number) => void;
  toggleState: boolean;
  onToggleChange: (val: boolean) => void;
  inputValue: string;
  onInputChange: (val: string) => void;
  onAction: () => void;
}

const ElementRenderer: React.FC<ElementRendererProps> = ({
  element,
  previewMode,
  tabState,
  onTabChange,
  toggleState,
  onToggleChange,
  inputValue,
  onInputChange,
  onAction,
}) => {
  const { props } = element;
  const color = props.colorScheme || 'indigo';

  const getColorClasses = () => {
    switch (color) {
      case 'emerald':
        return {
          bg: 'bg-emerald-600',
          bgLight: 'bg-emerald-50',
          text: 'text-emerald-700',
          border: 'border-emerald-200',
          ring: 'focus:ring-emerald-500',
          linear: 'bg-linear-to-br from-emerald-600 to-teal-800',
        };
      case 'rose':
        return {
          bg: 'bg-rose-600',
          bgLight: 'bg-rose-50',
          text: 'text-rose-700',
          border: 'border-rose-200',
          ring: 'focus:ring-rose-500',
          linear: 'bg-linear-to-br from-rose-600 to-red-800',
        };
      case 'amber':
        return {
          bg: 'bg-amber-600',
          bgLight: 'bg-amber-50',
          text: 'text-amber-700',
          border: 'border-amber-200',
          ring: 'focus:ring-amber-500',
          linear: 'bg-linear-to-br from-amber-500 to-orange-700',
        };
      case 'sky':
        return {
          bg: 'bg-sky-600',
          bgLight: 'bg-sky-50',
          text: 'text-sky-700',
          border: 'border-sky-200',
          ring: 'focus:ring-sky-500',
          linear: 'bg-linear-to-br from-sky-600 to-blue-800',
        };
      case 'purple':
        return {
          bg: 'bg-purple-600',
          bgLight: 'bg-purple-50',
          text: 'text-purple-700',
          border: 'border-purple-200',
          ring: 'focus:ring-purple-500',
          linear: 'bg-linear-to-br from-purple-600 to-indigo-900',
        };
      case 'indigo':
      default:
        return {
          bg: 'bg-indigo-600',
          bgLight: 'bg-indigo-50',
          text: 'text-indigo-700',
          border: 'border-indigo-200',
          ring: 'focus:ring-indigo-500',
          linear: 'bg-linear-to-br from-indigo-600 to-violet-800',
        };
    }
  };

  const scheme = getColorClasses();

  switch (element.type) {
    case 'header':
      return (
        <div className={`py-2 ${props.align === 'center' ? 'text-center' : props.align === 'right' ? 'text-right' : 'text-left'}`}>
          <h2 className="text-2xl font-bold tracking-tight text-neutral-900">{props.title || 'Screen Header'}</h2>
          {props.subtitle && <p className="text-sm text-neutral-500 mt-1">{props.subtitle}</p>}
        </div>
      );

    case 'search':
      return (
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            disabled={!previewMode}
            value={inputValue}
            onChange={(e) => onInputChange(e.target.value)}
            placeholder={props.placeholder || 'Search anything...'}
            className={`w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 ${scheme.ring} shadow-xs`}
          />
        </div>
      );

    case 'hero':
      return (
        <div className={`${scheme.linear} text-white p-6 rounded-2xl shadow-sm space-y-2`}>
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-white/20 text-[11px] font-semibold tracking-wide uppercase">
            <Sparkles className="w-3 h-3" />
            <span>Featured</span>
          </div>
          <h3 className="text-xl font-bold">{props.title || 'Featured Announcement'}</h3>
          <p className="text-sm text-white/80">{props.subtitle || 'Add an inspiring banner or special promotional message.'}</p>
          {props.buttonText && (
            <button
              onClick={onAction}
              className="mt-3 px-4 py-2 bg-white text-neutral-900 font-semibold text-xs rounded-lg hover:bg-neutral-50 active:scale-95 transition shadow-xs"
            >
              {props.buttonText}
            </button>
          )}
        </div>
      );

    case 'tabs':
      const tabs = props.tabs || ['All', 'Popular', 'Recent'];
      return (
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none border-b border-neutral-200/80">
          {tabs.map((tab, idx) => {
            const isActive = tabState === idx;
            return (
              <button
                key={tab}
                onClick={() => previewMode && onTabChange(idx)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                  isActive
                    ? `${scheme.bg} text-white shadow-xs`
                    : 'text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>
      );

    case 'card':
      return (
        <div className="bg-white border border-neutral-200/80 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition">
          {props.imageUrl && (
            <img 
              src={props.imageUrl} 
              alt={props.title || 'Card thumbnail'} 
              className="w-full h-44 object-cover" 
            />
          )}
          <div className="p-4 space-y-1.5">
            <h4 className="font-semibold text-neutral-900 text-base">{props.title || 'Item Card'}</h4>
            <p className="text-sm text-neutral-500 leading-relaxed">{props.subtitle || 'Card description or specifications.'}</p>
            {props.buttonText && (
              <button
                onClick={onAction}
                className={`mt-2 w-full py-2 ${scheme.bgLight} ${scheme.text} font-semibold text-xs rounded-lg hover:opacity-80 transition flex items-center justify-center gap-1`}
              >
                <span>{props.buttonText}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      );

    case 'button':
      return (
        <button
          onClick={onAction}
          className={`w-full py-3 px-4 ${scheme.bg} hover:opacity-90 text-white font-medium text-sm rounded-xl transition shadow-xs flex items-center justify-center gap-2 active:scale-[0.99]`}
        >
          <span>{props.buttonText || 'Action Button'}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      );

    case 'stats':
      const statsList = props.items || [
        { id: '1', title: 'Metric 1', value: '128' },
        { id: '2', title: 'Metric 2', value: '94%' },
        { id: '3', title: 'Metric 3', value: '4.9' },
      ];
      return (
        <div className="grid grid-cols-3 gap-2 bg-white p-3 rounded-xl border border-neutral-200/80 text-center shadow-xs">
          {statsList.map((stat) => (
            <div key={stat.id} className="p-1">
              <div className="text-lg font-bold text-neutral-900 tracking-tight">{stat.value}</div>
              <div className="text-[11px] text-neutral-500 font-medium truncate">{stat.title}</div>
            </div>
          ))}
        </div>
      );

    case 'list':
      const listItems = props.items || [
        { id: '1', title: 'First list record', subtitle: 'Detail note', badge: 'Active' },
        { id: '2', title: 'Second list record', subtitle: 'Detail note', value: '$45' },
      ];
      return (
        <div className="bg-white rounded-xl border border-neutral-200/80 divide-y divide-neutral-100 overflow-hidden shadow-xs">
          {listItems.map((item) => (
            <div key={item.id} className="p-3.5 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-900">{item.title}</p>
                {item.subtitle && <p className="text-xs text-neutral-500 mt-0.5">{item.subtitle}</p>}
              </div>
              <div className="flex items-center gap-2">
                {item.badge && (
                  <span className={`px-2 py-0.5 text-[11px] font-semibold rounded-full ${scheme.bgLight} ${scheme.text}`}>
                    {item.badge}
                  </span>
                )}
                {item.value && <span className="text-xs font-semibold text-neutral-600">{item.value}</span>}
              </div>
            </div>
          ))}
        </div>
      );

    case 'input':
      return (
        <div>
          {props.label && <label className="block text-xs font-medium text-neutral-700 mb-1">{props.label}</label>}
          <input
            type="text"
            disabled={!previewMode}
            value={inputValue}
            onChange={(e) => onInputChange(e.target.value)}
            placeholder={props.placeholder || 'Type here...'}
            className={`w-full px-3.5 py-2.5 bg-white border border-neutral-200 rounded-xl text-sm placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 ${scheme.ring} shadow-xs`}
          />
        </div>
      );

    case 'toggle':
      return (
        <div className="bg-white p-3.5 rounded-xl border border-neutral-200/80 flex items-center justify-between shadow-xs">
          <div>
            <span className="text-sm font-medium text-neutral-900">{props.title || 'Settings Toggle'}</span>
            {props.subtitle && <p className="text-xs text-neutral-500 mt-0.5">{props.subtitle}</p>}
          </div>
          <button
            onClick={() => previewMode && onToggleChange(!toggleState)}
            className={`w-11 h-6 flex items-center rounded-full p-1 transition duration-300 ${
              toggleState ? scheme.bg : 'bg-neutral-300'
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition duration-300 ${
                toggleState ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      );

    case 'image':
      return (
        <div className="rounded-2xl overflow-hidden border border-neutral-200/80 shadow-xs">
          <img
            src={props.imageUrl || 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600'}
            alt="Showcase visual"
            className="w-full h-48 object-cover"
          />
        </div>
      );

    case 'banner':
      return (
        <div className="p-3 bg-amber-50 border border-amber-200/80 rounded-xl text-xs text-amber-900 flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          <span className="font-medium">{props.title || 'Important Notice or Update'}</span>
        </div>
      );

    case 'divider':
      return <div className="h-px bg-neutral-200/80 my-2" />;

    default:
      return (
        <div className="p-3 bg-neutral-100 rounded-lg text-neutral-500 text-xs">
          Unknown block: {element.name}
        </div>
      );
  }
};
