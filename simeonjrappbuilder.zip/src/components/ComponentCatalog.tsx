import React, { useState } from 'react';
import { 
  Heading, LayoutTemplate, Square, CreditCard, 
  TextCursorInput, Search, BarChart3, List, 
  SlidersHorizontal, Image, AlertCircle, Plus, 
  Layers, ChevronRight, Sparkles, Move
} from 'lucide-react';
import { ElementType, AppScreen } from '../types';

interface ComponentCatalogProps {
  screens: AppScreen[];
  activeScreenId: string;
  onSelectScreen: (screenId: string) => void;
  onAddScreen: () => void;
  onAddElement: (type: ElementType) => void;
}

interface ComponentItem {
  type: ElementType;
  label: string;
  description: string;
  icon: React.ElementType;
  category: 'layout' | 'forms' | 'content' | 'data';
}

const CATALOG_ITEMS: ComponentItem[] = [
  // Layout
  {
    type: 'header',
    label: 'Header & Title',
    description: 'Screen title with optional subtitle',
    icon: Heading,
    category: 'layout',
  },
  {
    type: 'hero',
    label: 'Hero Banner',
    description: 'Attention-grabbing callout block with button',
    icon: LayoutTemplate,
    category: 'layout',
  },
  {
    type: 'tabs',
    label: 'Navigation Tabs',
    description: 'Horizontal pill tabs for categories or views',
    icon: SlidersHorizontal,
    category: 'layout',
  },
  {
    type: 'divider',
    label: 'Divider Line',
    description: 'Subtle horizontal section separator',
    icon: Square,
    category: 'layout',
  },

  // Forms & Actions
  {
    type: 'button',
    label: 'Action Button',
    description: 'Interactive button with tap triggers',
    icon: Square,
    category: 'forms',
  },
  {
    type: 'search',
    label: 'Search Field',
    description: 'Search box with search icon and query input',
    icon: Search,
    category: 'forms',
  },
  {
    type: 'input',
    label: 'Text Input',
    description: 'Form input field with label and placeholder',
    icon: TextCursorInput,
    category: 'forms',
  },
  {
    type: 'toggle',
    label: 'Toggle Switch',
    description: 'Interactive on/off settings switch',
    icon: SlidersHorizontal,
    category: 'forms',
  },

  // Content
  {
    type: 'card',
    label: 'Content Card',
    description: 'Image, heading, summary text and action',
    icon: CreditCard,
    category: 'content',
  },
  {
    type: 'image',
    label: 'Image Banner',
    description: 'Full-width visual media asset container',
    icon: Image,
    category: 'content',
  },
  {
    type: 'banner',
    label: 'Alert Banner',
    description: 'Notification or warning callout notice',
    icon: AlertCircle,
    category: 'content',
  },

  // Data & Lists
  {
    type: 'stats',
    label: 'Stats / Metrics',
    description: 'Multi-column KPI counters and highlights',
    icon: BarChart3,
    category: 'data',
  },
  {
    type: 'list',
    label: 'Data List',
    description: 'Stacked item list with subtitle and badges',
    icon: List,
    category: 'data',
  },
];

export const ComponentCatalog: React.FC<ComponentCatalogProps> = ({
  screens,
  activeScreenId,
  onSelectScreen,
  onAddScreen,
  onAddElement,
}) => {
  const [activeTab, setActiveTab] = useState<'components' | 'screens'>('components');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'layout' | 'forms' | 'content' | 'data'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredItems = CATALOG_ITEMS.filter((item) => {
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    const matchesSearch = item.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <aside className="w-72 bg-neutral-900 border-r border-neutral-800 flex flex-col h-full shrink-0 select-none">
      {/* Top Tab Bar: Components vs Screens */}
      <div className="p-2 border-b border-neutral-800 flex items-center gap-1">
        <button
          onClick={() => setActiveTab('components')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
            activeTab === 'components'
              ? 'bg-neutral-800 text-white shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/40'
          }`}
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Blocks</span>
        </button>
        <button
          onClick={() => setActiveTab('screens')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
            activeTab === 'screens'
              ? 'bg-neutral-800 text-white shadow-xs'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/40'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Pages ({screens.length})</span>
        </button>
      </div>

      {activeTab === 'components' ? (
        <div className="flex-1 flex flex-col min-h-0">
          {/* Search and Category Filter */}
          <div className="p-3 border-b border-neutral-800/80 space-y-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search blocks..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-200 placeholder:text-neutral-500 focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            {/* Category Pills */}
            <div className="flex gap-1 overflow-x-auto pb-0.5 scrollbar-none">
              {(['all', 'layout', 'forms', 'content', 'data'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-2 py-1 rounded-md text-[11px] font-medium capitalize shrink-0 transition ${
                    categoryFilter === cat
                      ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Component Items List */}
          <div className="flex-1 overflow-y-auto p-2.5 space-y-1.5">
            {filteredItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.type}
                  onClick={() => onAddElement(item.type)}
                  className="w-full p-2.5 rounded-xl bg-neutral-800/40 hover:bg-neutral-800 border border-neutral-800/70 hover:border-indigo-500/50 flex items-start gap-3 text-left transition group"
                >
                  <div className="w-8 h-8 rounded-lg bg-neutral-900 group-hover:bg-indigo-600/20 text-neutral-400 group-hover:text-indigo-400 flex items-center justify-center shrink-0 transition border border-neutral-800 group-hover:border-indigo-500/40">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold text-neutral-200 flex items-center justify-between">
                      <span>{item.label}</span>
                      <Plus className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 text-indigo-400 transition" />
                    </div>
                    <div className="text-[11px] text-neutral-400 truncate mt-0.5">
                      {item.description}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="p-3 border-t border-neutral-800 bg-neutral-900/80 text-[11px] text-neutral-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span>Click any block to insert into active canvas</span>
          </div>
        </div>
      ) : (
        /* Screens View */
        <div className="flex-1 flex flex-col min-h-0">
          <div className="p-3 border-b border-neutral-800 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">Application Screens</span>
            <button
              onClick={onAddScreen}
              className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white transition shadow-xs"
            >
              <Plus className="w-3 h-3" />
              <span>New Screen</span>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-2.5 space-y-1.5">
            {screens.map((screen, index) => {
              const isActive = screen.id === activeScreenId;
              return (
                <div
                  key={screen.id}
                  onClick={() => onSelectScreen(screen.id)}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition ${
                    isActive
                      ? 'bg-indigo-950/40 border-indigo-500 text-white'
                      : 'bg-neutral-800/40 border-neutral-800 text-neutral-300 hover:bg-neutral-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-md bg-neutral-800 text-[10px] font-mono flex items-center justify-center text-neutral-400">
                      {index + 1}
                    </span>
                    <div>
                      <div className="text-xs font-semibold">{screen.name}</div>
                      <div className="text-[11px] text-neutral-400">{screen.elements.length} elements</div>
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-neutral-500'}`} />
                </div>
              );
            })}
          </div>
        </div>
      )}
    </aside>
  );
};
