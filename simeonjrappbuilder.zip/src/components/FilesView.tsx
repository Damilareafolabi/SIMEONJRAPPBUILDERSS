import React, { useState } from 'react';
import { FileCode2, Download, Copy, Check, Eye } from 'lucide-react';
import { AppFile } from '../types/promptBuilder';

interface FilesViewProps {
  files: AppFile[];
  appName: string;
  onOpenFile: (file: AppFile) => void;
}

export function FilesView({ files, appName, onOpenFile }: FilesViewProps) {
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleDownloadZip = () => {
    // Package files into downloadable JSON manifest / project file
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ appName, files, exportedAt: new Date().toISOString() }, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${appName.toLowerCase().replace(/\s+/g, '-')}-project.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="max-w-5xl mx-auto w-full space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Project Source Architecture</h1>
          <p className="text-xs text-slate-500">
            Generated file system ready for Vite, Next.js, Electron, or Tauri compilation.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-xs transition-all"
        >
          {downloadSuccess ? <Check size={14} className="text-emerald-400" /> : <Download size={14} />}
          <span>{downloadSuccess ? 'Downloaded!' : 'Export Project Bundle'}</span>
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between text-xs text-slate-500 font-semibold">
          <span>Path / File Name</span>
          <div className="flex gap-8">
            <span>Language</span>
            <span>Size</span>
            <span>Action</span>
          </div>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {files.map((file) => (
            <div key={file.path} className="p-4 flex items-center justify-between hover:bg-slate-50/80 transition-colors">
              <div className="flex items-center gap-2.5">
                <FileCode2 size={16} className="text-indigo-600" />
                <div>
                  <span className="font-bold text-slate-800">{file.name}</span>
                  <span className="text-[11px] text-slate-400 ml-2 font-mono">({file.path})</span>
                </div>
              </div>

              <div className="flex items-center gap-8">
                <span className="text-slate-600 font-mono capitalize">{file.language}</span>
                <span className="text-slate-400 font-mono">{file.size || '3.2 KB'}</span>
                <button
                  onClick={() => onOpenFile(file)}
                  className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
                >
                  <Eye size={13} />
                  <span>Inspect</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
