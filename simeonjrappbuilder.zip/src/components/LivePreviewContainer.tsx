import React, { useState } from 'react';
import { 
  Monitor, Tablet, Smartphone, RotateCw, ExternalLink, 
  Maximize2, Check, RefreshCw, ShieldCheck, TrendingUp, 
  Sparkles, CheckCircle2, AlertTriangle, Layers
} from 'lucide-react';
import { PipelineStep, BuildMode, BuildType } from '../types/promptBuilder';
import { TradingApp } from './liveApps/TradingApp';
import { AiAssistantApp } from './liveApps/AiAssistantApp';
import { SaasDashboardApp } from './liveApps/SaasDashboardApp';
import { SocialApp } from './liveApps/SocialApp';
import { DeliveryApp } from './liveApps/DeliveryApp';
import { CustomApp } from './liveApps/CustomApp';

interface LivePreviewContainerProps {
  appType: string;
  appTitle: string;
  prompt: string;
  isGenerating: boolean;
  pipelineSteps: PipelineStep[];
  device: 'desktop' | 'tablet' | 'phone';
  onSelectDevice: (d: 'desktop' | 'tablet' | 'phone') => void;
  onRefresh: () => void;
  buildMode?: BuildMode;
  buildType?: BuildType;
  onOpenReadiness?: () => void;
  onOpenEvolve?: () => void;
  onOpenGrowth?: () => void;
  readinessScore?: number;
}

export function LivePreviewContainer({
  appType,
  appTitle,
  prompt,
  isGenerating,
  pipelineSteps,
  device,
  onSelectDevice,
  onRefresh,
  buildMode = 'production',
  buildType = 'Web',
  onOpenReadiness,
  onOpenEvolve,
  onOpenGrowth,
  readinessScore = 96,
}: LivePreviewContainerProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Render the appropriate live app
  const renderAppContent = () => {
    if (isGenerating) {
      return (
        <div className="w-full h-full min-h-[500px] flex flex-col items-center justify-center bg-slate-900 text-white space-y-4 p-8">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 animate-spin">
            <RefreshCw size={24} />
          </div>
          <div className="text-center space-y-1">
            <h4 className="font-bold text-base">Synthesizing Universal Application...</h4>
            <p className="text-xs text-slate-400 max-w-sm">
              Analyzing prompt requirements, scaffolding state tree, compiling components, and preparing live edge sandbox.
            </p>
          </div>
        </div>
      );
    }

    const typeLower = (appType || '').toLowerCase();
    const promptLower = (prompt || '').toLowerCase();

    if (typeLower.includes('trading') || promptLower.includes('trading') || promptLower.includes('crypto')) {
      return <TradingApp />;
    }
    if (typeLower.includes('ai') || promptLower.includes('ai') || promptLower.includes('chatgpt') || promptLower.includes('gemini')) {
      return <AiAssistantApp />;
    }
    if (typeLower.includes('saas') || promptLower.includes('saas') || promptLower.includes('crm') || promptLower.includes('billing')) {
      return <SaasDashboardApp />;
    }
    if (typeLower.includes('social') || promptLower.includes('social') || promptLower.includes('community')) {
      return <SocialApp />;
    }
    if (typeLower.includes('delivery') || promptLower.includes('delivery') || promptLower.includes('food')) {
      return <DeliveryApp />;
    }

    // Default to dynamic custom app generator tailored to prompt
    return <CustomApp prompt={prompt || 'Interactive modern web and mobile application'} title={appTitle} />;
  };

  return (
    <div className={`space-y-6 max-w-6xl mx-auto w-full pt-8 ${isFullscreen ? 'fixed inset-0 z-50 bg-slate-900 p-6 overflow-y-auto' : ''}`}>
      {/* Top Preview Header & Device Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded ${
              buildMode === 'production'
                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                : 'bg-amber-100 text-amber-900 border border-amber-300'
            }`}>
              {buildMode === 'production' ? '● PRODUCTION READY' : '▲ PROTOTYPE'}
            </span>
            <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
              {buildType} Target
            </span>
            <span className="text-[11px] text-slate-400 font-mono">127.0.0.1:8787</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
            {appTitle || 'Your application'}
          </h2>
        </div>

        {/* Action Buttons: Readiness, Evolve, Growth */}
        <div className="flex flex-wrap items-center gap-2">
          {onOpenReadiness && (
            <button
              onClick={onOpenReadiness}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold shadow-2xs transition flex items-center gap-1.5"
            >
              <ShieldCheck size={14} className={readinessScore >= 90 ? 'text-emerald-600' : 'text-amber-500'} />
              <span>Readiness:</span>
              <span className={`font-black ${readinessScore >= 90 ? 'text-emerald-700' : 'text-amber-700'}`}>
                {readinessScore}/100
              </span>
            </button>
          )}

          {onOpenEvolve && (
            <button
              onClick={onOpenEvolve}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold shadow-xs transition flex items-center gap-1.5"
            >
              <Sparkles size={13} className="text-indigo-300" />
              <span>Evolve App</span>
            </button>
          )}

          {onOpenGrowth && (
            <button
              onClick={onOpenGrowth}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition flex items-center gap-1.5"
            >
              <TrendingUp size={13} />
              <span>Growth Center</span>
            </button>
          )}
        </div>

        {/* Viewport and Action Buttons */}
        <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-slate-200 shadow-xs">
          <button
            onClick={() => onSelectDevice('desktop')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              device === 'desktop' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            <Monitor size={14} />
            <span className="hidden sm:inline">Desktop</span>
          </button>

          <button
            onClick={() => onSelectDevice('tablet')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              device === 'tablet' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            <Tablet size={14} />
            <span className="hidden sm:inline">Tablet</span>
          </button>

          <button
            onClick={() => onSelectDevice('phone')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              device === 'phone' ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-950'
            }`}
          >
            <Smartphone size={14} />
            <span className="hidden sm:inline">Phone</span>
          </button>

          <div className="h-4 w-px bg-slate-200 mx-1" />

          <button
            onClick={onRefresh}
            title="Refresh sandbox"
            className="p-1.5 rounded-lg text-slate-600 hover:text-slate-950 hover:bg-slate-50 transition-colors"
          >
            <RotateCw size={14} />
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            title="Toggle fullscreen"
            className="p-1.5 rounded-lg text-slate-600 hover:text-slate-950 hover:bg-slate-50 transition-colors"
          >
            <Maximize2 size={14} />
          </button>
        </div>
      </div>

      {/* Browser / Device Frame */}
      <div className="flex justify-center w-full">
        <div
          className={`w-full transition-all duration-300 bg-white rounded-3xl border border-slate-300 shadow-xl overflow-hidden flex flex-col ${
            device === 'phone'
              ? 'max-w-[390px] border-8 border-slate-800 rounded-[44px]'
              : device === 'tablet'
              ? 'max-w-[740px]'
              : 'max-w-full'
          }`}
        >
          {/* Simulated Browser Address Bar */}
          <div className="bg-slate-100 border-b border-slate-200 px-4 py-2.5 flex items-center justify-between gap-3 select-none">
            {/* Window traffic light dots */}
            <div className="flex items-center gap-1.5 shrink-0">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            </div>

            {/* Address input */}
            <div className="flex-1 max-w-md bg-white border border-slate-200 rounded-lg px-3 py-1 text-xs text-slate-500 font-mono flex items-center justify-between shadow-2xs">
              <span className="truncate">~ 127.0.0.1:8787/preview</span>
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.2 rounded shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> LIVE
              </span>
            </div>

            <div className="text-[10px] text-slate-400 font-medium hidden sm:block">
              Vite 6 HMR
            </div>
          </div>

          {/* Actual Live App Render */}
          <div className="min-h-[580px] bg-slate-50 flex-1 overflow-hidden relative">
            {renderAppContent()}
          </div>
        </div>
      </div>

      {/* Factory Pipeline Stages (01 PLAN -> 02 BUILD -> 03 TEST -> 04 FIX -> 05 PREVIEW) */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Factory Pipeline
            </div>
            <div className="text-sm font-bold text-slate-900">
              Idea → Production
            </div>
          </div>
          <span className="text-xs text-emerald-600 font-semibold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            Automated CI/CD Verification
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {pipelineSteps.map((step) => {
            const isRunning = step.status === 'running';
            const isDone = step.status === 'done';

            return (
              <div
                key={step.id}
                className={`p-3 rounded-2xl border transition-all ${
                  isRunning
                    ? 'border-indigo-400 bg-indigo-50/50 shadow-xs'
                    : isDone
                    ? 'border-slate-200 bg-slate-50'
                    : 'border-slate-100 bg-white opacity-60'
                }`}
              >
                <div className="text-[10px] font-bold text-slate-400">{step.stepNum}</div>
                <div className="font-bold text-xs text-slate-900 mt-0.5 flex items-center gap-1">
                  <span>{step.name}</span>
                  {isDone && <Check size={12} className="text-emerald-600" />}
                </div>
                <div className="text-[11px] text-slate-500 mt-1 leading-tight">
                  {step.desc}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
