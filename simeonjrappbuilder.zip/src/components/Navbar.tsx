import React, { useState } from 'react';
import { 
  Smartphone, Tablet, Monitor, Play, Edit3, Code2, 
  FolderDown, FolderUp, RotateCcw, RotateCw, Layers, 
  Sparkles, Check, ChevronDown, Plus
} from 'lucide-react';
import { DeviceType, AppProject } from '../types';
import { STARTER_TEMPLATES } from '../templates';

interface NavbarProps {
  project: AppProject;
  activeDevice: DeviceType;
  onDeviceChange: (device: DeviceType) => void;
  previewMode: boolean;
  onTogglePreview: () => void;
  onOpenExport: () => void;
  onOpenScreens: () => void;
  onSelectTemplate: (templateKey: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onUpdateProjectName: (name: string) => void;
  onDownloadProject: () => void;
  onImportProject: (file: File) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  project,
  activeDevice,
  onDeviceChange,
  previewMode,
  onTogglePreview,
  onOpenExport,
  onOpenScreens,
  onSelectTemplate,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onUpdateProjectName,
  onDownloadProject,
  onImportProject,
}) => {
  const [templateMenuOpen, setTemplateMenuOpen] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);
  const [projectName, setProjectName] = useState(project.name);

  const handleNameSubmit = () => {
    setIsEditingName(false);
    if (projectName.trim()) {
      onUpdateProjectName(projectName.trim());
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImportProject(file);
    }
  };

  return (
    <header className="h-14 bg-neutral-900 border-b border-neutral-800 text-neutral-200 px-4 flex items-center justify-between z-30 shrink-0">
      {/* Left: Branding & Project Title */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-linear-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white font-bold shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold tracking-wider text-neutral-400 uppercase">Simeon Jr</span>
              <span className="text-xs px-1.5 py-0.5 rounded-sm bg-indigo-950 text-indigo-300 font-mono border border-indigo-800/60">BUILDER</span>
            </div>
            {isEditingName ? (
              <input
                type="text"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                onBlur={handleNameSubmit}
                onKeyDown={(e) => e.key === 'Enter' && handleNameSubmit()}
                autoFocus
                className="text-sm font-semibold bg-neutral-800 text-white px-1.5 py-0.5 rounded-sm outline-hidden border border-indigo-500"
              />
            ) : (
              <button
                onClick={() => setIsEditingName(true)}
                className="text-sm font-semibold text-neutral-100 hover:text-indigo-400 flex items-center gap-1 text-left transition"
                title="Click to rename project"
              >
                <span>{project.name}</span>
                <Edit3 className="w-3 h-3 text-neutral-500" />
              </button>
            )}
          </div>
        </div>

        <div className="h-6 w-px bg-neutral-800 ml-2" />

        {/* Templates dropdown */}
        <div className="relative">
          <button
            onClick={() => setTemplateMenuOpen(!templateMenuOpen)}
            className="flex items-center gap-1.5 text-xs font-medium px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700/80 text-neutral-300 transition"
          >
            <span>Templates</span>
            <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
          </button>

          {templateMenuOpen && (
            <div className="absolute left-0 mt-1.5 w-52 bg-neutral-800 border border-neutral-700 rounded-xl shadow-xl p-1.5 z-50 text-xs">
              <div className="px-2 py-1 text-[10px] uppercase font-bold text-neutral-400">Load Starter App</div>
              <button
                onClick={() => { onSelectTemplate('ecommerce'); setTemplateMenuOpen(false); }}
                className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-neutral-700 text-neutral-200 transition"
              >
                <div className="font-medium">Storefront App</div>
                <div className="text-[11px] text-neutral-400">Products, cart & catalog flow</div>
              </button>
              <button
                onClick={() => { onSelectTemplate('productivity'); setTemplateMenuOpen(false); }}
                className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-neutral-700 text-neutral-200 transition"
              >
                <div className="font-medium">TaskFlow Planner</div>
                <div className="text-[11px] text-neutral-400">Sprint lists & daily metrics</div>
              </button>
              <button
                onClick={() => { onSelectTemplate('blank'); setTemplateMenuOpen(false); }}
                className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-neutral-700 text-neutral-200 transition"
              >
                <div className="font-medium">Blank Canvas</div>
                <div className="text-[11px] text-neutral-400">Fresh minimal screen</div>
              </button>
            </div>
          )}
        </div>

        {/* Screens manager button */}
        <button
          onClick={onOpenScreens}
          className="flex items-center gap-1.5 text-xs font-medium px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700/80 text-neutral-300 transition"
          title="Manage screens & pages"
        >
          <Layers className="w-3.5 h-3.5 text-indigo-400" />
          <span>Screens ({project.screens.length})</span>
        </button>
      </div>

      {/* Center: Device Viewport Switcher */}
      <div className="flex items-center bg-neutral-950 p-0.5 rounded-lg border border-neutral-800">
        <button
          onClick={() => onDeviceChange('mobile')}
          className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition ${
            activeDevice === 'mobile' ? 'bg-neutral-800 text-white shadow-xs' : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Mobile Viewport (375x720)"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Mobile</span>
        </button>
        <button
          onClick={() => onDeviceChange('tablet')}
          className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition ${
            activeDevice === 'tablet' ? 'bg-neutral-800 text-white shadow-xs' : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Tablet Viewport (768x860)"
        >
          <Tablet className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Tablet</span>
        </button>
        <button
          onClick={() => onDeviceChange('desktop')}
          className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition ${
            activeDevice === 'desktop' ? 'bg-neutral-800 text-white shadow-xs' : 'text-neutral-400 hover:text-neutral-200'
          }`}
          title="Full Desktop Viewport"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Desktop</span>
        </button>
      </div>

      {/* Right: Actions (Undo/Redo, Mode, Export, Save) */}
      <div className="flex items-center gap-2">
        <div className="flex items-center text-neutral-400 bg-neutral-800/80 rounded-lg p-0.5 border border-neutral-800">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className="p-1.5 hover:text-white disabled:opacity-30 disabled:hover:text-neutral-400 rounded-md transition"
            title="Undo (Ctrl+Z)"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            className="p-1.5 hover:text-white disabled:opacity-30 disabled:hover:text-neutral-400 rounded-md transition"
            title="Redo (Ctrl+Y)"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mode toggle */}
        <button
          onClick={onTogglePreview}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
            previewMode 
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30' 
              : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200'
          }`}
        >
          {previewMode ? (
            <>
              <Edit3 className="w-3.5 h-3.5" />
              <span>Exit Preview</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
              <span>Live Test</span>
            </>
          )}
        </button>

        {/* Export Code Modal */}
        <button
          onClick={onOpenExport}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs transition"
          title="Export React + Tailwind Code"
        >
          <Code2 className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Export Code</span>
        </button>

        {/* Backup / Export JSON */}
        <button
          onClick={onDownloadProject}
          className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          title="Download Project JSON"
        >
          <FolderDown className="w-4 h-4" />
        </button>

        <label 
          className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 cursor-pointer transition"
          title="Import Project JSON"
        >
          <FolderUp className="w-4 h-4" />
          <input 
            type="file" 
            accept=".json" 
            onChange={handleFileInput} 
            className="hidden" 
          />
        </label>
      </div>
    </header>
  );
};
