import React from 'react';
import { FolderKanban, Play, Download, Trash2, ArrowUpRight, Sparkles, ExternalLink } from 'lucide-react';
import { GeneratedApp } from '../types/promptBuilder';

interface ProjectsViewProps {
  projects: GeneratedApp[];
  onLaunchProject: (app: GeneratedApp) => void;
  onDeleteProject: (id: string) => void;
  onNewApp: () => void;
}

export function ProjectsView({ projects, onLaunchProject, onDeleteProject, onNewApp }: ProjectsViewProps) {
  return (
    <div className="max-w-6xl mx-auto w-full space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Your Generated Applications</h1>
          <p className="text-xs text-slate-500">Universal software artifacts synthesized from your prompts.</p>
        </div>
        <button
          onClick={onNewApp}
          className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-xs"
        >
          + Create New App
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projects.map((p) => (
          <div key={p.id} className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs flex flex-col justify-between space-y-4 hover:shadow-md transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded-full border border-indigo-200">
                  {p.category}
                </span>
                <span className="text-[11px] text-slate-400">
                  {new Date(p.createdAt).toLocaleDateString()}
                </span>
              </div>
              <h3 className="font-bold text-base text-slate-900 leading-snug">{p.title}</h3>
              <p className="text-xs text-slate-600 line-clamp-2 mt-1 leading-relaxed">{p.description}</p>
              <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-2.5 mt-3 text-[11px] text-slate-500 italic">
                "{p.prompt}"
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <span className="text-[11px] text-slate-500 font-medium">
                {p.files.length} production files
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onDeleteProject(p.id)}
                  className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-50 transition-colors"
                  title="Delete"
                >
                  <Trash2 size={14} />
                </button>
                <button
                  onClick={() => onLaunchProject(p)}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1 shadow-xs transition-all active:scale-95"
                >
                  <Play size={12} fill="currentColor" />
                  <span>Launch Live</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
