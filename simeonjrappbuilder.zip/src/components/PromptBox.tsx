import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, Sparkles, Plus, RefreshCw, Layers, 
  Smartphone, Monitor, Globe, Cpu, Database, 
  CheckCircle2, AlertTriangle, ShieldCheck, Copy, 
  FileCode, Zap, Upload, Play, Clock
} from 'lucide-react';
import { AppCategory, BuildMode, BuildType } from '../types/promptBuilder';
import { PROMPT_IDEAS, DYNAMIC_APPMORA_IDEAS } from '../data/appPresets';

interface PromptBoxProps {
  selectedCategory: AppCategory;
  onSelectCategory: (cat: AppCategory) => void;
  prompt: string;
  onChangePrompt: (val: string) => void;
  onBuild: () => void;
  isGenerating: boolean;
  buildMode: BuildMode;
  onSelectBuildMode: (mode: BuildMode) => void;
  buildType: BuildType;
  onSelectBuildType: (type: BuildType) => void;
  onTransformExisting?: () => void;
  onCloneApp?: () => void;
  onImportProject?: () => void;
}

export function PromptBox({
  selectedCategory,
  onSelectCategory,
  prompt,
  onChangePrompt,
  onBuild,
  isGenerating,
  buildMode,
  onSelectBuildMode,
  buildType,
  onSelectBuildType,
  onTransformExisting,
  onCloneApp,
  onImportProject,
}: PromptBoxProps) {
  const [ideaTab, setIdeaTab] = useState<'popular' | 'dynamic'>('popular');
  const [dynamicCycle, setDynamicCycle] = useState(0);
  const [isAutoRefreshing, setIsAutoRefreshing] = useState(true);
  const [secondsUntilRefresh, setSecondsUntilRefresh] = useState(20);

  // Periodic automatic refresh for APPMORA dynamic ideas (20s interval)
  useEffect(() => {
    if (!isAutoRefreshing) return;
    const timer = setInterval(() => {
      setSecondsUntilRefresh((prev) => {
        if (prev <= 1) {
          setDynamicCycle((c) => c + 1);
          return 20;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isAutoRefreshing]);

  const BUILD_TYPES: { id: BuildType; label: string; icon: React.ElementType }[] = [
    { id: 'Web', label: 'Web', icon: Globe },
    { id: 'Mobile', label: 'Mobile', icon: Smartphone },
    { id: 'Android APK', label: 'Android APK', icon: Smartphone },
    { id: 'Desktop', label: 'Desktop', icon: Monitor },
    { id: 'AI App', label: 'AI App', icon: Cpu },
    { id: 'SaaS', label: 'SaaS', icon: Database },
    { id: 'Multi-App', label: 'Multi-App', icon: Layers },
    { id: 'Other', label: 'Other', icon: Sparkles },
  ];

  const popularIdeas = DYNAMIC_APPMORA_IDEAS.filter((i) => i.type === 'popular');
  const dynamicIdeas = DYNAMIC_APPMORA_IDEAS.filter((i) => i.type === 'dynamic');

  const charCount = prompt.length;
  const wordCount = prompt.trim() ? prompt.trim().split(/\s+/).length : 0;

  return (
    <div id="build-engine" className="space-y-8 max-w-4xl mx-auto w-full pt-2">
      {/* Heading */}
      <div className="text-center space-y-2">
        <h2 className="text-3xl sm:text-4xl font-black text-slate-950 tracking-tight">
          What do you want to build?
        </h2>
        <p className="text-sm text-slate-600 max-w-2xl mx-auto leading-relaxed">
          Describe your application, features, users, workflow, design, integrations and requirements. Paste full specs or enter high-level goals — APPMORA has no prompt length limits.
        </p>
      </div>

      {/* Main Unlimited Prompt Box */}
      <div className="bg-white border border-slate-300 rounded-3xl p-5 shadow-sm hover:border-indigo-400 focus-within:border-indigo-600 focus-within:ring-4 focus-within:ring-indigo-100 transition-all text-left relative space-y-4">
        {/* Badges / Header bar */}
        <div className="flex items-center justify-between text-xs text-slate-500 pb-1 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700 uppercase tracking-wider text-[10px]">
              Unlimited Input Specification
            </span>
            <span className="text-slate-300">•</span>
            <span className="text-[11px] text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md">
              No Artificial Limits
            </span>
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            {charCount.toLocaleString()} chars | {wordCount.toLocaleString()} words
          </div>
        </div>

        <textarea
          value={prompt}
          onChange={(e) => onChangePrompt(e.target.value)}
          placeholder="Describe your application, features, users, workflow, design, integrations and requirements. Be as detailed as you want."
          rows={6}
          className="w-full bg-transparent text-sm sm:text-base text-slate-900 placeholder-slate-400 focus:outline-none resize-y min-h-[140px] leading-relaxed font-sans"
        />

        {/* Action strip inside prompt box */}
        <div className="flex flex-wrap items-center justify-between pt-3 border-t border-slate-100 gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onChangePrompt('')}
              className="text-xs text-slate-500 hover:text-slate-800 font-medium px-2.5 py-1.5 rounded-lg hover:bg-slate-100 flex items-center gap-1.5 transition-colors"
            >
              <Plus size={14} />
              <span>Clear prompt</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onBuild}
              disabled={!prompt.trim() || isGenerating}
              className={`font-bold text-xs uppercase tracking-wider px-6 py-3 rounded-xl flex items-center gap-2 shadow-md transition-all active:scale-95 ${
                buildMode === 'production'
                  ? 'bg-slate-900 hover:bg-black text-white shadow-slate-900/20'
                  : 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-600/20'
              } disabled:opacity-40`}
            >
              {isGenerating ? (
                <>
                  <RefreshCw size={15} className="animate-spin" />
                  <span>Synthesizing Application...</span>
                </>
              ) : (
                <>
                  <span>
                    {buildMode === 'production' ? 'BUILD PRODUCTION APP' : 'BUILD PROTOTYPE'}
                  </span>
                  <ArrowRight size={15} />
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Build Controls: Build Type & Build Mode */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. Build Type Selector */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Build Type
            </label>
            <span className="text-[11px] text-slate-400 font-mono">Target Platform</span>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {BUILD_TYPES.map((bt) => {
              const isSelected = buildType === bt.id;
              const Icon = bt.icon;
              return (
                <button
                  key={bt.id}
                  onClick={() => {
                    onSelectBuildType(bt.id);
                    // Map buildType to appCategory
                    if (bt.id === 'Web') onSelectCategory('Web App');
                    else if (bt.id === 'Mobile') onSelectCategory('Mobile App');
                    else if (bt.id === 'Android APK') onSelectCategory('APK / Android App');
                    else if (bt.id === 'Desktop') onSelectCategory('Desktop App');
                    else if (bt.id === 'AI App') onSelectCategory('AI Chat App');
                    else if (bt.id === 'SaaS') onSelectCategory('SaaS Dashboard');
                    else if (bt.id === 'Multi-App') onSelectCategory('Multi-App Suite');
                  }}
                  className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  <Icon size={16} className={isSelected ? 'text-white' : 'text-slate-500'} />
                  <span className="mt-1 text-[11px] leading-tight">{bt.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Build Mode Selector: Prototype vs Production */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Build Mode
            </label>
            <span className="text-[11px] font-mono text-indigo-600 font-semibold">
              {buildMode === 'production' ? 'Full Production Readiness' : 'Fast Concept Validation'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {/* Prototype Mode Button */}
            <button
              onClick={() => onSelectBuildMode('prototype')}
              className={`p-3 rounded-xl border text-left transition-all ${
                buildMode === 'prototype'
                  ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-400/40 text-amber-950 shadow-xs'
                  : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs">Prototype</span>
                <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-amber-200/70 text-amber-900">
                  Concept
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                Simulated data, UI wireframing, rapid product validation. Fast iteration.
              </p>
            </button>

            {/* Production Mode Button */}
            <button
              onClick={() => onSelectBuildMode('production')}
              className={`p-3 rounded-xl border text-left transition-all ${
                buildMode === 'production'
                  ? 'bg-slate-900 border-slate-900 ring-2 ring-slate-800 text-white shadow-sm'
                  : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs">Production</span>
                <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                  buildMode === 'production' ? 'bg-emerald-500 text-slate-950' : 'bg-emerald-100 text-emerald-800'
                }`}>
                  Ready
                </span>
              </div>
              <p className={`text-[11px] mt-1 leading-snug ${
                buildMode === 'production' ? 'text-slate-300' : 'text-slate-500'
              }`}>
                Real auth, persistent DB, live APIs, 18-step validation checks & packaging.
              </p>
            </button>
          </div>
        </div>
      </div>

      {/* Action Suite: Build New, Transform Existing, Clone App, Import Project */}
      <div className="flex flex-wrap items-center justify-center gap-2 pt-1 text-xs">
        <span className="text-slate-400 font-semibold text-[11px] uppercase tracking-wider mr-1">
          Factory Actions:
        </span>
        <button
          onClick={onBuild}
          disabled={!prompt.trim() || isGenerating}
          className="px-3.5 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-black font-semibold flex items-center gap-1.5 shadow-xs transition-all disabled:opacity-40"
        >
          <Play size={13} />
          <span>Build New</span>
        </button>
        <button
          onClick={onTransformExisting}
          className="px-3.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold flex items-center gap-1.5 shadow-2xs transition-all"
        >
          <FileCode size={13} className="text-indigo-600" />
          <span>Transform Existing</span>
        </button>
        <button
          onClick={onCloneApp}
          className="px-3.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold flex items-center gap-1.5 shadow-2xs transition-all"
        >
          <Copy size={13} className="text-emerald-600" />
          <span>Clone App</span>
        </button>
        <button
          onClick={onImportProject}
          className="px-3.5 py-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold flex items-center gap-1.5 shadow-2xs transition-all"
        >
          <Upload size={13} className="text-amber-600" />
          <span>Import Project</span>
        </button>
      </div>

      {/* Section 12 & 13: ✨ APPMORA IDEAS with Dynamic Periodic Refresh */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              ✨ APPMORA Ideas
            </h3>
            <span className="text-xs text-slate-400">|</span>
            <span className="text-xs text-slate-500">Autonomous concept synthesis</span>
          </div>

          <div className="flex items-center gap-3">
            {/* Countdown / Refresh indicator */}
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
              <Clock size={12} className="text-indigo-500" />
              <span>Next cycle in {secondsUntilRefresh}s</span>
            </div>

            <button
              onClick={() => {
                setDynamicCycle((c) => c + 1);
                setSecondsUntilRefresh(20);
              }}
              title="Refresh ideas immediately"
              className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <RefreshCw size={13} />
            </button>
          </div>
        </div>

        {/* Dual Tabs: Popular Ideas vs New APPMORA Ideas */}
        <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
          <button
            onClick={() => setIdeaTab('popular')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              ideaTab === 'popular'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Popular Ideas (Starter Blueprints)
          </button>
          <button
            onClick={() => setIdeaTab('dynamic')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
              ideaTab === 'dynamic'
                ? 'bg-indigo-600 text-white shadow-2xs'
                : 'text-indigo-600 hover:bg-indigo-50'
            }`}
          >
            <Sparkles size={12} />
            <span>✨ New APPMORA Ideas</span>
          </button>
        </div>

        {/* Idea Cards / Chips */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {(ideaTab === 'popular' ? popularIdeas : dynamicIdeas).map((item) => (
            <div
              key={item.id}
              onClick={() => {
                onChangePrompt(item.prompt);
                if (item.category === 'Trading') {
                  onSelectBuildType('Web');
                  onSelectCategory('Trading Platform');
                } else if (item.category === 'AI App') {
                  onSelectBuildType('AI App');
                  onSelectCategory('AI Chat App');
                } else if (item.category === 'Social') {
                  onSelectBuildType('Web');
                  onSelectCategory('Social Platform');
                } else if (item.category === 'SaaS') {
                  onSelectBuildType('SaaS');
                  onSelectCategory('SaaS Dashboard');
                } else if (item.category === 'Mobile & Web') {
                  onSelectBuildType('Mobile');
                  onSelectCategory('Mobile App');
                } else if (item.category === 'Desktop') {
                  onSelectBuildType('Desktop');
                  onSelectCategory('Desktop App');
                }
              }}
              className="p-3 rounded-xl border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/30 text-left cursor-pointer transition-all shadow-2xs group"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-900 group-hover:text-indigo-950 transition-colors">
                  {item.title}
                </span>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 border border-slate-200">
                  {item.badge}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                {item.prompt}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
