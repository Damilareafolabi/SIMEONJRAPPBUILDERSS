import React from 'react';
import { 
  Sparkles, CheckCircle, ArrowRight, ShieldCheck, 
  Cpu, HardDrive, Zap, Info, ChevronRight, Layers,
  Terminal, Globe, Smartphone, Monitor
} from 'lucide-react';

interface PromptHeaderProps {
  onStartBuilding: () => void;
  onExploreAppmora: () => void;
}

export function PromptHeader({ onStartBuilding, onExploreAppmora }: PromptHeaderProps) {
  return (
    <div className="space-y-8">
      {/* Top status bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200/80 pb-4 gap-3">
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-indigo-600 flex items-center gap-2">
            <span className="font-extrabold tracking-wider">APPMORA</span>
            <span className="text-slate-400">•</span>
            <span className="text-slate-600 font-semibold">Simeon Intelligence Software Factory</span>
            <span className="text-slate-400">•</span>
            <span className="text-slate-400 font-medium">Simeon Jr Studios & Technologies</span>
          </div>
          <div className="text-sm font-bold text-slate-900 mt-0.5">
            IDEA → SOFTWARE → PRODUCTION → EVOLUTION
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1 rounded-full text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[11px] font-bold uppercase tracking-wider">Local AI Engine Active</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-slate-500 font-mono">
            <HardDrive size={13} className="text-indigo-500" />
            <span>0 Required API Keys</span>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="text-center max-w-4xl mx-auto space-y-6 pt-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-50 border border-indigo-200/80 text-indigo-700 text-xs font-semibold shadow-2xs">
          <Sparkles size={13} className="text-indigo-600 animate-spin" />
          <span className="font-bold tracking-tight">Simeon Intelligence Software Factory</span>
          <span className="text-indigo-400">|</span>
          <span className="text-slate-600 font-medium">From Idea to Software</span>
        </div>

        <div className="space-y-3">
          <h1 className="text-4xl sm:text-6xl font-black text-slate-950 tracking-tight leading-none">
            APPMORA
          </h1>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-indigo-600 tracking-tight">
            From Idea to Software.
          </h2>
          <p className="text-sm sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed pt-1">
            Build real web applications, mobile applications, Android APKs, desktop software, SaaS platforms, AI applications and multi-app ecosystems from natural-language instructions.
          </p>
          <div className="text-xs sm:text-sm font-bold text-slate-800 tracking-wide">
            Build it. Test it. Deploy it. Evolve it.
          </div>
        </div>

        {/* Primary and Secondary CTA Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            onClick={onStartBuilding}
            className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center gap-2 active:scale-95"
          >
            <span>Start Building</span>
            <ArrowRight size={16} />
          </button>
          <button
            onClick={onExploreAppmora}
            className="px-6 py-3 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold text-sm shadow-xs transition-all flex items-center gap-2"
          >
            <span>Explore APPMORA</span>
            <ChevronRight size={16} className="text-slate-400" />
          </button>
        </div>

        {/* Real Software Factory Workflow Strip */}
        <div className="pt-4">
          <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2.5">
            APPMORA REAL SOFTWARE FACTORY PIPELINE
          </div>
          <div className="bg-white border border-slate-200/90 rounded-2xl p-3 shadow-xs overflow-x-auto">
            <div className="flex items-center justify-between min-w-[700px] text-[11px] font-semibold text-slate-700 px-2">
              {[
                'IDEA', 'UNDERSTAND', 'PLAN', 'ARCHITECT', 'BUILD',
                'INSTALL', 'TEST', 'FIX', 'PREVIEW', 'SECURITY CHECK',
                'PRODUCTION BUILD', 'PACKAGE', 'DEPLOY', 'MONITOR', 'EVOLVE'
              ].map((stage, idx, arr) => (
                <React.Fragment key={stage}>
                  <span className={`px-2 py-1 rounded-md transition-colors ${
                    stage === 'BUILD' || stage === 'TEST' || stage === 'EVOLVE'
                      ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-200'
                      : 'hover:bg-slate-50'
                  }`}>
                    {stage}
                  </span>
                  {idx < arr.length - 1 && (
                    <ChevronRight size={12} className="text-slate-300 shrink-0" />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* Section 4: Build Without a Mandatory AI API Key */}
        <div className="bg-white border border-slate-200/90 rounded-3xl p-6 sm:p-7 shadow-xs text-left space-y-4 relative overflow-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-indigo-600">
                Core APPMORA Advantage
              </div>
              <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                Build Without a Mandatory AI API Key
              </h3>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold w-fit">
              <CheckCircle size={13} />
              <span>Local-First Autonomous Engine</span>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Run APPMORA's local-first AI software factory using local AI infrastructure without requiring users to provide an external AI API key for the core local building workflow.
          </p>

          {/* 6 Mandatory Advantage Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            {[
              '✓ Local-first AI',
              '✓ No mandatory AI API key',
              '✓ No artificial local prompt credits',
              '✓ Web + Mobile + Android + Desktop',
              '✓ Prototype + Production',
              '✓ Build + Test + Fix + Deploy',
            ].map((badge) => (
              <div
                key={badge}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800 flex items-center gap-1.5"
              >
                <span className="font-bold">{badge}</span>
              </div>
            ))}
          </div>

          {/* Clear Distinction: Local Factory vs Optional 3rd-Party Services */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-xs">
            <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-3.5 space-y-1">
              <div className="font-bold text-indigo-900 flex items-center gap-1.5">
                <HardDrive size={13} className="text-indigo-600" />
                <span>APPMORA LOCAL FACTORY</span>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Core parsing, architecture planning, TypeScript synthesis, AST verification, and local preview compile cleanly without requiring external cloud accounts or external AI API keys.
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1">
              <div className="font-bold text-slate-800 flex items-center gap-1.5">
                <Globe size={13} className="text-slate-600" />
                <span>OPTIONAL THIRD-PARTY SERVICES</span>
              </div>
              <p className="text-slate-500 text-[11px] leading-relaxed">
                If your generated application integrates external providers (Stripe, Twilio, Google Maps, SendGrid, or custom external AI endpoints), those API keys belong to the specific application integration and are never an APPMORA prerequisite.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
