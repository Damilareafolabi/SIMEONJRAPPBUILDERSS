import React from 'react';
import { 
  X, Trash2, Copy, Sliders, Palette, 
  Link2, AlignLeft, AlignCenter, AlignRight, 
  Sparkles, Plus, Minus
} from 'lucide-react';
import { AppElement, AppScreen } from '../types';

interface PropertyInspectorProps {
  element: AppElement | null;
  screens: AppScreen[];
  onUpdateElementProps: (elementId: string, updatedProps: Partial<AppElement['props']>) => void;
  onUpdateElementName: (elementId: string, name: string) => void;
  onClose: () => void;
  onDuplicate: (elementId: string) => void;
  onDelete: (elementId: string) => void;
}

export const PropertyInspector: React.FC<PropertyInspectorProps> = ({
  element,
  screens,
  onUpdateElementProps,
  onUpdateElementName,
  onClose,
  onDuplicate,
  onDelete,
}) => {
  if (!element) {
    return (
      <aside className="w-80 bg-neutral-900 border-l border-neutral-800 p-6 flex flex-col items-center justify-center text-center text-neutral-400 select-none">
        <Sliders className="w-10 h-10 mb-3 stroke-1 text-neutral-500" />
        <div className="text-xs font-semibold text-neutral-300">No Block Selected</div>
        <p className="text-[11px] text-neutral-500 mt-1 max-w-[200px]">
          Click on any element in the canvas to adjust its properties, text, color theme, and click actions.
        </p>
      </aside>
    );
  }

  const { props } = element;

  const handlePropChange = (field: keyof AppElement['props'], value: any) => {
    onUpdateElementProps(element.id, { [field]: value });
  };

  const handleListItemChange = (index: number, field: string, value: string) => {
    const currentItems = [...(props.items || [])];
    if (currentItems[index]) {
      currentItems[index] = { ...currentItems[index], [field]: value };
      handlePropChange('items', currentItems);
    }
  };

  const handleAddListItem = () => {
    const currentItems = [...(props.items || [])];
    currentItems.push({
      id: String(Date.now()),
      title: 'New Item',
      subtitle: 'Description note',
      value: '100',
    });
    handlePropChange('items', currentItems);
  };

  const handleRemoveListItem = (index: number) => {
    const currentItems = (props.items || []).filter((_, i) => i !== index);
    handlePropChange('items', currentItems);
  };

  const handleTabChange = (index: number, value: string) => {
    const currentTabs = [...(props.tabs || [])];
    currentTabs[index] = value;
    handlePropChange('tabs', currentTabs);
  };

  const handleAddTab = () => {
    const currentTabs = [...(props.tabs || ['Tab 1', 'Tab 2'])];
    currentTabs.push(`Tab ${currentTabs.length + 1}`);
    handlePropChange('tabs', currentTabs);
  };

  const handleRemoveTab = (index: number) => {
    const currentTabs = (props.tabs || []).filter((_, i) => i !== index);
    handlePropChange('tabs', currentTabs);
  };

  return (
    <aside className="w-80 bg-neutral-900 border-l border-neutral-800 flex flex-col h-full shrink-0 select-none text-neutral-200">
      {/* Header */}
      <div className="p-3 border-b border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-indigo-500" />
          <span className="text-xs font-bold uppercase tracking-wider text-neutral-300">
            Inspector • {element.type}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => onDuplicate(element.id)}
            className="p-1 hover:text-white text-neutral-400 transition"
            title="Duplicate Block"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDelete(element.id)}
            className="p-1 hover:text-rose-400 text-neutral-400 transition"
            title="Delete Block"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="p-1 hover:text-white text-neutral-400 transition ml-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content Form */}
      <div className="flex-1 overflow-y-auto p-3.5 space-y-4 text-xs">
        {/* Name in Tree */}
        <div>
          <label className="block text-[11px] font-medium text-neutral-400 mb-1">Block Label</label>
          <input
            type="text"
            value={element.name}
            onChange={(e) => onUpdateElementName(element.id, e.target.value)}
            className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden focus:border-indigo-500 text-xs"
          />
        </div>

        {/* Text / Content Fields */}
        <div className="space-y-3 pt-2 border-t border-neutral-800/80">
          <div className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">Content</div>

          {('title' in props || ['header', 'hero', 'card', 'banner', 'toggle'].includes(element.type)) && (
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Title / Headline</label>
              <input
                type="text"
                value={props.title || ''}
                onChange={(e) => handlePropChange('title', e.target.value)}
                placeholder="Enter title text"
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden focus:border-indigo-500 text-xs"
              />
            </div>
          )}

          {('subtitle' in props || ['header', 'hero', 'card', 'toggle'].includes(element.type)) && (
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Subtitle / Description</label>
              <textarea
                rows={2}
                value={props.subtitle || ''}
                onChange={(e) => handlePropChange('subtitle', e.target.value)}
                placeholder="Enter summary or description"
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden focus:border-indigo-500 text-xs resize-none"
              />
            </div>
          )}

          {('buttonText' in props || ['button', 'hero', 'card'].includes(element.type)) && (
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Button Label</label>
              <input
                type="text"
                value={props.buttonText || ''}
                onChange={(e) => handlePropChange('buttonText', e.target.value)}
                placeholder="e.g. Continue, Shop Now"
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden focus:border-indigo-500 text-xs"
              />
            </div>
          )}

          {('placeholder' in props || ['input', 'search'].includes(element.type)) && (
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Placeholder Text</label>
              <input
                type="text"
                value={props.placeholder || ''}
                onChange={(e) => handlePropChange('placeholder', e.target.value)}
                placeholder="e.g. Type something..."
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden focus:border-indigo-500 text-xs"
              />
            </div>
          )}

          {('label' in props || element.type === 'input') && (
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Field Label</label>
              <input
                type="text"
                value={props.label || ''}
                onChange={(e) => handlePropChange('label', e.target.value)}
                placeholder="e.g. Email Address"
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden focus:border-indigo-500 text-xs"
              />
            </div>
          )}

          {('imageUrl' in props || ['image', 'card'].includes(element.type)) && (
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Image URL</label>
              <input
                type="text"
                value={props.imageUrl || ''}
                onChange={(e) => handlePropChange('imageUrl', e.target.value)}
                placeholder="https://..."
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden focus:border-indigo-500 text-xs"
              />
            </div>
          )}
        </div>

        {/* Styling section */}
        <div className="space-y-3 pt-2 border-t border-neutral-800/80">
          <div className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">Appearance & Theme</div>

          {/* Color Scheme Picker */}
          <div>
            <label className="block text-[11px] text-neutral-400 mb-1.5">Color Palette</label>
            <div className="grid grid-cols-6 gap-1.5">
              {(['indigo', 'emerald', 'rose', 'amber', 'sky', 'purple'] as const).map((col) => (
                <button
                  key={col}
                  onClick={() => handlePropChange('colorScheme', col)}
                  className={`h-7 rounded-md transition flex items-center justify-center ${
                    col === 'indigo'
                      ? 'bg-indigo-600'
                      : col === 'emerald'
                      ? 'bg-emerald-600'
                      : col === 'rose'
                      ? 'bg-rose-600'
                      : col === 'amber'
                      ? 'bg-amber-600'
                      : col === 'sky'
                      ? 'bg-sky-600'
                      : 'bg-purple-600'
                  } ${
                    props.colorScheme === col
                      ? 'ring-2 ring-white ring-offset-2 ring-offset-neutral-900'
                      : 'opacity-70 hover:opacity-100'
                  }`}
                  title={col}
                />
              ))}
            </div>
          </div>

          {/* Alignment */}
          {element.type === 'header' && (
            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Text Alignment</label>
              <div className="flex bg-neutral-950 p-0.5 rounded-lg border border-neutral-800">
                <button
                  onClick={() => handlePropChange('align', 'left')}
                  className={`flex-1 py-1 flex items-center justify-center rounded-sm ${
                    props.align === 'left' || !props.align ? 'bg-neutral-800 text-white' : 'text-neutral-400'
                  }`}
                >
                  <AlignLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handlePropChange('align', 'center')}
                  className={`flex-1 py-1 flex items-center justify-center rounded-sm ${
                    props.align === 'center' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
                  }`}
                >
                  <AlignCenter className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handlePropChange('align', 'right')}
                  className={`flex-1 py-1 flex items-center justify-center rounded-sm ${
                    props.align === 'right' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
                  }`}
                >
                  <AlignRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Tab Items Editor (if tabs) */}
        {element.type === 'tabs' && (
          <div className="space-y-2 pt-2 border-t border-neutral-800/80">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">Tab Items</span>
              <button
                onClick={handleAddTab}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Add Tab</span>
              </button>
            </div>
            {(props.tabs || []).map((tab, idx) => (
              <div key={idx} className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={tab}
                  onChange={(e) => handleTabChange(idx, e.target.value)}
                  className="flex-1 px-2 py-1 bg-neutral-950 border border-neutral-800 rounded text-xs"
                />
                <button
                  onClick={() => handleRemoveTab(idx)}
                  className="p-1 text-neutral-500 hover:text-rose-400"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Items List Editor (for stats or lists) */}
        {['stats', 'list'].includes(element.type) && (
          <div className="space-y-2 pt-2 border-t border-neutral-800/80">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">Items List</span>
              <button
                onClick={handleAddListItem}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Add Item</span>
              </button>
            </div>
            {(props.items || []).map((item, idx) => (
              <div key={item.id || idx} className="p-2 bg-neutral-950 border border-neutral-800 rounded-lg space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-neutral-500 font-mono">Item #{idx + 1}</span>
                  <button
                    onClick={() => handleRemoveListItem(idx)}
                    className="text-neutral-500 hover:text-rose-400 text-xs"
                  >
                    Remove
                  </button>
                </div>
                <input
                  type="text"
                  value={item.title}
                  placeholder="Title"
                  onChange={(e) => handleListItemChange(idx, 'title', e.target.value)}
                  className="w-full px-2 py-1 bg-neutral-900 border border-neutral-800 rounded text-xs"
                />
                {element.type === 'stats' ? (
                  <input
                    type="text"
                    value={item.value || ''}
                    placeholder="Stat Value (e.g. 4.9 or 12k)"
                    onChange={(e) => handleListItemChange(idx, 'value', e.target.value)}
                    className="w-full px-2 py-1 bg-neutral-900 border border-neutral-800 rounded text-xs"
                  />
                ) : (
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={item.subtitle || ''}
                      placeholder="Subtitle"
                      onChange={(e) => handleListItemChange(idx, 'subtitle', e.target.value)}
                      className="flex-1 px-2 py-1 bg-neutral-900 border border-neutral-800 rounded text-xs"
                    />
                    <input
                      type="text"
                      value={item.badge || ''}
                      placeholder="Badge"
                      onChange={(e) => handleListItemChange(idx, 'badge', e.target.value)}
                      className="w-16 px-2 py-1 bg-neutral-900 border border-neutral-800 rounded text-xs"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Action & Navigation Triggers */}
        {['button', 'hero', 'card'].includes(element.type) && (
          <div className="space-y-3 pt-2 border-t border-neutral-800/80">
            <div className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
              <Link2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>Tap Action & Navigation</span>
            </div>

            <div>
              <label className="block text-[11px] text-neutral-400 mb-1">Action Type</label>
              <select
                value={props.actionType || 'none'}
                onChange={(e) => handlePropChange('actionType', e.target.value)}
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden text-xs"
              >
                <option value="none">No Action</option>
                <option value="navigate">Navigate to Page</option>
                <option value="toast">Show Notification Toast</option>
                <option value="alert">Show Alert Message</option>
              </select>
            </div>

            {props.actionType === 'navigate' && (
              <div>
                <label className="block text-[11px] text-neutral-400 mb-1">Target Screen</label>
                <select
                  value={props.targetScreenId || ''}
                  onChange={(e) => handlePropChange('targetScreenId', e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden text-xs"
                >
                  <option value="">Select Screen...</option>
                  {screens.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {(props.actionType === 'toast' || props.actionType === 'alert') && (
              <div>
                <label className="block text-[11px] text-neutral-400 mb-1">Message Text</label>
                <input
                  type="text"
                  value={props.actionMessage || ''}
                  onChange={(e) => handlePropChange('actionMessage', e.target.value)}
                  placeholder="e.g. Added to cart successfully!"
                  className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-neutral-100 focus:outline-hidden text-xs"
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer controls */}
      <div className="p-3 border-t border-neutral-800 flex items-center gap-2">
        <button
          onClick={() => onDuplicate(element.id)}
          className="flex-1 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition"
        >
          <Copy className="w-3 h-3" />
          <span>Duplicate</span>
        </button>
        <button
          onClick={() => onDelete(element.id)}
          className="flex-1 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition"
        >
          <Trash2 className="w-3 h-3" />
          <span>Delete</span>
        </button>
      </div>
    </aside>
  );
};
