import React, { useState } from 'react';
import { X, Plus, Trash2, Edit2, Check, Smartphone } from 'lucide-react';
import { AppScreen } from '../types';

interface ScreensModalProps {
  isOpen: boolean;
  onClose: () => void;
  screens: AppScreen[];
  activeScreenId: string;
  onSelectScreen: (id: string) => void;
  onAddScreen: (name: string, bgColor?: string) => void;
  onRenameScreen: (id: string, newName: string) => void;
  onDeleteScreen: (id: string) => void;
}

export const ScreensModal: React.FC<ScreensModalProps> = ({
  isOpen,
  onClose,
  screens,
  activeScreenId,
  onSelectScreen,
  onAddScreen,
  onRenameScreen,
  onDeleteScreen,
}) => {
  const [newScreenName, setNewScreenName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempName, setTempName] = useState('');

  if (!isOpen) return null;

  const handleAdd = () => {
    if (newScreenName.trim()) {
      onAddScreen(newScreenName.trim(), '#f8fafc');
      setNewScreenName('');
    }
  };

  const handleStartRename = (screen: AppScreen) => {
    setEditingId(screen.id);
    setTempName(screen.name);
  };

  const handleSaveRename = (id: string) => {
    if (tempName.trim()) {
      onRenameScreen(id, tempName.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-lg flex flex-col shadow-2xl overflow-hidden text-neutral-200">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-semibold text-white">Manage Screens & Pages</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Add Screen Input */}
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="New screen name (e.g. Profile, Checkout)..."
              value={newScreenName}
              onChange={(e) => setNewScreenName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
              className="flex-1 px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-100 placeholder:text-neutral-500 focus:outline-hidden focus:border-indigo-500"
            />
            <button
              onClick={handleAdd}
              className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </div>

          {/* Screens List */}
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {screens.map((screen, idx) => {
              const isActive = screen.id === activeScreenId;
              const isEditing = editingId === screen.id;

              return (
                <div
                  key={screen.id}
                  className={`p-3 rounded-xl border flex items-center justify-between transition ${
                    isActive
                      ? 'bg-indigo-950/40 border-indigo-500 text-white'
                      : 'bg-neutral-800/40 border-neutral-800 hover:bg-neutral-800/80 text-neutral-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5 flex-1 min-w-0">
                    <span className="w-5 h-5 rounded-md bg-neutral-900 text-[10px] font-mono flex items-center justify-center text-neutral-400">
                      {idx + 1}
                    </span>

                    {isEditing ? (
                      <div className="flex items-center gap-1.5 flex-1 mr-2">
                        <input
                          type="text"
                          value={tempName}
                          onChange={(e) => setTempName(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleSaveRename(screen.id)}
                          autoFocus
                          className="px-2 py-1 bg-neutral-950 border border-indigo-500 rounded text-xs text-white flex-1"
                        />
                        <button
                          onClick={() => handleSaveRename(screen.id)}
                          className="p-1 text-emerald-400 hover:text-emerald-300"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div 
                        onClick={() => {
                          onSelectScreen(screen.id);
                          onClose();
                        }}
                        className="cursor-pointer flex-1"
                      >
                        <div className="text-xs font-semibold truncate">{screen.name}</div>
                        <div className="text-[10px] text-neutral-400">{screen.elements.length} blocks inserted</div>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    {!isEditing && (
                      <button
                        onClick={() => handleStartRename(screen)}
                        className="p-1.5 text-neutral-400 hover:text-neutral-200 transition"
                        title="Rename Screen"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                    )}
                    {screens.length > 1 && (
                      <button
                        onClick={() => onDeleteScreen(screen.id)}
                        className="p-1.5 text-neutral-400 hover:text-rose-400 transition"
                        title="Delete Screen"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-neutral-800 bg-neutral-900 text-right">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-medium transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
