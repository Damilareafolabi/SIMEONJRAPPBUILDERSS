import React from 'react';
import { Command, FolderKanban, LayoutTemplate, FileCode2, Plus, Sparkles, Sliders } from 'lucide-react';

export type NavTab = 'build' | 'projects' | 'templates' | 'files' | 'canvas';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onNewApp: () => void;
  projectCount: number;
}

export function Sidebar({ activeTab, onSelectTab, onNewApp, projectCount }: SidebarProps) {
  const navItems = [
    { id: 'build' as const, label: 'Build', icon: Command },
    { id: 'projects' as const, label: 'Projects', icon: FolderKanban, badge: projectCount },
    { id: 'templates' as const, label: 'Templates', icon: LayoutTemplate },
    { id: 'files' as const, label: 'Files', icon: FileCode2 },
    { id: 'canvas' as const, label: 'Visual Canvas', icon: Sliders },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col justify-between shrink-0 h-screen select-none sticky top-0">
      <div className="p-4 space-y-6">
        {/* Brand Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-950 text-white flex items-center justify-center font-black text-sm tracking-wider shadow-md">
            SJ
          </div>
          <div>
            <div className="font-bold text-sm tracking-tight text-slate-900 leading-none">Universal App Factory</div>
            <div className="text-[11px] text-slate-500 font-medium mt-1">AI Builder Platform</div>
          </div>
        </div>

        {/* New App Button */}
        <button
          onClick={onNewApp}
          className="w-full bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded-xl py-2 px-3 text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all active:scale-95"
        >
          <Plus size={15} className="text-slate-600" />
          <span>+ New App</span>
        </button>

        {/* Factory Navigation */}
        <div className="space-y-1">
          <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-slate-400">
            Factory
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-slate-100 text-slate-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon size={16} className={isActive ? 'text-indigo-600' : 'text-slate-400'} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.2 rounded-full font-bold">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Status Card */}
      <div className="p-4 border-t border-slate-100">
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-bold text-slate-800">AI Engine</span>
            </div>
            <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider bg-emerald-100 px-1.5 py-0.5 rounded">
              ONLINE
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Connected • Gemini & Local Engine
          </div>
        </div>
      </div>
    </aside>
  );
}
