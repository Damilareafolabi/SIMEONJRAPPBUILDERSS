import React from 'react';
import { ArrowRight, Check, ShieldCheck, Zap, Layers, Globe } from 'lucide-react';

export function StrategySection({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <div className="max-w-4xl mx-auto w-full pt-16 pb-12 space-y-16 text-center">
      {/* Platform Strategy */}
      <div className="space-y-4">
        <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
          Commercial Platform Strategy
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Built once. Productized deeply. Sold broadly.
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 text-left">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-2">
            <div className="text-xs font-bold text-slate-400">01</div>
            <h3 className="font-bold text-base text-slate-900">Universal output</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Build web apps, desktop software, APKs, mobile apps, and premium AI products from one natural-language workflow.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-2">
            <div className="text-xs font-bold text-slate-400">02</div>
            <h3 className="font-bold text-base text-slate-900">High-end product power</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Create trading platforms, social apps, fintech dashboards, AI assistants, and multi-app ecosystems with production-grade architecture.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-2">
            <div className="text-xs font-bold text-slate-400">03</div>
            <h3 className="font-bold text-base text-slate-900">Commercial ready</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Designed for real customers, brands, and white-label deployments across SaaS, enterprise, and private deployment models.
            </p>
          </div>
        </div>
      </div>

      {/* Local-first Advantage */}
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 text-white rounded-3xl p-8 sm:p-12 shadow-xl space-y-4">
        <div className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">
          Local-First Advantage
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          No mandatory AI credit model by default.
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto leading-relaxed">
          Customers run their app factory on local AI infrastructure, with optional cloud AI integrations only when they choose to add them.
        </p>

        <div className="pt-6 grid grid-cols-2 sm:grid-cols-5 gap-3 text-center border-t border-slate-800">
          {[
            { step: '1', title: 'Describe app' },
            { step: '2', title: 'AI generates app' },
            { step: '3', title: 'Preview live build' },
            { step: '4', title: 'Test and fix' },
            { step: '5', title: 'Export / deploy' },
          ].map((item) => (
            <div key={item.step} className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/50">
              <div className="text-indigo-400 text-xs font-bold">{item.step}</div>
              <div className="text-xs font-semibold text-white mt-0.5">{item.title}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Deployment Packaging */}
      <div className="space-y-4">
        <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
          Commercial Models
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Flexible packaging for every deployment.
        </h2>

        <div className="flex flex-wrap justify-center gap-2 max-w-2xl mx-auto pt-2">
          {['Web app', 'Desktop software', 'Mobile app', 'APK build', 'White-label', 'Enterprise platform'].map((m) => (
            <span
              key={m}
              className="bg-white border border-slate-200 text-slate-800 text-xs font-semibold px-4 py-2 rounded-xl shadow-2xs"
            >
              {m}
            </span>
          ))}
        </div>

        <div className="pt-4">
          <button
            onClick={onGetStarted}
            className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold uppercase tracking-wider px-6 py-3 rounded-xl shadow-md transition-all active:scale-95"
          >
            Start Building with Prompt Engine →
          </button>
        </div>
      </div>
    </div>
  );
}
