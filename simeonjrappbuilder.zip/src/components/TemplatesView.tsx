import React from 'react';
import { LayoutTemplate, Sparkles, ArrowRight, Zap } from 'lucide-react';
import { APP_PRESETS } from '../data/appPresets';
import { GeneratedApp } from '../types/promptBuilder';

interface TemplatesViewProps {
  onSelectTemplate: (app: GeneratedApp) => void;
}

export function TemplatesView({ onSelectTemplate }: TemplatesViewProps) {
  const templatesList = Object.values(APP_PRESETS);

  return (
    <div className="max-w-6xl mx-auto w-full space-y-6">
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl font-bold text-slate-900">Pre-Architected Universal Templates</h1>
        <p className="text-xs text-slate-500">
          Battle-tested production foundations built for high-throughput commercial deployment.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templatesList.map((tmpl) => (
          <div
            key={tmpl.id}
            className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs hover:border-indigo-400 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] bg-slate-100 text-slate-700 font-bold px-2.5 py-0.5 rounded-full">
                  {tmpl.category}
                </span>
                <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                  <Zap size={13} fill="currentColor" /> Ready
                </span>
              </div>

              <h3 className="font-bold text-lg text-slate-900">{tmpl.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{tmpl.description}</p>

              <div className="bg-slate-50 border border-slate-100 p-3 rounded-2xl text-[11px] text-slate-500 font-mono">
                Prompt: "{tmpl.prompt}"
              </div>
            </div>

            <div className="pt-6">
              <button
                onClick={() => onSelectTemplate(tmpl)}
                className="w-full bg-slate-900 hover:bg-indigo-600 text-white text-xs font-bold py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              >
                <span>Use Template in Studio</span>
                <ArrowRight size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
