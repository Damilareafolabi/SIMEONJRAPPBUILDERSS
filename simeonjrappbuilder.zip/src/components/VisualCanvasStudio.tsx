import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './Navbar';
import { ComponentCatalog } from './ComponentCatalog';
import { Canvas } from './Canvas';
import { PropertyInspector } from './PropertyInspector';
import { CodeExportModal } from './CodeExportModal';
import { ScreensModal } from './ScreensModal';
import { AppProject, AppElement, ElementType, DeviceType, AppScreen } from '../types';
import { STARTER_TEMPLATES } from '../templates';
import { Sparkles } from 'lucide-react';

export function VisualCanvasStudio() {
  const [project, setProject] = useState<AppProject>(() => {
    try {
      const saved = localStorage.getItem('simeonjr_app_builder_project');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return STARTER_TEMPLATES.ecommerce;
  });

  const [history, setHistory] = useState<{ past: AppProject[]; future: AppProject[] }>({
    past: [],
    future: [],
  });

  const [activeDevice, setActiveDevice] = useState<DeviceType>('mobile');
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [isScreensOpen, setIsScreensOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('simeonjr_app_builder_project', JSON.stringify(project));
    } catch {
      // ignore
    }
  }, [project]);

  const commitProjectState = useCallback((updater: (prev: AppProject) => AppProject) => {
    setProject((current) => {
      const next = updater(current);
      setHistory((h) => ({
        past: [...h.past.slice(-20), current],
        future: [],
      }));
      return next;
    });
  }, []);

  const handleUndo = useCallback(() => {
    setHistory((h) => {
      if (h.past.length === 0) return h;
      const previous = h.past[h.past.length - 1];
      const newPast = h.past.slice(0, h.past.length - 1);
      setProject(previous);
      return {
        past: newPast,
        future: [project, ...h.future],
      };
    });
  }, [project]);

  const handleRedo = useCallback(() => {
    setHistory((h) => {
      if (h.future.length === 0) return h;
      const next = h.future[0];
      const newFuture = h.future.slice(1);
      setProject(next);
      return {
        past: [...h.past, project],
        future: newFuture,
      };
    });
  }, [project]);

  const activeScreen = project.screens.find((s) => s.id === project.activeScreenId) || project.screens[0];
  const selectedElement = activeScreen?.elements.find((el) => el.id === selectedElementId) || null;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleAddElement = (type: ElementType) => {
    const newId = `${type}-${Date.now().toString(36)}`;
    let defaultProps: AppElement['props'] = {
      colorScheme: 'indigo',
    };

    switch (type) {
      case 'header':
        defaultProps = {
          title: 'Section Header',
          subtitle: 'Descriptive subtitle or category overview',
          align: 'left',
          colorScheme: 'indigo',
        };
        break;
      case 'hero':
        defaultProps = {
          title: 'Discover Next Generation Quality',
          subtitle: 'Join thousands of creators crafting with Universal App Factory.',
          buttonText: 'Get Started Now',
          colorScheme: 'indigo',
          actionType: 'toast',
          actionMessage: 'Action triggered from Hero banner!',
          borderRadius: 'xl',
        };
        break;
      case 'card':
        defaultProps = {
          title: 'Featured Item',
          subtitle: 'High-performance components ready for deployment',
          content: 'Flexible modular layouts designed for reactive real-time experiences.',
          buttonText: 'Learn More',
          colorScheme: 'indigo',
          borderRadius: 'lg',
        };
        break;
      case 'button':
        defaultProps = {
          buttonText: 'Click Action',
          colorScheme: 'indigo',
          variant: 'solid',
          borderRadius: 'lg',
          actionType: 'toast',
          actionMessage: 'Button action executed!',
        };
        break;
      case 'search':
        defaultProps = {
          placeholder: 'Search resources, products, documentation...',
          borderRadius: 'lg',
        };
        break;
      case 'input':
        defaultProps = {
          label: 'Email Address',
          placeholder: 'user@example.com',
          borderRadius: 'lg',
        };
        break;
      case 'stats':
        defaultProps = {
          items: [
            { id: '1', title: 'Active Users', value: '28.4K', badge: '+12%' },
            { id: '2', title: 'Latency', value: '18ms', badge: 'Fast' },
            { id: '3', title: 'Uptime', value: '99.98%', badge: 'Operational' },
          ],
        };
        break;
      case 'tabs':
        defaultProps = {
          tabs: ['Overview', 'Analytics', 'Settings', 'API'],
          activeTabIndex: 0,
          colorScheme: 'indigo',
        };
        break;
      case 'toggle':
        defaultProps = {
          label: 'Enable Real-time Cloud Sync',
          checked: true,
          colorScheme: 'indigo',
        };
        break;
      default:
        defaultProps = {
          title: 'New Component',
          colorScheme: 'indigo',
        };
    }

    const newElement: AppElement = {
      id: newId,
      type,
      name: `${type.charAt(0).toUpperCase() + type.slice(1)} Block`,
      props: defaultProps,
    };

    commitProjectState((prev) => {
      const screens = prev.screens.map((s) => {
        if (s.id === prev.activeScreenId) {
          return {
            ...s,
            elements: [...s.elements, newElement],
          };
        }
        return s;
      });
      return { ...prev, screens, updatedAt: Date.now() };
    });

    setSelectedElementId(newId);
    showToast(`Added ${type} component`);
  };

  const handleUpdateElementProps = (elementId: string, props: Partial<AppElement['props']>) => {
    commitProjectState((prev) => {
      const screens = prev.screens.map((s) => {
        if (s.id === prev.activeScreenId) {
          return {
            ...s,
            elements: s.elements.map((el) => {
              if (el.id === elementId) {
                return {
                  ...el,
                  props: { ...el.props, ...props },
                };
              }
              return el;
            }),
          };
        }
        return s;
      });
      return { ...prev, screens, updatedAt: Date.now() };
    });
  };

  const handleUpdateElementName = (elementId: string, name: string) => {
    commitProjectState((prev) => {
      const screens = prev.screens.map((s) => {
        if (s.id === prev.activeScreenId) {
          return {
            ...s,
            elements: s.elements.map((el) => (el.id === elementId ? { ...el, name } : el)),
          };
        }
        return s;
      });
      return { ...prev, screens, updatedAt: Date.now() };
    });
  };

  const handleDeleteElement = (id: string) => {
    commitProjectState((prev) => {
      const screens = prev.screens.map((s) => {
        if (s.id === prev.activeScreenId) {
          return {
            ...s,
            elements: s.elements.filter((el) => el.id !== id),
          };
        }
        return s;
      });
      return { ...prev, screens, updatedAt: Date.now() };
    });
    if (selectedElementId === id) {
      setSelectedElementId(null);
    }
    showToast('Element deleted');
  };

  const handleDuplicateElement = (id: string) => {
    const toDup = activeScreen.elements.find((el) => el.id === id);
    if (!toDup) return;

    const copyId = `${toDup.type}-${Date.now().toString(36)}`;
    const copyElement: AppElement = {
      ...toDup,
      id: copyId,
      name: `${toDup.name} (Copy)`,
      props: { ...toDup.props },
    };

    const index = activeScreen.elements.findIndex((el) => el.id === id);
    commitProjectState((prev) => {
      const screens = prev.screens.map((s) => {
        if (s.id === prev.activeScreenId) {
          const newElements = [...s.elements];
          newElements.splice(index + 1, 0, copyElement);
          return { ...s, elements: newElements };
        }
        return s;
      });
      return { ...prev, screens, updatedAt: Date.now() };
    });

    setSelectedElementId(copyId);
    showToast('Element duplicated');
  };

  const handleMoveElement = (id: string, direction: 'up' | 'down') => {
    const idx = activeScreen.elements.findIndex((el) => el.id === id);
    if (idx === -1) return;
    if (direction === 'up' && idx === 0) return;
    if (direction === 'down' && idx === activeScreen.elements.length - 1) return;

    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    commitProjectState((prev) => {
      const screens = prev.screens.map((s) => {
        if (s.id === prev.activeScreenId) {
          const newElements = [...s.elements];
          const [moved] = newElements.splice(idx, 1);
          newElements.splice(targetIdx, 0, moved);
          return { ...s, elements: newElements };
        }
        return s;
      });
      return { ...prev, screens, updatedAt: Date.now() };
    });
  };

  const handleSelectScreen = (screenId: string) => {
    commitProjectState((prev) => ({ ...prev, activeScreenId: screenId }));
    setSelectedElementId(null);
  };

  const handleAddScreen = (name?: string, bgColor?: string) => {
    const newScreenId = `screen-${Date.now().toString(36)}`;
    const newScreen: AppScreen = {
      id: newScreenId,
      name: name || `Screen ${project.screens.length + 1}`,
      bgColor: bgColor || '#f8fafc',
      elements: [
        {
          id: `hdr-${Date.now().toString(36)}`,
          type: 'header',
          name: 'Screen Header',
          props: {
            title: name || `New Screen`,
            subtitle: 'Start dragging UI elements to build this view',
            colorScheme: 'indigo',
          },
        },
      ],
    };

    commitProjectState((prev) => ({
      ...prev,
      screens: [...prev.screens, newScreen],
      activeScreenId: newScreenId,
      updatedAt: Date.now(),
    }));

    showToast(`Created screen "${newScreen.name}"`);
  };

  const handleRenameScreen = (screenId: string, newName: string) => {
    commitProjectState((prev) => ({
      ...prev,
      screens: prev.screens.map((s) => (s.id === screenId ? { ...s, name: newName } : s)),
      updatedAt: Date.now(),
    }));
  };

  const handleDeleteScreen = (screenId: string) => {
    if (project.screens.length <= 1) {
      showToast('Cannot delete the last remaining screen');
      return;
    }
    commitProjectState((prev) => {
      const newScreens = prev.screens.filter((s) => s.id !== screenId);
      const newActive = prev.activeScreenId === screenId ? newScreens[0].id : prev.activeScreenId;
      return {
        ...prev,
        screens: newScreens,
        activeScreenId: newActive,
        updatedAt: Date.now(),
      };
    });
    showToast('Screen deleted');
  };

  const handleSelectTemplate = (templateKey: string) => {
    const tmpl = STARTER_TEMPLATES[templateKey];
    if (tmpl) {
      commitProjectState(() => tmpl);
      setSelectedElementId(null);
      showToast(`Loaded template: ${tmpl.name}`);
    }
  };

  return (
    <div className="h-full w-full flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden font-sans">
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-neutral-900/95 border border-neutral-700/80 text-white text-xs px-4 py-2 rounded-full shadow-2xl flex items-center gap-2 backdrop-blur-md">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      <Navbar
        project={project}
        activeDevice={activeDevice}
        onDeviceChange={setActiveDevice}
        previewMode={previewMode}
        onTogglePreview={() => {
          setPreviewMode(!previewMode);
          if (!previewMode) setSelectedElementId(null);
        }}
        onOpenExport={() => setIsExportOpen(true)}
        onOpenScreens={() => setIsScreensOpen(true)}
        onSelectTemplate={handleSelectTemplate}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={history.past.length > 0}
        canRedo={history.future.length > 0}
        onUpdateProjectName={(name) => commitProjectState((p) => ({ ...p, name }))}
        onDownloadProject={() => {
          const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(project, null, 2));
          const a = document.createElement('a');
          a.href = dataStr;
          a.download = `${project.name.toLowerCase().replace(/\s+/g, '-')}-project.json`;
          a.click();
          showToast('Project downloaded');
        }}
        onImportProject={(file) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            try {
              const parsed = JSON.parse(e.target?.result as string);
              if (parsed.screens && parsed.activeScreenId) {
                commitProjectState(() => parsed);
                showToast('Project loaded successfully!');
              }
            } catch {
              showToast('Failed to parse project JSON');
            }
          };
          reader.readAsText(file);
        }}
      />

      <div className="flex-1 flex overflow-hidden relative">
        {!previewMode && (
          <ComponentCatalog
            screens={project.screens}
            activeScreenId={project.activeScreenId}
            onSelectScreen={handleSelectScreen}
            onAddScreen={() => handleAddScreen()}
            onAddElement={handleAddElement}
          />
        )}

        <Canvas
          screen={activeScreen}
          selectedElementId={selectedElementId}
          onSelectElement={setSelectedElementId}
          onMoveElement={handleMoveElement}
          onDuplicateElement={handleDuplicateElement}
          onDeleteElement={handleDeleteElement}
          onAddElement={handleAddElement}
          activeDevice={activeDevice}
          previewMode={previewMode}
          onNavigateScreen={handleSelectScreen}
          onTriggerToast={showToast}
        />

        {!previewMode && (
          <PropertyInspector
            element={selectedElement}
            screens={project.screens}
            onUpdateElementProps={handleUpdateElementProps}
            onUpdateElementName={handleUpdateElementName}
            onClose={() => setSelectedElementId(null)}
            onDuplicate={handleDuplicateElement}
            onDelete={handleDeleteElement}
          />
        )}
      </div>

      <CodeExportModal
        project={project}
        activeScreen={activeScreen}
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />

      <ScreensModal
        isOpen={isScreensOpen}
        onClose={() => setIsScreensOpen(false)}
        screens={project.screens}
        activeScreenId={project.activeScreenId}
        onSelectScreen={handleSelectScreen}
        onAddScreen={(name, bgColor) => handleAddScreen(name, bgColor)}
        onRenameScreen={handleRenameScreen}
        onDeleteScreen={handleDeleteScreen}
      />
    </div>
  );
}
