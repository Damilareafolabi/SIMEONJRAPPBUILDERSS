import React from 'react';
import { CheckCircle2, FileCode, RefreshCw, Folder, Layers, Sparkles, Terminal, Code2 } from 'lucide-react';
import { AgentActivityStep, AppFile } from '../types/promptBuilder';

interface WorkspaceColumnsProps {
  agentSteps: AgentActivityStep[];
  isGenerating: boolean;
  files: AppFile[];
  activeFile: AppFile | null;
  onSelectFile: (file: AppFile) => void;
  onRefreshPreview: () => void;
  onStartAnother: () => void;
  previewDevice: string;
}

export function WorkspaceColumns({
  agentSteps,
  isGenerating,
  files,
  activeFile,
  onSelectFile,
  onRefreshPreview,
  onStartAnother,
  previewDevice,
}: WorkspaceColumnsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-6xl mx-auto w-full pt-6">
      {/* Column 1: AGENT ACTIVITY */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs flex flex-col justify-between min-h-[290px]">
        <div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Agent Activity
            </span>
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>{isGenerating ? 'BUILDING' : 'READY'}</span>
            </div>
          </div>

          <h3 className="text-xl font-bold text-slate-900 mb-3">
            {isGenerating ? 'Synthesizing App...' : 'Ready'}
          </h3>

          <div className="space-y-2.5 text-xs">
            {agentSteps.map((step) => (
              <div key={step.id} className="flex items-center gap-2 text-slate-600">
                <div className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 ${
                  step.status === 'completed' ? 'text-emerald-600' : step.status === 'active' ? 'text-indigo-600 animate-spin' : 'text-slate-300'
                }`}>
                  {step.status === 'active' ? (
                    <RefreshCw size={12} />
                  ) : (
                    <CheckCircle2 size={13} fill="currentColor" className="text-emerald-500 text-white" />
                  )}
                </div>
                <span className={step.status === 'active' ? 'font-bold text-indigo-600' : ''}>
                  {step.title}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-[11px] text-slate-400 pt-3 border-t border-slate-100 mt-4">
          Universal multi-agent runtime
        </div>
      </div>

      {/* Column 2: PROJECT FILES */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs flex flex-col justify-between min-h-[290px]">
        <div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Project
            </span>
            <span className="text-xs bg-slate-100 text-slate-700 font-bold px-2 py-0.5 rounded-full">
              {files.length}
            </span>
          </div>

          <h3 className="text-xl font-bold text-slate-900 mb-3">
            Files
          </h3>

          {files.length === 0 ? (
            <div className="py-8 text-center space-y-2 text-slate-400">
              <div className="w-10 h-10 mx-auto rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-300">
                <FileCode size={20} />
              </div>
              <div className="text-xs font-semibold text-slate-600">No application generated yet</div>
              <p className="text-[11px] text-slate-400">Your generated project files will appear here.</p>
            </div>
          ) : (
            <div className="space-y-1.5 overflow-y-auto max-h-[160px] pr-1 text-xs">
              {files.map((f) => (
                <button
                  key={f.path}
                  onClick={() => onSelectFile(f)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-left transition-colors ${
                    activeFile?.path === f.path ? 'bg-indigo-50 text-indigo-700 font-bold' : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className="flex items-center gap-2 truncate">
                    <FileCode size={13} className="text-indigo-500 shrink-0" />
                    <span className="truncate">{f.name}</span>
                  </span>
                  {f.size && <span className="text-[10px] text-slate-400">{f.size}</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        {files.length > 0 && (
          <div className="text-[11px] text-indigo-600 font-medium pt-3 border-t border-slate-100 cursor-pointer hover:underline">
            Click any file to inspect code
          </div>
        )}
      </div>

      {/* Column 3: BUILDER TOOLS */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs flex flex-col justify-between min-h-[290px]">
        <div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Builder Tools
            </span>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full uppercase tracking-wider">
              LOCAL
            </span>
          </div>

          <h3 className="text-xl font-bold text-slate-900 mb-3">
            Workspace
          </h3>

          <div className="space-y-2 text-xs divide-y divide-slate-100">
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Runtime</span>
              <span className="font-bold text-slate-800">Vite + React</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Engine</span>
              <span className="font-bold text-slate-800">APPMORA Local AST • No Key Needed</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Preview</span>
              <span className="font-bold text-slate-800 capitalize">{previewDevice}</span>
            </div>
          </div>
        </div>

        {/* Runtime Scanner */}
        <div className="pt-3 border-t border-slate-100 space-y-2">
          <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-2 text-center text-[10px] font-bold text-slate-500 uppercase tracking-wider">
            {isGenerating ? 'Compiling Live Preview...' : 'Preview Verification Healthy'}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onRefreshPreview}
              className="py-2 px-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold text-center transition-colors"
            >
              Refresh preview
            </button>
            <button
              onClick={onStartAnother}
              className="py-2 px-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold text-center transition-colors"
            >
              Start another app
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
