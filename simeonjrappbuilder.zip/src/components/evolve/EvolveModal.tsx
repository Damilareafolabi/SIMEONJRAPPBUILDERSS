import React, { useState } from 'react';
import { 
  Sparkles, RefreshCw, CheckCircle2, ArrowRight, Zap, 
  ShieldAlert, Layout, Smartphone, Code2, Search, 
  Eye, Database, TrendingUp, X, CheckSquare, Square
} from 'lucide-react';
import { EvolveRecommendation } from '../../types/promptBuilder';

interface EvolveModalProps {
  isOpen: boolean;
  onClose: () => void;
  appName?: string;
  onApplyRecommendations: (recommendationIds: string[]) => void;
  isApplying?: boolean;
}

const DEFAULT_RECOMMENDATIONS: EvolveRecommendation[] = [
  {
    id: 'evo-1',
    category: 'Performance',
    title: 'Code Splitting & Dynamic Imports for Preview Bundle',
    description: 'Deconstruct oversized entry chunk into route-based async chunks. Cuts first-load JS payload from 480KB to 160KB.',
    impact: 'High',
    effort: 'Low',
    selected: true,
  },
  {
    id: 'evo-2',
    category: 'Security',
    title: 'CSP Headers & Strict Sanitization Guard',
    description: 'Enforce nonces on script execution and sanitize all dynamic user markup to eliminate XSS surface.',
    impact: 'High',
    effort: 'Low',
    selected: true,
  },
  {
    id: 'evo-3',
    category: 'UX',
    title: 'Optimistic UI Updates & Skeleton Shimmer Transitions',
    description: 'Replace abrupt spinner pauses with fluid skeleton loading states and instant optimistic list mutations.',
    impact: 'Medium',
    effort: 'Medium',
    selected: true,
  },
  {
    id: 'evo-4',
    category: 'Mobile',
    title: 'Touch-Target Expansion & PWA Offline Manifest',
    description: 'Scale mobile tap targets to 44x44px minimum, add service worker caching for offline access, and link manifest.webmanifest.',
    impact: 'High',
    effort: 'Medium',
    selected: true,
  },
  {
    id: 'evo-5',
    category: 'Refactor',
    title: 'State Decoupling & Modular Hook Architecture',
    description: 'Extract business logic from monolithic components into focused custom React hooks and domain stores.',
    impact: 'Medium',
    effort: 'Low',
    selected: false,
  },
  {
    id: 'evo-6',
    category: 'Missing Features',
    title: 'Universal Keyboard Shortcuts & Command Palette',
    description: 'Add Cmd+K quick launcher, arrow navigation, and ESC modal dismissals for power user efficiency.',
    impact: 'Medium',
    effort: 'Low',
    selected: true,
  },
  {
    id: 'evo-7',
    category: 'SEO',
    title: 'Dynamic OpenGraph & Structured Schema Metadata',
    description: 'Inject OpenGraph tags, Twitter cards, and JSON-LD schema for rich search snippet indexing.',
    impact: 'Low',
    effort: 'Low',
    selected: false,
  },
  {
    id: 'evo-8',
    category: 'Accessibility',
    title: 'WCAG AA Contrast Audit & ARIA Landmark Roles',
    description: 'Ensure 4.5:1 text-to-canvas contrast ratio, proper focus rings, and screen-reader navigable headings.',
    impact: 'Medium',
    effort: 'Low',
    selected: true,
  },
  {
    id: 'evo-9',
    category: 'Database',
    title: 'Index Optimization & IndexedDB Client Caching',
    description: 'Add composite indexes for frequently sorted queries and local cache for instant warm restarts.',
    impact: 'High',
    effort: 'Medium',
    selected: false,
  },
  {
    id: 'evo-10',
    category: 'Conversion',
    title: 'Frictionless One-Click Checkout & Value Indicators',
    description: 'Streamline signup and conversion flow by removing unnecessary form steps and displaying security badges.',
    impact: 'High',
    effort: 'Medium',
    selected: true,
  },
];

export function EvolveModal({
  isOpen,
  onClose,
  appName = 'Active Application',
  onApplyRecommendations,
  isApplying = false,
}: EvolveModalProps) {
  const [recommendations, setRecommendations] = useState<EvolveRecommendation[]>(DEFAULT_RECOMMENDATIONS);
  const [activeFilter, setActiveFilter] = useState<string>('all');

  if (!isOpen) return null;

  const toggleSelect = (id: string) => {
    setRecommendations((prev) =>
      prev.map((r) => (r.id === id ? { ...r, selected: !r.selected } : r))
    );
  };

  const selectAll = () => {
    setRecommendations((prev) => prev.map((r) => ({ ...r, selected: true })));
  };

  const deselectAll = () => {
    setRecommendations((prev) => prev.map((r) => ({ ...r, selected: false })));
  };

  const selectedCount = recommendations.filter((r) => r.selected).length;

  const handleApply = () => {
    const selectedIds = recommendations.filter((r) => r.selected).map((r) => r.id);
    onApplyRecommendations(selectedIds);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Performance': return Zap;
      case 'Security': return ShieldAlert;
      case 'UX': return Layout;
      case 'Mobile': return Smartphone;
      case 'Refactor': return Code2;
      case 'Missing Features': return Sparkles;
      case 'SEO': return Search;
      case 'Accessibility': return Eye;
      case 'Database': return Database;
      case 'Conversion': return TrendingUp;
      default: return Sparkles;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8 animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                APPMORA Evolution Engine
              </span>
              <span className="text-xs text-slate-400 font-mono">{appName}</span>
            </div>
            <h2 className="text-2xl font-black text-slate-950 tracking-tight flex items-center gap-2">
              <RefreshCw className="text-indigo-600 w-6 h-6" />
              <span>Continuous App Evolution</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Never abandon your software after generation. Inspect code, UX, performance, and security to evolve it continuously.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Action / Selection summary bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200/80 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">{selectedCount} of {recommendations.length} Selected</span>
            <button
              onClick={selectAll}
              className="text-indigo-600 hover:text-indigo-800 font-semibold underline decoration-dotted"
            >
              Select All
            </button>
            <span className="text-slate-300">•</span>
            <button
              onClick={deselectAll}
              className="text-slate-500 hover:text-slate-700 font-medium"
            >
              Deselect All
            </button>
          </div>

          <button
            onClick={handleApply}
            disabled={isApplying || selectedCount === 0}
            className="px-4 py-2 bg-slate-900 hover:bg-black disabled:opacity-40 text-white font-bold rounded-xl flex items-center gap-2 shadow-xs transition active:scale-95"
          >
            {isApplying ? (
              <>
                <RefreshCw size={13} className="animate-spin" />
                <span>Applying Evolution Upgrades...</span>
              </>
            ) : (
              <>
                <span>Apply Selected Upgrades ({selectedCount})</span>
                <ArrowRight size={13} />
              </>
            )}
          </button>
        </div>

        {/* 10 Evolution Category Recommendations */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[460px] overflow-y-auto pr-1">
          {recommendations.map((rec) => {
            const Icon = getCategoryIcon(rec.category);
            return (
              <div
                key={rec.id}
                onClick={() => toggleSelect(rec.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer text-left space-y-2 ${
                  rec.selected
                    ? 'bg-indigo-50/40 border-indigo-300 shadow-2xs ring-1 ring-indigo-400/30'
                    : 'bg-white border-slate-200/80 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
                    <Icon size={15} className={rec.selected ? 'text-indigo-600' : 'text-slate-500'} />
                    <span>{rec.title}</span>
                  </div>
                  <div className="shrink-0 text-slate-400">
                    {rec.selected ? (
                      <CheckCircle2 size={16} className="text-indigo-600" />
                    ) : (
                      <Square size={16} className="text-slate-300" />
                    )}
                  </div>
                </div>

                <p className="text-[11px] text-slate-600 leading-relaxed">
                  {rec.description}
                </p>

                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    {rec.category}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    rec.impact === 'High' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {rec.impact} Impact
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Effort: {rec.effort}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
