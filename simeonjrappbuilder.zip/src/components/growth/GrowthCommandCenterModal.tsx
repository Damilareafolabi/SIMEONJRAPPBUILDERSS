import React, { useState } from 'react';
import { 
  TrendingUp, Users, Target, Send, MessageSquare, 
  DollarSign, Search, CheckCircle, Copy, X, ShieldAlert, 
  Lightbulb, Share2, FileText, ArrowRight
} from 'lucide-react';
import { GrowthPlanData } from '../../types/promptBuilder';

interface GrowthCommandCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  appName?: string;
  appDescription?: string;
}

export function GrowthCommandCenterModal({
  isOpen,
  onClose,
  appName = 'ApexTrade Universal Terminal',
  appDescription = 'Algorithmic trading platform with depth charts, live order books, and real-time execution.',
}: GrowthCommandCenterModalProps) {
  const [activeTab, setActiveTab] = useState<'icp' | 'launch' | 'messaging' | 'channels' | 'pricing' | 'compliance'>('icp');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                APPMORA Growth Engine
              </span>
              <span className="text-xs text-slate-400 font-mono">{appName}</span>
            </div>
            <h2 className="text-2xl font-black text-slate-950 tracking-tight flex items-center gap-2">
              <TrendingUp className="text-emerald-600 w-6 h-6" />
              <span>Growth Command Center</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Transform your software into a viable commercial business with strategic customer discovery, launch playbooks, and compliant distribution.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 border-b border-slate-100 pb-2 overflow-x-auto">
          {[
            { id: 'icp', label: '1. Ideal Customer Profiles (ICP)', icon: Target },
            { id: 'messaging', label: '2. Value Messaging & Outreaches', icon: MessageSquare },
            { id: 'launch', label: '3. Launch Playbooks', icon: Share2 },
            { id: 'channels', label: '4. Distribution Channels', icon: Users },
            { id: 'pricing', label: '5. Monetization & Pricing', icon: DollarSign },
            { id: 'compliance', label: 'Compliance & Ethics Guard', icon: ShieldAlert },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Icon size={14} className={isActive ? 'text-emerald-400' : 'text-slate-400'} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Panels */}
        <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1">
          {activeTab === 'icp' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-left">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                  Primary ICP: Professional Algo Traders & Quant Funds
                </span>
                <h4 className="font-bold text-sm text-slate-900">Quantitative Strategy Developers</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Requires low-latency execution, real-time WebSocket depth updates, and customizable risk parameter thresholds without vendor lock-in.
                </p>
                <div className="text-[11px] text-slate-500 font-mono pt-1">
                  Pain point: Clunky legacy terminals with high fees and slow API streaming.
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="text-[10px] uppercase font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded">
                  Secondary ICP: Active Retail Momentum Traders
                </span>
                <h4 className="font-bold text-sm text-slate-900">High-Volume Retail Investors</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Looking for institutional-grade depth visualization and seamless account switching across crypto and equity accounts in one browser tab.
                </p>
                <div className="text-[11px] text-slate-500 font-mono pt-1">
                  Pain point: Fragmented accounts across 4 different exchanges.
                </div>
              </div>
            </div>
          )}

          {activeTab === 'messaging' && (
            <div className="space-y-3 text-left">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900">
                    Direct Founder-to-Customer Discovery Outreach (Draft Template)
                  </h4>
                  <button
                    onClick={() => handleCopy('msg-1', `Hey {{Name}},\n\nI built a low-latency trading terminal that unifies multi-exchange depth charts and local execution without monthly subscription overhead. Not selling anything—would love to get your honest feedback on whether this solves your multi-account workflow friction.\n\nBest,\nFounder, ${appName}`)}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                  >
                    <Copy size={13} />
                    <span>{copiedId === 'msg-1' ? 'Copied!' : 'Copy Template'}</span>
                  </button>
                </div>
                <div className="bg-white p-3 rounded-xl border border-slate-200 font-mono text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
{`Hey {{Name}},

I built a low-latency trading terminal that unifies multi-exchange depth charts and local execution without monthly subscription overhead. Not selling anything—would love to get your honest feedback on whether this solves your multi-account workflow friction.

Best,
Founder, ${appName}`}
                </div>
                <div className="text-[10px] text-slate-500">
                  Notice: APPMORA provides human-reviewed drafts. Never send unsolicited automated spam.
                </div>
              </div>
            </div>
          )}

          {activeTab === 'launch' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-left">
              {[
                { platform: 'Product Hunt', strategy: 'Highlight universal local-first architecture and instant preview sandbox.', timing: 'Tuesday 12:01 AM PST' },
                { platform: 'Hacker News (Show HN)', strategy: 'Focus on zero external AI keys required, AST parser, and local build correctness.', timing: 'Wednesday 9:00 AM EST' },
                { platform: 'Reddit (/r/webdev, /r/algotrading)', strategy: 'Share open architecture diagram and technical benchmark comparisons.', timing: 'Thursday 11:00 AM EST' },
                { platform: 'LinkedIn Tech Thought Leadership', strategy: 'Case study on moving from mockup generation to real validated production deployments.', timing: 'Weekly Monday' },
              ].map((item) => (
                <div key={item.platform} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <span className="font-bold text-xs text-slate-900">{item.platform}</span>
                  <p className="text-xs text-slate-600 leading-relaxed">{item.strategy}</p>
                  <div className="text-[11px] text-indigo-600 font-medium pt-1">
                    Optimal Window: {item.timing}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'channels' && (
            <div className="space-y-3 text-left">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-900">
                  Organic Inbound & Technical SEO Architecture
                </h4>
                <ul className="list-disc list-inside text-xs text-slate-600 space-y-1 leading-relaxed">
                  <li>Programmatic landing pages for trading pairs and exchange comparisons.</li>
                  <li>Developer documentation with interactive API playgrounds.</li>
                  <li>GitHub Open Source core client with commercial hosted backend upgrades.</li>
                  <li>Direct Discord and Telegram community for algorithmic strategy authors.</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'pricing' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-left">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-xs font-bold text-slate-900">Free / Community</div>
                <div className="text-xl font-black text-slate-950">$0</div>
                <p className="text-[11px] text-slate-600">Local terminal, standard order routing, community indicators.</p>
              </div>

              <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-200 space-y-2">
                <div className="text-xs font-bold text-indigo-900">Pro Algorithmic</div>
                <div className="text-xl font-black text-indigo-950">$49<span className="text-xs text-slate-500">/mo</span></div>
                <p className="text-[11px] text-slate-600">Sub-millisecond WebSocket data feed, multi-account routing, priority order priority.</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-xs font-bold text-slate-900">Institutional</div>
                <div className="text-xl font-black text-slate-950">$499<span className="text-xs text-slate-500">/mo</span></div>
                <p className="text-[11px] text-slate-600">Dedicated colocation proxy, custom FIX API bridge, multi-seat audit trails.</p>
              </div>
            </div>
          )}

          {activeTab === 'compliance' && (
            <div className="p-5 rounded-2xl bg-emerald-50/50 border border-emerald-200 space-y-3 text-left">
              <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                <ShieldAlert size={18} className="text-emerald-700" />
                <span>APPMORA Compliance-First Policy</span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">
                APPMORA is strictly committed to legal, ethical business growth. We enforce:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-emerald-600" />
                  <span>No automated unsolicited cold mass email</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-emerald-600" />
                  <span>No scraping private personal data or credentials</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-emerald-600" />
                  <span>All outreach copy is for human review and personalization</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-emerald-600" />
                  <span>CAN-SPAM, GDPR, and CASL compliance standards</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
