import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, Bot, User, Copy, Check, Zap, Cpu, Code2, RefreshCw } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  model?: string;
  tokens?: number;
}

export function AiAssistantApp() {
  const [activeModel, setActiveModel] = useState('Gemini 3.8 Flash');
  const [inputPrompt, setInputPrompt] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      role: 'assistant',
      content: '👋 Welcome to Universal OmniAI Studio! I can write production code, orchestrate distributed microservices, analyze financial data, or architect complex workflows. What are we building today?',
      timestamp: '12:00 PM',
      model: 'Gemini 3.8 Flash',
      tokens: 48,
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = (textToSend?: string) => {
    const prompt = textToSend || inputPrompt;
    if (!prompt.trim() || isTyping) return;

    const userMsg: Message = {
      id: Math.random().toString(36).substring(2, 9),
      role: 'user',
      content: prompt.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setIsTyping(true);

    // Simulate AI response streaming
    setTimeout(() => {
      let replyContent = '';
      if (prompt.toLowerCase().includes('react') || prompt.toLowerCase().includes('code') || prompt.toLowerCase().includes('hook')) {
        replyContent = `Here is a production-grade TypeScript React implementation tailored for your architecture:\n\n\`\`\`typescript\nimport { useState, useEffect, useCallback } from 'react';\n\nexport function useLiveStream<T>(channelUrl: string) {\n  const [data, setData] = useState<T | null>(null);\n  const [status, setStatus] = useState<'connecting' | 'open' | 'closed'>('connecting');\n\n  useEffect(() => {\n    const ws = new WebSocket(channelUrl);\n    ws.onopen = () => setStatus('open');\n    ws.onmessage = (event) => setData(JSON.parse(event.data));\n    ws.onclose = () => setStatus('closed');\n    return () => ws.close();\n  }, [channelUrl]);\n\n  return { data, status };\n}\n\`\`\`\n\n**Key Highlights**:\n1. Non-blocking WebSocket lifecycle with cleanup.\n2. Typed payloads.\n3. Automatic reconnection hook readiness.`;
      } else if (prompt.toLowerCase().includes('trading') || prompt.toLowerCase().includes('finance')) {
        replyContent = `To build a high-frequency trading platform:\n1. **Event Sourcing Engine**: Use Redis Streams or Kafka for ultra-low latency order matching.\n2. **Order Book State**: Maintain in-memory binary trees for sub-millisecond price-time priority sorting.\n3. **Risk & Margin Gatekeeper**: Pre-validate leverage before routing to liquidity pools.`;
      } else {
        replyContent = `Analysis complete for: "${prompt}"\n\nI have generated the foundational blueprint with modular separation of concerns. The runtime is configured with responsive viewport adapters and strict TypeScript types. Would you like me to generate the database schema or write the API endpoints next?`;
      }

      const assistantMsg: Message = {
        id: Math.random().toString(36).substring(2, 9),
        role: 'assistant',
        content: replyContent,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        model: activeModel,
        tokens: Math.floor(Math.random() * 200) + 120,
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 1200);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const samplePrompts = [
    'Write a TypeScript React hook for live WebSockets',
    'How do I architect a low-latency trading order book?',
    'Create a database schema for multi-tenant SaaS billing',
  ];

  return (
    <div className="w-full h-full min-h-[580px] bg-slate-900 text-slate-100 flex flex-col font-sans">
      {/* Top Bar */}
      <div className="bg-slate-950 border-b border-slate-800 px-4 py-3 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-white">
            <Sparkles size={16} />
          </div>
          <div>
            <div className="font-bold text-sm text-white flex items-center gap-1.5">
              OmniAI Workspace <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded">v3.8 Production</span>
            </div>
          </div>
        </div>

        {/* Model Switcher */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
          {[
            { name: 'Gemini 3.8 Flash', icon: Zap },
            { name: 'Claude 3.7 Sonnet', icon: Sparkles },
            { name: 'GPT-4o', icon: Cpu },
          ].map((m) => (
            <button
              key={m.name}
              onClick={() => setActiveModel(m.name)}
              className={`px-2.5 py-1 text-xs font-semibold rounded flex items-center gap-1 transition-all ${
                activeModel === m.name ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <m.icon size={13} />
              {m.name}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Conversation Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 max-w-3xl ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
          >
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                msg.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-purple-400 border border-slate-700'
              }`}
            >
              {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
            </div>

            <div
              className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-indigo-600 text-white rounded-tr-none'
                  : 'bg-slate-950/80 border border-slate-800/90 text-slate-200 rounded-tl-none'
              }`}
            >
              {msg.model && (
                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-2 pb-1 border-b border-slate-800/80">
                  <span className="font-semibold text-purple-400">{msg.model}</span>
                  <span>{msg.tokens} tokens</span>
                </div>
              )}

              <div className="whitespace-pre-wrap font-sans">
                {msg.content}
              </div>

              <div className="flex justify-between items-center text-[10px] text-slate-400 mt-2">
                <span>{msg.timestamp}</span>
                {msg.role === 'assistant' && (
                  <button
                    onClick={() => copyToClipboard(msg.content, msg.id)}
                    className="hover:text-white flex items-center gap-1 transition-colors"
                  >
                    {copiedId === msg.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    {copiedId === msg.id ? 'Copied' : 'Copy'}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3 max-w-xl">
            <div className="w-8 h-8 rounded-lg bg-slate-800 text-purple-400 border border-slate-700 flex items-center justify-center">
              <Bot size={16} />
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-2xl rounded-tl-none px-4 py-3 flex items-center gap-2 text-slate-400 text-xs">
              <div className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
              <span>{activeModel} is generating response...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestions and Prompt Input */}
      <div className="p-4 bg-slate-950 border-t border-slate-800">
        {/* Quick Suggestion Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-2 no-scrollbar">
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 px-3 py-1.5 rounded-full border border-slate-800 whitespace-nowrap transition-colors shrink-0"
            >
              💡 {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="relative flex items-center">
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={`Ask ${activeModel} anything...`}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 pr-24 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
          />
          <div className="absolute right-2 flex items-center gap-1">
            <button
              onClick={() => handleSend()}
              disabled={!inputPrompt.trim() || isTyping}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all"
            >
              <span>Send</span>
              <Send size={13} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
