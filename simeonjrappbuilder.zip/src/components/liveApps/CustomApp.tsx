import React, { useState } from 'react';
import { Sparkles, Plus, CheckCircle2, Trash2, Search, Filter, ArrowUpRight } from 'lucide-react';

interface CustomItem {
  id: string;
  title: string;
  subtitle: string;
  status: string;
  tag: string;
}

export function CustomApp({ prompt, title }: { prompt: string; title: string }) {
  const [items, setItems] = useState<CustomItem[]>([
    { id: '1', title: 'Foundational Micro-Module', subtitle: 'Auto-scaffolded reactive store', status: 'Active', tag: 'Core' },
    { id: '2', title: 'Universal Endpoint Adapter', subtitle: 'Sub-second API routing layer', status: 'Ready', tag: 'Network' },
    { id: '3', title: 'Dynamic Component Viewport', subtitle: 'Responsive multi-device layout', status: 'Optimized', tag: 'UI' },
  ]);
  const [newItemTitle, setNewItemTitle] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [toast, setToast] = useState<string | null>(null);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemTitle.trim()) return;

    const created: CustomItem = {
      id: Math.random().toString(36).substring(2, 9),
      title: newItemTitle.trim(),
      subtitle: `Created based on: ${prompt.slice(0, 30)}...`,
      status: 'Active',
      tag: 'Custom',
    };

    setItems([created, ...items]);
    setNewItemTitle('');
    setToast(`Added "${created.title}" to active workspace`);
    setTimeout(() => setToast(null), 2500);
  };

  const removeItem = (id: string) => {
    setItems(items.filter((i) => i.id !== id));
  };

  const filtered = items.filter((i) =>
    i.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    i.subtitle.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="w-full h-full min-h-[580px] bg-slate-50 text-slate-900 font-sans flex flex-col overflow-y-auto">
      {/* Top Banner */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-bold text-base text-slate-900">{title || 'Dynamic Universal App'}</h1>
            <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-bold border border-indigo-200 flex items-center gap-1">
              <Sparkles size={11} /> Prompt-Synthesized
            </span>
          </div>
          <p className="text-xs text-slate-500 line-clamp-1 max-w-xl">
            Prompt: "{prompt}"
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg font-semibold">
            {items.length} Active Records
          </span>
        </div>
      </div>

      {toast && (
        <div className="bg-emerald-50 border-b border-emerald-200 text-emerald-800 text-xs px-6 py-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-medium">
            <CheckCircle2 size={13} className="text-emerald-600" />
            {toast}
          </span>
          <button onClick={() => setToast(null)} className="text-slate-400 hover:text-slate-700">✕</button>
        </div>
      )}

      {/* Main Content */}
      <div className="p-6 max-w-4xl mx-auto w-full space-y-6 flex-1">
        {/* Quick KPI stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="text-xs text-slate-500">Pipeline State</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">Operational</div>
            <div className="text-[11px] text-emerald-600 font-semibold mt-1">100% Health Verification</div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="text-xs text-slate-500">Active Records</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">{items.length}</div>
            <div className="text-[11px] text-indigo-600 font-semibold mt-1">Dynamic Local Storage</div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="text-xs text-slate-500">Latency Target</div>
            <div className="text-2xl font-bold text-slate-900 mt-1">&lt; 14ms</div>
            <div className="text-[11px] text-slate-500 font-semibold mt-1">Edge Runtime Ready</div>
          </div>
        </div>

        {/* Action Form */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <form onSubmit={handleAddItem} className="flex gap-2">
            <input
              type="text"
              value={newItemTitle}
              onChange={(e) => setNewItemTitle(e.target.value)}
              placeholder="Add a new entry, task, or record to this app..."
              className="flex-1 text-xs px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={!newItemTitle.trim()}
              className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1 shadow-xs transition-all"
            >
              <Plus size={14} />
              <span>Add Record</span>
            </button>
          </form>
        </div>

        {/* Filter and List */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="p-3.5 border-b border-slate-200 flex items-center justify-between">
            <div className="relative flex-1 max-w-xs">
              <Search size={13} className="absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search entries..."
                className="w-full pl-8 pr-3 py-1 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500"
              />
            </div>
            <span className="text-xs text-slate-500">Showing {filtered.length} entries</span>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {filtered.length === 0 ? (
              <div className="p-8 text-center text-slate-400">No matching records found.</div>
            ) : (
              filtered.map((item) => (
                <div key={item.id} className="p-3.5 flex items-center justify-between hover:bg-slate-50/80 transition-colors">
                  <div className="space-y-0.5">
                    <div className="font-semibold text-slate-900 flex items-center gap-2">
                      {item.title}
                      <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium">
                        {item.tag}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500">{item.subtitle}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-full border border-emerald-200">
                      {item.status}
                    </span>
                    <button onClick={() => removeItem(item.id)} className="text-slate-400 hover:text-rose-600 transition-colors">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
