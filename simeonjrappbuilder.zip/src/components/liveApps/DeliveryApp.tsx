import React, { useState, useEffect } from 'react';
import { ShoppingBag, Clock, MapPin, Phone, MessageSquare, CheckCircle, Navigation, ArrowRight, X } from 'lucide-react';

interface MenuItem {
  id: string;
  name: string;
  category: string;
  price: number;
  time: string;
  calories: string;
  image: string;
}

export function DeliveryApp() {
  const [cart, setCart] = useState<{ item: MenuItem; count: number }[]>([]);
  const [isOrdered, setIsOrdered] = useState(false);
  const [etaMinutes, setEtaMinutes] = useState(14);
  const [courierProgress, setCourierProgress] = useState(30);
  const [toast, setToast] = useState<string | null>(null);

  const menu: MenuItem[] = [
    {
      id: 'd1',
      name: 'Artisan Truffle Smash Burger',
      category: 'Burgers',
      price: 16.50,
      time: '15-20 min',
      calories: '720 kcal',
      image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=200&auto=format&fit=crop&q=80',
    },
    {
      id: 'd2',
      name: 'Wild Salmon Teriyaki Bowl',
      category: 'Bowls',
      price: 19.00,
      time: '12-18 min',
      calories: '540 kcal',
      image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200&auto=format&fit=crop&q=80',
    },
    {
      id: 'd3',
      name: 'Wood-fired Margherita Pizza',
      category: 'Pizza',
      price: 17.25,
      time: '20-25 min',
      calories: '860 kcal',
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=200&auto=format&fit=crop&q=80',
    },
    {
      id: 'd4',
      name: 'Cold-Pressed Green Glow Juice',
      category: 'Drinks',
      price: 6.50,
      time: '5 min',
      calories: '110 kcal',
      image: 'https://images.unsplash.com/photo-1622597467836-f3285f2131b7?w=200&auto=format&fit=crop&q=80',
    },
  ];

  const addToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((p) => p.item.id === item.id);
      if (existing) {
        return prev.map((p) => (p.item.id === item.id ? { ...p, count: p.count + 1 } : p));
      }
      return [...prev, { item, count: 1 }];
    });
    setToast(`Added ${item.name} to cart`);
    setTimeout(() => setToast(null), 2500);
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((p) => p.item.id !== itemId));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.item.price * item.count, 0);

  const [nearbyCouriers, setNearbyCouriers] = useState(7);
  const [liveGpsPulse, setLiveGpsPulse] = useState(false);

  // Ambient live updates when viewing menu (delayed 8s so it is never distracting)
  useEffect(() => {
    const ambientTimer = setInterval(() => {
      setNearbyCouriers((prev) => {
        const next = Math.max(5, Math.min(11, prev + (Math.random() > 0.5 ? 1 : -1)));
        setLiveGpsPulse(true);
        setTimeout(() => setLiveGpsPulse(false), 1200);
        return next;
      });
    }, 8000);
    return () => clearInterval(ambientTimer);
  }, []);

  // Smooth delayed courier simulation when ordered (every 4.5s)
  useEffect(() => {
    if (!isOrdered) return;
    const interval = setInterval(() => {
      setCourierProgress((prev) => {
        if (prev >= 100) return 100;
        return prev + 6;
      });
      setEtaMinutes((prev) => Math.max(1, prev - 1));
    }, 4500);
    return () => clearInterval(interval);
  }, [isOrdered]);

  return (
    <div className="w-full h-full min-h-[580px] bg-slate-50 text-slate-900 font-sans flex flex-col overflow-y-auto">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-3.5 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500 flex items-center justify-center text-white font-bold">
            ⚡
          </div>
          <div>
            <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
              DashBite HyperDelivery <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-bold">15 MIN GUARANTEE</span>
            </div>
            <div className="text-[11px] text-slate-500 flex items-center gap-1">
              <MapPin size={11} className="text-amber-500" /> Delivering to: 742 Evergreen Terrace
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors ${
            liveGpsPulse ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
          }`}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>{nearbyCouriers} couriers online</span>
          </div>

          {!isOrdered ? (
            <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-xl text-xs font-semibold">
              <ShoppingBag size={14} className="text-amber-600" />
              <span>{cart.reduce((s, i) => s + i.count, 0)} items</span>
              <span className="text-slate-400">|</span>
              <span className="text-slate-900 font-bold">${cartTotal.toFixed(2)}</span>
            </div>
          ) : (
            <button
              onClick={() => {
                setIsOrdered(false);
                setCart([]);
                setCourierProgress(30);
              }}
              className="text-xs text-amber-700 font-semibold hover:underline"
            >
              Order Again
            </button>
          )}
        </div>
      </div>

      {toast && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 text-xs px-6 py-2 flex items-center justify-between">
          <span>{toast}</span>
          <button onClick={() => setToast(null)} className="text-slate-400 hover:text-slate-600">✕</button>
        </div>
      )}

      {/* Main View: Menu & Ordering OR Live GPS Tracking */}
      {!isOrdered ? (
        <div className="p-6 max-w-5xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1">
          {/* Menu Catalog (8 cols) */}
          <div className="lg:col-span-8 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900">Chef Specials & Favorites</h2>
              <span className="text-xs text-slate-500">Live Kitchen Active</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {menu.map((item) => (
                <div key={item.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between">
                  <div className="h-32 w-full overflow-hidden bg-slate-100 relative">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                    <span className="absolute top-2 left-2 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-semibold px-2 py-0.5 rounded-full">
                      {item.time}
                    </span>
                  </div>
                  <div className="p-3.5 space-y-2">
                    <div>
                      <h3 className="font-bold text-xs text-slate-900">{item.name}</h3>
                      <p className="text-[11px] text-slate-500">{item.calories}</p>
                    </div>
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-sm font-bold text-slate-900">${item.price.toFixed(2)}</span>
                      <button
                        onClick={() => addToCart(item)}
                        className="bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-xs transition-all active:scale-95"
                      >
                        + Add to Order
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cart Checkout Summary (4 cols) */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col justify-between h-fit">
            <div>
              <h2 className="text-sm font-bold text-slate-900 mb-3 flex items-center justify-between">
                <span>Order Summary</span>
                <span className="text-xs font-normal text-slate-500">Standard Priority</span>
              </h2>

              {cart.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  Your bag is empty. Add culinary delights from the menu!
                </div>
              ) : (
                <div className="divide-y divide-slate-100 text-xs space-y-2 mb-4">
                  {cart.map(({ item, count }) => (
                    <div key={item.id} className="pt-2 flex justify-between items-center">
                      <div>
                        <div className="font-semibold text-slate-800">{count}x {item.name}</div>
                        <div className="text-[11px] text-slate-400">${(item.price * count).toFixed(2)}</div>
                      </div>
                      <button onClick={() => removeFromCart(item.id)} className="text-slate-400 hover:text-rose-600">
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-1.5 text-xs pt-3 border-t border-slate-100 text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${cartTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span className="text-emerald-600 font-semibold">FREE (Promo)</span>
                </div>
                <div className="flex justify-between font-bold text-sm text-slate-900 pt-2 border-t border-slate-100">
                  <span>Total Due</span>
                  <span>${cartTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                if (cart.length === 0) return;
                setIsOrdered(true);
              }}
              disabled={cart.length === 0}
              className="mt-6 w-full bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-95"
            >
              <span>Place Order (${cartTotal.toFixed(2)})</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      ) : (
        /* LIVE GPS DELIVERY TRACKING VIEW */
        <div className="p-6 max-w-3xl mx-auto w-full space-y-6 flex-1">
          {/* Animated Road / Map Simulation */}
          <div className="bg-slate-900 text-white rounded-3xl p-6 relative overflow-hidden shadow-lg border border-slate-800">
            {/* Background grid lines */}
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]" />

            <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 mb-6">
              <div>
                <span className="text-amber-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                  Live Courier Tracking
                </span>
                <h2 className="text-2xl font-bold text-white mt-1">Arriving in ~{etaMinutes} Minutes</h2>
                <p className="text-xs text-slate-400">Courier Alex R. is en route with your fresh order</p>
              </div>

              <div className="bg-slate-800/80 backdrop-blur-xs border border-slate-700 px-4 py-2 rounded-2xl flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                  🏍️
                </div>
                <div>
                  <div className="text-xs font-bold text-white">Alex Rivero</div>
                  <div className="text-[11px] text-slate-400">4.97 ★ • Honda CB500</div>
                </div>
              </div>
            </div>

            {/* Road route visual */}
            <div className="relative my-8">
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 via-amber-400 to-indigo-500 transition-all duration-1000"
                  style={{ width: `${courierProgress}%` }}
                />
              </div>

              {/* Courier Bike Marker */}
              <div
                className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 transition-all duration-1000 flex flex-col items-center"
                style={{ left: `${courierProgress}%` }}
              >
                <div className="w-7 h-7 bg-amber-400 text-slate-950 rounded-full shadow-lg flex items-center justify-center text-xs font-bold animate-bounce">
                  ⚡
                </div>
                <span className="text-[9px] font-bold bg-slate-950 px-1.5 py-0.5 rounded mt-1">En Route</span>
              </div>
            </div>

            {/* Step markers */}
            <div className="grid grid-cols-4 text-center text-xs text-slate-400 pt-2 border-t border-slate-800">
              <div className="text-emerald-400 font-bold">✓ Ordered</div>
              <div className="text-emerald-400 font-bold">✓ Prepared</div>
              <div className="text-amber-400 font-bold">● Out on Road</div>
              <div>○ Destination</div>
            </div>
          </div>

          {/* Courier Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => {
                setToast('Calling driver Alex via VoIP bridge...');
                setTimeout(() => setToast(null), 3000);
              }}
              className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <Phone size={14} className="text-emerald-600" />
              <span>Call Courier</span>
            </button>
            <button
              onClick={() => {
                setToast('Message sent to courier: "Gate code is 4421"');
                setTimeout(() => setToast(null), 3000);
              }}
              className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <MessageSquare size={14} className="text-indigo-600" />
              <span>Send Instructions</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
