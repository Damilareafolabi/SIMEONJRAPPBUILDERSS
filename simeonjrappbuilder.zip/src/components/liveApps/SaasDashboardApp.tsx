import React, { useState, useEffect } from 'react';
import { Users, DollarSign, TrendingUp, CreditCard, Search, Plus, Filter, CheckCircle2, ArrowUpRight, X } from 'lucide-react';

interface Customer {
  id: string;
  name: string;
  company: string;
  plan: 'Enterprise' | 'Growth' | 'Starter';
  mrr: number;
  status: 'Active' | 'Trial' | 'Past Due';
  joinedDate: string;
}

export function SaasDashboardApp() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [searchTerm, setSearchTerm] = useState('');
  const [planFilter, setPlanFilter] = useState('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const [newCustomer, setNewCustomer] = useState({
    name: '',
    company: '',
    plan: 'Growth' as const,
    mrr: 499,
  });

  const [customers, setCustomers] = useState<Customer[]>([
    { id: '1', name: 'Sophia Chen', company: 'HyperScale AI', plan: 'Enterprise', mrr: 2400, status: 'Active', joinedDate: 'Aug 2026' },
    { id: '2', name: 'Marcus Vance', company: 'Apex Global Ventures', plan: 'Enterprise', mrr: 3800, status: 'Active', joinedDate: 'Jul 2026' },
    { id: '3', name: 'Elena Rostova', company: 'Starlight Studio', plan: 'Growth', mrr: 499, status: 'Trial', joinedDate: 'Yesterday' },
    { id: '4', name: 'Devon King', company: 'CloudWave Technologies', plan: 'Starter', mrr: 99, status: 'Active', joinedDate: 'May 2026' },
  ]);

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPlan = planFilter === 'All' || c.plan === planFilter;
    return matchesSearch && matchesPlan;
  });

  const [totalMrrBonus, setTotalMrrBonus] = useState(0);
  const [activeUsersLive, setActiveUsersLive] = useState(14280);
  const [livePulse, setLivePulse] = useState(false);

  // Delayed live sync: ticks every 7 seconds, subtle and non-distracting
  useEffect(() => {
    const liveTimer = setInterval(() => {
      setActiveUsersLive((prev) => prev + (Math.random() > 0.4 ? 1 : 0));
      setLivePulse(true);
      setTimeout(() => setLivePulse(false), 1200);
    }, 7000);
    return () => clearInterval(liveTimer);
  }, []);

  // Gentle incoming customer event every 16 seconds
  useEffect(() => {
    const eventTimer = setInterval(() => {
      const sampleNames = [
        { name: 'Chloe Dubois', company: 'Luminary AI Paris', plan: 'Growth' as const, mrr: 499 },
        { name: 'Tariq Al-Mansoor', company: 'Oasis Cloud Dubai', plan: 'Enterprise' as const, mrr: 1800 },
        { name: 'Aria Thorne', company: 'Veloce Robotics', plan: 'Starter' as const, mrr: 99 },
      ];
      const pick = sampleNames[Math.floor(Math.random() * sampleNames.length)];
      const autoCustomer: Customer = {
        id: Math.random().toString(36).substring(2, 8),
        name: pick.name,
        company: pick.company,
        plan: pick.plan,
        mrr: pick.mrr,
        status: 'Active',
        joinedDate: 'Just now',
      };
      setCustomers((prev) => [autoCustomer, ...prev.slice(0, 5)]);
      setTotalMrrBonus((prev) => prev + pick.mrr);
    }, 16000);
    return () => clearInterval(eventTimer);
  }, []);

  const totalMrr = customers.reduce((sum, c) => sum + c.mrr, 0);

  const handleAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomer.name || !newCustomer.company) return;

    const created: Customer = {
      id: Math.random().toString(36).substring(2, 9),
      name: newCustomer.name,
      company: newCustomer.company,
      plan: newCustomer.plan,
      mrr: Number(newCustomer.mrr) || 299,
      status: 'Active',
      joinedDate: 'Just now',
    };

    setCustomers([created, ...customers]);
    setIsAddModalOpen(false);
    setNewCustomer({ name: '', company: '', plan: 'Growth', mrr: 499 });
    setToast(`Added ${created.company} to active pipeline`);
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <div className="w-full h-full min-h-[580px] bg-slate-50 text-slate-900 font-sans flex flex-col overflow-y-auto">
      {/* Top Banner */}
      <div className="bg-white border-b border-slate-200 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            NexusPulse CRM & Revenue Hub
            <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-semibold border border-indigo-200">
              Live Production
            </span>
          </h1>
          <p className="text-xs text-slate-500">Real-time subscription billing, customer churn intelligence, and pipeline management.</p>
        </div>

        <div className="flex items-center gap-2">
          {/* Monthly / Annual Toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-3 py-1 rounded font-medium transition-all ${
                billingCycle === 'monthly' ? 'bg-white shadow text-slate-900 font-bold' : 'text-slate-600'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`px-3 py-1 rounded font-medium transition-all ${
                billingCycle === 'annual' ? 'bg-white shadow text-slate-900 font-bold' : 'text-slate-600'
              }`}
            >
              Annual <span className="text-[10px] text-emerald-600 font-bold">(-20%)</span>
            </button>
          </div>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold px-3 py-2 rounded-lg flex items-center gap-1.5 shadow-sm transition-all"
          >
            <Plus size={15} />
            <span>Add Customer</span>
          </button>
        </div>
      </div>

      {toast && (
        <div className="bg-emerald-50 border-b border-emerald-200 text-emerald-800 text-xs px-6 py-2 flex items-center justify-between">
          <span className="flex items-center gap-2 font-medium">
            <CheckCircle2 size={14} className="text-emerald-600" />
            {toast}
          </span>
          <button onClick={() => setToast(null)} className="text-slate-400 hover:text-slate-700">✕</button>
        </div>
      )}

      {/* Main Content */}
      <div className="p-6 space-y-6 flex-1">
        {/* KPI Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span>Monthly Recurring Revenue</span>
              <span className="inline-flex items-center gap-1 text-[10px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                SYNC (7s)
              </span>
            </div>
            <div className={`text-2xl font-bold transition-colors duration-500 ${livePulse ? 'text-indigo-600' : 'text-slate-900'}`}>
              ${(totalMrr + totalMrrBonus).toLocaleString()}
            </div>
            <div className="flex items-center gap-1 text-xs text-emerald-600 font-semibold mt-1">
              <ArrowUpRight size={14} /> +19.2% real-time run rate
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span>Live Active Users</span>
              <Users size={16} className="text-indigo-600" />
            </div>
            <div className="text-2xl font-bold text-slate-900">
              {activeUsersLive.toLocaleString()}
            </div>
            <div className="flex items-center gap-1 text-xs text-emerald-600 font-semibold mt-1">
              <ArrowUpRight size={14} /> Active sessions worldwide
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span>Gross Churn Rate</span>
              <TrendingUp size={16} className="text-emerald-600" />
            </div>
            <div className="text-2xl font-bold text-slate-900">
              0.84%
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Target: &lt; 1.5% • Ultra healthy
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span>Average Deal Size</span>
              <CreditCard size={16} className="text-indigo-600" />
            </div>
            <div className="text-2xl font-bold text-slate-900">
              $1,840
            </div>
            <div className="flex items-center gap-1 text-xs text-emerald-600 font-semibold mt-1">
              <ArrowUpRight size={14} /> Top tier expanding
            </div>
          </div>
        </div>

        {/* Customer Pipeline Section */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-sm text-slate-900">Customer Accounts</h2>
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-medium">
                {filteredCustomers.length} accounts
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Search Bar */}
              <div className="relative">
                <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter name or company..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 w-48"
                />
              </div>

              {/* Plan Filter */}
              <select
                value={planFilter}
                onChange={(e) => setPlanFilter(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 text-slate-700"
              >
                <option value="All">All Plans</option>
                <option value="Enterprise">Enterprise</option>
                <option value="Growth">Growth</option>
                <option value="Starter">Starter</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-200 font-medium">
                <tr>
                  <th className="px-4 py-3">Customer / Company</th>
                  <th className="px-4 py-3">Tier Plan</th>
                  <th className="px-4 py-3">MRR Contribution</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Joined</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCustomers.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 font-semibold text-slate-900">
                      <div>{c.name}</div>
                      <div className="text-[11px] text-slate-500 font-normal">{c.company}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        c.plan === 'Enterprise' ? 'bg-purple-100 text-purple-700' : c.plan === 'Growth' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {c.plan}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900">
                      ${c.mrr.toLocaleString()}/mo
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        c.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${c.status === 'Active' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                        {c.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-500">{c.joinedDate}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => {
                          setToast(`Generated invoice statement for ${c.company}`);
                          setTimeout(() => setToast(null), 3000);
                        }}
                        className="text-indigo-600 hover:text-indigo-800 font-semibold"
                      >
                        Invoice
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Customer Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-slate-900">Add Customer Account</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddCustomer} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Contact Name</label>
                <input
                  type="text"
                  required
                  value={newCustomer.name}
                  onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                  placeholder="e.g. Rachel Adams"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Company / Team</label>
                <input
                  type="text"
                  required
                  value={newCustomer.company}
                  onChange={(e) => setNewCustomer({ ...newCustomer, company: e.target.value })}
                  placeholder="e.g. Zenith Cloud Inc"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Plan</label>
                  <select
                    value={newCustomer.plan}
                    onChange={(e) => setNewCustomer({ ...newCustomer, plan: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Starter">Starter ($99)</option>
                    <option value="Growth">Growth ($499)</option>
                    <option value="Enterprise">Enterprise ($2400)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Monthly MRR ($)</label>
                  <input
                    type="number"
                    value={newCustomer.mrr}
                    onChange={(e) => setNewCustomer({ ...newCustomer, mrr: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold shadow-xs"
                >
                  Create Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
