import React, { useState } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, Image, Send, MoreHorizontal, CheckCircle2 } from 'lucide-react';

interface Post {
  id: string;
  author: string;
  handle: string;
  avatar: string;
  time: string;
  content: string;
  tags: string[];
  likes: number;
  hasLiked: boolean;
  comments: { id: string; user: string; text: string }[];
}

export function SocialApp() {
  const [postText, setPostText] = useState('');
  const [activeTab, setActiveTab] = useState<'feed' | 'trending'>('feed');
  const [toast, setToast] = useState<string | null>(null);
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState('');

  const [posts, setPosts] = useState<Post[]>([
    {
      id: 'p1',
      author: 'Elena Rostova',
      handle: '@elena_design',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      time: '20m ago',
      content: 'Just launched our universal micro-frontend ecosystem on Simeon Jr App Factory! Zero-config deployment with sub-100ms response times. Thoughts on combining Vite + React with edge routing?',
      tags: ['#UniversalFactory', '#WebDev', '#React18'],
      likes: 42,
      hasLiked: false,
      comments: [
        { id: 'c1', user: 'Alex', text: 'Looks phenomenal! Clean typography and great pacing.' },
      ],
    },
    {
      id: 'p2',
      author: 'Kaelen Thorne',
      handle: '@kaelen_ai',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
      time: '1h ago',
      content: 'Local AI engines like Qwen and Gemini Flash give developers instant feedback loops without waiting on cloud queue throttles. The future of software creation is prompt-driven.',
      tags: ['#AIBuilder', '#LocalFirst', '#Engineering'],
      likes: 89,
      hasLiked: true,
      comments: [],
    },
  ]);

  const [onlineCreators, setOnlineCreators] = useState(342);
  const [livePulse, setLivePulse] = useState(false);

  // Dynamic live creator updates (delayed 8s so it is never distracting)
  React.useEffect(() => {
    const timer = setInterval(() => {
      setOnlineCreators((prev) => {
        const delta = Math.random() > 0.5 ? 1 : -1;
        setLivePulse(true);
        setTimeout(() => setLivePulse(false), 1200);
        return Math.max(310, Math.min(380, prev + delta));
      });
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  // Gentle delayed community activity (every 16s)
  React.useEffect(() => {
    const likeTimer = setInterval(() => {
      setPosts((prev) =>
        prev.map((p, idx) =>
          idx === 0 ? { ...p, likes: p.likes + 1 } : p
        )
      );
    }, 16000);
    return () => clearInterval(likeTimer);
  }, []);

  const handleCreatePost = () => {
    if (!postText.trim()) return;

    const newPost: Post = {
      id: Math.random().toString(36).substring(2, 9),
      author: 'You (Creator)',
      handle: '@simeon_creator',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
      time: 'Just now',
      content: postText.trim(),
      tags: ['#PromptBuilder', '#NewPost'],
      likes: 1,
      hasLiked: true,
      comments: [],
    };

    setPosts([newPost, ...posts]);
    setPostText('');
    setToast('Post published to Sphere Network!');
    setTimeout(() => setToast(null), 3000);
  };

  const toggleLike = (postId: string) => {
    setPosts(posts.map((p) => {
      if (p.id === postId) {
        return {
          ...p,
          hasLiked: !p.hasLiked,
          likes: p.hasLiked ? p.likes - 1 : p.likes + 1,
        };
      }
      return p;
    }));
  };

  const addComment = (postId: string) => {
    if (!commentInput.trim()) return;
    setPosts(posts.map((p) => {
      if (p.id === postId) {
        return {
          ...p,
          comments: [...p.comments, { id: Math.random().toString(), user: 'You', text: commentInput.trim() }],
        };
      }
      return p;
    }));
    setCommentInput('');
    setActiveCommentPostId(null);
  };

  return (
    <div className="w-full h-full min-h-[580px] bg-slate-100 text-slate-900 font-sans flex flex-col overflow-y-auto">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between sticky top-0 z-10 shadow-xs">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-pink-500 to-indigo-600 flex items-center justify-center text-white font-bold text-xs">
            S
          </div>
          <span className="font-bold text-sm tracking-tight">Sphere Community</span>
        </div>

        <div className="flex items-center gap-3">
          <div className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold transition-colors ${
            livePulse ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
          }`}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>{onlineCreators} creators online</span>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs">
            <button
              onClick={() => setActiveTab('feed')}
              className={`px-3 py-1 rounded font-semibold transition-all ${
                activeTab === 'feed' ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Feed
            </button>
            <button
              onClick={() => setActiveTab('trending')}
              className={`px-3 py-1 rounded font-semibold transition-all ${
                activeTab === 'trending' ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Explore
            </button>
          </div>
        </div>
      </div>

      {toast && (
        <div className="bg-indigo-50 border-b border-indigo-200 text-indigo-800 text-xs px-6 py-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-medium">
            <CheckCircle2 size={14} className="text-indigo-600" />
            {toast}
          </span>
          <button onClick={() => setToast(null)} className="text-slate-400 hover:text-slate-600">✕</button>
        </div>
      )}

      {/* Main Container */}
      <div className="max-w-2xl mx-auto w-full p-4 space-y-4 flex-1">
        {/* Stories Bar */}
        <div className="bg-white p-3 rounded-xl border border-slate-200 flex items-center gap-4 overflow-x-auto shadow-xs">
          {[
            { name: 'Your Story', img: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80', isNew: false },
            { name: 'Marcus', img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80', isNew: true },
            { name: 'Sophia', img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80', isNew: true },
            { name: 'Devon', img: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80', isNew: true },
          ].map((s, idx) => (
            <div key={idx} className="flex flex-col items-center gap-1 shrink-0 cursor-pointer">
              <div className={`p-0.5 rounded-full ${s.isNew ? 'bg-gradient-to-tr from-amber-500 to-rose-500' : 'border border-slate-300'}`}>
                <img src={s.img} alt={s.name} className="w-11 h-11 rounded-full object-cover border-2 border-white" />
              </div>
              <span className="text-[10px] text-slate-600 font-medium">{s.name}</span>
            </div>
          ))}
        </div>

        {/* Post Publisher */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex gap-3 items-start">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80"
              alt="You"
              className="w-9 h-9 rounded-full object-cover shrink-0"
            />
            <textarea
              value={postText}
              onChange={(e) => setPostText(e.target.value)}
              placeholder="What are you creating or exploring today?"
              rows={2}
              className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 resize-none"
            />
          </div>
          <div className="flex items-center justify-between pt-1 border-t border-slate-100">
            <div className="flex items-center gap-2 text-slate-500 text-xs">
              <span className="text-[11px] text-indigo-600 font-semibold cursor-pointer">#AddTag</span>
            </div>
            <button
              onClick={handleCreatePost}
              disabled={!postText.trim()}
              className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-semibold px-4 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xs transition-all"
            >
              <span>Publish</span>
              <Send size={12} />
            </button>
          </div>
        </div>

        {/* Post Feed */}
        <div className="space-y-4">
          {posts.map((post) => (
            <div key={post.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
              {/* Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <img src={post.avatar} alt={post.author} className="w-9 h-9 rounded-full object-cover" />
                  <div>
                    <div className="font-bold text-xs text-slate-900">{post.author}</div>
                    <div className="text-[11px] text-slate-500">{post.handle} • {post.time}</div>
                  </div>
                </div>
                <button className="text-slate-400 hover:text-slate-600">
                  <MoreHorizontal size={16} />
                </button>
              </div>

              {/* Content */}
              <p className="text-xs text-slate-800 leading-relaxed">{post.content}</p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5">
                {post.tags.map((t, idx) => (
                  <span key={idx} className="text-[11px] text-indigo-600 font-medium hover:underline cursor-pointer">
                    {t}
                  </span>
                ))}
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-600">
                <button
                  onClick={() => toggleLike(post.id)}
                  className={`flex items-center gap-1.5 transition-colors ${
                    post.hasLiked ? 'text-rose-600 font-bold' : 'hover:text-rose-600'
                  }`}
                >
                  <Heart size={15} fill={post.hasLiked ? 'currentColor' : 'none'} />
                  <span>{post.likes}</span>
                </button>

                <button
                  onClick={() => setActiveCommentPostId(activeCommentPostId === post.id ? null : post.id)}
                  className="flex items-center gap-1.5 hover:text-indigo-600 transition-colors"
                >
                  <MessageCircle size={15} />
                  <span>{post.comments.length}</span>
                </button>

                <button
                  onClick={() => {
                    setToast('Link copied to clipboard!');
                    setTimeout(() => setToast(null), 2500);
                  }}
                  className="flex items-center gap-1.5 hover:text-indigo-600 transition-colors"
                >
                  <Share2 size={15} />
                  <span>Share</span>
                </button>
              </div>

              {/* Comments Section */}
              {activeCommentPostId === post.id && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2 text-xs">
                  <div className="space-y-1">
                    {post.comments.length === 0 ? (
                      <div className="text-[11px] text-slate-400">No comments yet. Be the first!</div>
                    ) : (
                      post.comments.map((c) => (
                        <div key={c.id} className="text-[11px]">
                          <span className="font-bold text-slate-800">{c.user}: </span>
                          <span className="text-slate-600">{c.text}</span>
                        </div>
                      ))
                    )}
                  </div>
                  <div className="flex gap-2 pt-1">
                    <input
                      type="text"
                      placeholder="Write a comment..."
                      value={commentInput}
                      onChange={(e) => setCommentInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addComment(post.id)}
                      className="flex-1 px-2.5 py-1 text-xs bg-white border border-slate-200 rounded focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      onClick={() => addComment(post.id)}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded text-xs font-semibold"
                    >
                      Post
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
