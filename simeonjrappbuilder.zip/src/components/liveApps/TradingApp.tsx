import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, RefreshCw, DollarSign, Wallet, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface Trade {
  id: string;
  asset: string;
  side: 'BUY' | 'SELL';
  price: number;
  amount: number;
  total: number;
  time: string;
}

export function TradingApp() {
  const [selectedAsset, setSelectedAsset] = useState('BTC');
  const [balance, setBalance] = useState(148250.00);
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT'>('MARKET');
  const [amount, setAmount] = useState('0.25');
  const [sliderPercent, setSliderPercent] = useState(25);
  const [trades, setTrades] = useState<Trade[]>([
    { id: '1', asset: 'BTC', side: 'BUY', price: 94220, amount: 0.5, total: 47110, time: '14:22:04' },
    { id: '2', asset: 'ETH', side: 'SELL', price: 3410, amount: 4.0, total: 13640, time: '14:20:18' },
    { id: '3', asset: 'SOL', side: 'BUY', price: 194.5, amount: 25, total: 4862.5, time: '14:18:50' },
  ]);
  const [toast, setToast] = useState<string | null>(null);

  const [assetPrices, setAssetPrices] = useState<Record<string, { price: number; change: string; isUp: boolean }>>({
    BTC: { price: 94350.20, change: '+3.42%', isUp: true },
    ETH: { price: 3445.80, change: '+2.15%', isUp: true },
    SOL: { price: 198.40, change: '+5.78%', isUp: true },
    SUI: { price: 3.42, change: '+8.14%', isUp: true },
  });

  const [pricePulse, setPricePulse] = useState<'up' | 'down' | null>(null);

  // Dynamic live feed with gentle delay (every 6 seconds so it's not distracting)
  useEffect(() => {
    const timer = setInterval(() => {
      setAssetPrices((prev) => {
        const current = prev[selectedAsset] || { price: 1000, change: '+0.00%', isUp: true };
        // Gentle realistic fluctuation (+/- 0.08%)
        const deltaFactor = (Math.random() - 0.48) * 0.0016;
        const newPrice = Math.max(1, Number((current.price * (1 + deltaFactor)).toFixed(2)));
        const isUp = deltaFactor >= 0;
        
        setPricePulse(isUp ? 'up' : 'down');
        setTimeout(() => setPricePulse(null), 1400);

        return {
          ...prev,
          [selectedAsset]: {
            ...current,
            price: newPrice,
            isUp,
            change: `${isUp ? '+' : ''}${(parseFloat(current.change) + (deltaFactor * 10)).toFixed(2)}%`,
          },
        };
      });
    }, 6000);

    return () => clearInterval(timer);
  }, [selectedAsset]);

  // Gentle live trade simulator (every 12 seconds)
  useEffect(() => {
    const tradeTimer = setInterval(() => {
      const current = assetPrices[selectedAsset];
      if (!current) return;
      const isBuy = Math.random() > 0.45;
      const randomQty = selectedAsset === 'BTC' ? Number((Math.random() * 0.4 + 0.05).toFixed(4))
        : selectedAsset === 'ETH' ? Number((Math.random() * 2 + 0.2).toFixed(2))
        : Number((Math.random() * 15 + 2).toFixed(1));

      const autoTrade: Trade = {
        id: Math.random().toString(36).substring(2, 8),
        asset: selectedAsset,
        side: isBuy ? 'BUY' : 'SELL',
        price: current.price,
        amount: randomQty,
        total: Number((randomQty * current.price).toFixed(2)),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };

      setTrades((prev) => [autoTrade, ...prev.slice(0, 6)]);
    }, 12000);

    return () => clearInterval(tradeTimer);
  }, [selectedAsset, assetPrices]);

  const currentPrice = assetPrices[selectedAsset]?.price || 1000;

  // Handle trade execution
  const executeOrder = () => {
    const numAmount = parseFloat(amount) || 0;
    if (numAmount <= 0) return;
    const totalCost = numAmount * currentPrice;

    if (side === 'BUY' && totalCost > balance) {
      setToast('Insufficient balance for this transaction');
      setTimeout(() => setToast(null), 3000);
      return;
    }

    const newBalance = side === 'BUY' ? balance - totalCost : balance + totalCost;
    setBalance(newBalance);

    const newTrade: Trade = {
      id: Math.random().toString(36).substring(2, 9),
      asset: selectedAsset,
      side,
      price: currentPrice,
      amount: numAmount,
      total: totalCost,
      time: new Date().toLocaleTimeString(),
    };

    setTrades([newTrade, ...trades.slice(0, 7)]);
    setToast(`Successfully executed ${side} ${numAmount} ${selectedAsset} @ $${currentPrice.toLocaleString()}`);
    setTimeout(() => setToast(null), 3500);
  };

  const handleSliderChange = (pct: number) => {
    setSliderPercent(pct);
    const maxAffordable = (balance * (pct / 100)) / currentPrice;
    setAmount(maxAffordable.toFixed(4));
  };

  return (
    <div className="w-full h-full min-h-[580px] bg-slate-950 text-slate-100 font-sans flex flex-col select-none overflow-y-auto">
      {/* Top Ticker Header */}
      <div className="bg-slate-900 border-b border-slate-800/80 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-white shadow-sm">
            ▲
          </div>
          <div>
            <div className="font-bold text-sm tracking-tight text-white flex items-center gap-2">
              APEX TRADE <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-500/30">PRO TERMINAL</span>
            </div>
            <div className="text-[11px] text-slate-400">Universal Liquidity Aggregator</div>
          </div>
        </div>

        {/* Asset Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
          {Object.keys(assetPrices).map((ticker) => (
            <button
              key={ticker}
              onClick={() => setSelectedAsset(ticker)}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                selectedAsset === ticker
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {ticker}
            </button>
          ))}
        </div>

        {/* Balance */}
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-[10px] uppercase text-slate-400 font-medium">Buying Power</div>
            <div className="text-sm font-bold text-emerald-400">
              ${balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
        </div>
      </div>

      {/* Toast Notification */}
      {toast && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs px-4 py-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 size={14} className="text-emerald-400" />
            {toast}
          </span>
          <button onClick={() => setToast(null)} className="text-slate-400 hover:text-white text-xs">✕</button>
        </div>
      )}

      {/* Main Grid */}
      <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Chart & Stats (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {/* Main Price Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-medium">{selectedAsset}/USDT Perpetual</span>
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/60">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    LIVE (6s)
                  </span>
                </div>
                <div className="text-2xl font-bold text-white tracking-tight flex items-center gap-2 transition-all duration-500">
                  <span className={`px-1.5 py-0.5 rounded transition-all duration-700 ${
                    pricePulse === 'up'
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : pricePulse === 'down'
                      ? 'bg-rose-500/20 text-rose-300'
                      : 'text-white'
                  }`}>
                    ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded font-semibold flex items-center gap-0.5 ${
                      assetPrices[selectedAsset].isUp
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}
                  >
                    {assetPrices[selectedAsset].isUp ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                    {assetPrices[selectedAsset].change}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                {['1H', '24H', '7D', '1M', '1Y'].map((tf, i) => (
                  <button
                    key={tf}
                    className={`px-2.5 py-1 rounded font-medium ${
                      i === 1 ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive SVG Chart Wave */}
            <div className="w-full h-48 relative flex items-end">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 500 150" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                <path
                  d="M 0 110 Q 50 90, 100 120 T 200 80 T 300 95 T 400 40 T 500 30 L 500 150 L 0 150 Z"
                  fill="url(#chartGrad)"
                />
                <path
                  d="M 0 110 Q 50 90, 100 120 T 200 80 T 300 95 T 400 40 T 500 30"
                  fill="none"
                  stroke="#818cf8"
                  strokeWidth="2.5"
                />
                <circle cx="500" cy="30" r="4" fill="#818cf8" className="animate-ping" />
                <circle cx="500" cy="30" r="4" fill="#818cf8" />
              </svg>
            </div>
            <div className="flex justify-between text-[11px] text-slate-500 border-t border-slate-800/80 pt-2 mt-2">
              <span>08:00</span>
              <span>10:00</span>
              <span>12:00</span>
              <span>14:00</span>
              <span>Live Now</span>
            </div>
          </div>

          {/* Recent Executed Trades */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex-1">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs font-bold text-slate-200 uppercase tracking-wider">Executed Trade History</div>
              <span className="text-[11px] text-slate-400">Auto-synced</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="text-slate-400 border-b border-slate-800 pb-2">
                    <th className="py-1 font-medium">Time</th>
                    <th className="py-1 font-medium">Asset</th>
                    <th className="py-1 font-medium">Side</th>
                    <th className="py-1 font-medium text-right">Price</th>
                    <th className="py-1 font-medium text-right">Amount</th>
                    <th className="py-1 font-medium text-right">Total ($)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {trades.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-2 text-slate-400">{t.time}</td>
                      <td className="py-2 font-semibold text-white">{t.asset}</td>
                      <td className="py-2">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            t.side === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {t.side}
                        </span>
                      </td>
                      <td className="py-2 text-right font-mono">${t.price.toLocaleString()}</td>
                      <td className="py-2 text-right font-mono">{t.amount}</td>
                      <td className="py-2 text-right font-mono text-slate-200">${t.total.toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Order Panel & Order Book (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {/* Order Placement Form */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">Place Order</span>
              <div className="flex items-center gap-1 text-[11px] text-slate-400">
                <ShieldCheck size={13} className="text-emerald-400" /> 0% Fee Tier
              </div>
            </div>

            {/* Side Tabs */}
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800 mb-3">
              <button
                onClick={() => setSide('BUY')}
                className={`py-2 text-xs font-bold rounded transition-all ${
                  side === 'BUY' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                BUY / LONG
              </button>
              <button
                onClick={() => setSide('SELL')}
                className={`py-2 text-xs font-bold rounded transition-all ${
                  side === 'SELL' ? 'bg-rose-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                SELL / SHORT
              </button>
            </div>

            {/* Order Type */}
            <div className="flex gap-2 mb-3">
              {(['MARKET', 'LIMIT'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setOrderType(t)}
                  className={`text-xs px-2.5 py-1 rounded border font-medium ${
                    orderType === t
                      ? 'border-indigo-500 bg-indigo-500/10 text-indigo-300'
                      : 'border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {/* Amount input */}
            <div className="space-y-1.5 mb-3">
              <label className="text-[11px] text-slate-400 flex justify-between">
                <span>Amount ({selectedAsset})</span>
                <span>Est: ${( (parseFloat(amount) || 0) * currentPrice ).toLocaleString()}</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-indigo-500"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-500 font-bold">{selectedAsset}</span>
              </div>
            </div>

            {/* Quick Percent Pills */}
            <div className="grid grid-cols-4 gap-1.5 mb-4">
              {[25, 50, 75, 100].map((pct) => (
                <button
                  key={pct}
                  onClick={() => handleSliderChange(pct)}
                  className={`text-[11px] py-1 rounded border font-medium ${
                    sliderPercent === pct
                      ? 'bg-slate-800 text-white border-slate-600'
                      : 'border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {pct}%
                </button>
              ))}
            </div>

            {/* Execute Button */}
            <button
              onClick={executeOrder}
              className={`w-full py-2.5 rounded-lg font-bold text-sm text-white transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2 ${
                side === 'BUY'
                  ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/30'
                  : 'bg-rose-600 hover:bg-rose-500 shadow-rose-900/30'
              }`}
            >
              {side === 'BUY' ? 'Execute Buy Order' : 'Execute Sell Order'}
            </button>
          </div>

          {/* Live Order Book */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex-1">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">Live Order Book</span>
              <span className="text-[10px] text-slate-500">Real-time matching</span>
            </div>
            <div className="space-y-1 text-[11px] font-mono">
              {/* Asks */}
              {[
                { price: currentPrice * 1.002, size: 1.45, pct: 60 },
                { price: currentPrice * 1.001, size: 0.82, pct: 40 },
              ].map((item, i) => (
                <div key={i} className="flex justify-between relative py-0.5 text-rose-400">
                  <div
                    className="absolute right-0 top-0 bottom-0 bg-rose-500/10 pointer-events-none"
                    style={{ width: `${item.pct}%` }}
                  />
                  <span>${item.price.toFixed(2)}</span>
                  <span className="text-slate-400">{item.size}</span>
                </div>
              ))}

              <div className="py-1 text-center font-bold text-white text-xs border-y border-slate-800/80 my-1">
                ${currentPrice.toFixed(2)} Spread: $0.05
              </div>

              {/* Bids */}
              {[
                { price: currentPrice * 0.999, size: 2.15, pct: 85 },
                { price: currentPrice * 0.998, size: 1.20, pct: 50 },
              ].map((item, i) => (
                <div key={i} className="flex justify-between relative py-0.5 text-emerald-400">
                  <div
                    className="absolute right-0 top-0 bottom-0 bg-emerald-500/10 pointer-events-none"
                    style={{ width: `${item.pct}%` }}
                  />
                  <span>${item.price.toFixed(2)}</span>
                  <span className="text-slate-400">{item.size}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
