import React from 'react';
import { 
  Sparkles, CheckCircle2, Shield, Globe, Cpu, Zap, 
  Layers, ArrowRight, Server, Terminal, Lock, Award
} from 'lucide-react';

interface AboutUsViewProps {
  onStartBuilding: () => void;
  onExploreAgents: () => void;
}

export function AboutUsView({ onStartBuilding, onExploreAgents }: AboutUsViewProps) {
  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16 antialiased">
      {/* Hero Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <Sparkles size={13} />
          <span>OUR MISSION & ARCHITECTURE</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          Redefining software creation for the universal era.
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          APPMORA was created by <strong>Simeon Intelligence / Simeon Jr Studios & Technologies</strong> to bridge the chasm between natural language and full-spectrum, production-ready software across every device and operating system.
        </p>
      </div>

      {/* The Universal Software Thesis */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl grid md:grid-cols-2 gap-10 items-center">
        <div className="space-y-5">
          <div className="text-xs font-bold uppercase tracking-wider text-indigo-400">The Problem with Traditional Builders</div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Why isolated cloud sandboxes are no longer enough.
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Existing app builders limit creators to a single web iframe or temporary cloud virtual machine. When you want an Android APK, an iOS package, a desktop executable, or self-hosted source code, traditional tools force you to start from scratch.
          </p>
          <p className="text-sm text-slate-300 leading-relaxed">
            APPMORA breaks this ceiling. A single prompt synthesizes clean TypeScript, React, Tailwind, and native bindings. You own the code, the assets, and the binaries forever.
          </p>

          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={onStartBuilding}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center gap-2"
            >
              <span>Experience the Engine</span>
              <ArrowRight size={14} />
            </button>
            <button
              onClick={onExploreAgents}
              className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition"
            >
              Meet the AI Agents
            </button>
          </div>
        </div>

        {/* Comparison Matrix */}
        <div className="bg-slate-950/80 rounded-2xl p-6 border border-slate-800/80 space-y-4">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wider border-b border-slate-800 pb-2 flex justify-between">
            <span>Capability</span>
            <span className="text-indigo-400">APPMORA Advantage</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-start justify-between py-2 border-b border-slate-900 gap-4">
              <span className="text-slate-400">Platform Deployment</span>
              <span className="font-semibold text-emerald-400 text-right">Universal (Web, APK, iOS, Desktop)</span>
            </div>
            <div className="flex items-start justify-between py-2 border-b border-slate-900 gap-4">
              <span className="text-slate-400">Source Code Ownership</span>
              <span className="font-semibold text-emerald-400 text-right">100% Full Export & Zero Lock-in</span>
            </div>
            <div className="flex items-start justify-between py-2 border-b border-slate-900 gap-4">
              <span className="text-slate-400">Multi-Agent Consensus</span>
              <span className="font-semibold text-emerald-400 text-right">5 Autonomous Dev Agents</span>
            </div>
            <div className="flex items-start justify-between py-2 border-b border-slate-900 gap-4">
              <span className="text-slate-400">Local & Cloud Execution</span>
              <span className="font-semibold text-emerald-400 text-right">Dual Hybrid Execution Engine</span>
            </div>
            <div className="flex items-start justify-between py-2 gap-4">
              <span className="text-slate-400">Self-Healing CI/CD</span>
              <span className="font-semibold text-emerald-400 text-right">Automatic Linter & Syntax Repair</span>
            </div>
          </div>
        </div>
      </div>

      {/* Core Principles */}
      <div className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            Our Architectural Principles
          </h2>
          <p className="text-sm text-slate-600">
            Engineered by Simeon Jr Studios & Technologies with uncompromising craft.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Zap size={20} />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Prompt-to-Live Runtime</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Sub-second AST analysis and reactive code synthesis transform user intentions into running applications without intermediate cold boots.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <Globe size={20} />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Universal Targets</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Build once from prompt, output immediately to Web (React/Tailwind), Android APK (Capacitor/Java), and Desktop (Tauri/Rust).
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center font-bold">
              <Cpu size={20} />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Multi-Agent Verification</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Independent compiler, security, and linting agents inspect every synthesized line before preview to guarantee zero breaking errors.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <Lock size={20} />
            </div>
            <h3 className="font-bold text-slate-900 text-base">Privacy & Sovereignty</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Your software code, schemas, and assets belong entirely to you. Download complete source repositories with one click.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
