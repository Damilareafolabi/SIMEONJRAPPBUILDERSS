import React, { useState } from 'react';
import { 
  Sparkles, Cpu, Terminal, ShieldCheck, Play, CheckCircle2, 
  RotateCcw, ArrowRight, Activity, Layers, Code2, Zap, AlertCircle
} from 'lucide-react';

interface AgentInfo {
  id: string;
  name: string;
  codename: string;
  role: string;
  description: string;
  metrics: string;
  status: 'idle' | 'active' | 'success';
}

export function AgentsView({ onStartBuilding }: { onStartBuilding: () => void }) {
  const [activeTab, setActiveTab] = useState<string>('alpha');
  const [isRunningSimulation, setIsRunningSimulation] = useState<boolean>(false);
  const [simulationLogs, setSimulationLogs] = useState<string[]>([
    '[00:00.01] SYSTEM: Autonomous Agent Fleet connected via Simeon Jr Studios Engine',
    '[00:00.04] AGENT ALPHA: Awaiting intent compilation instructions',
    '[00:00.07] FLEET STATUS: 5/5 Agents healthy • Ready for synthesis',
  ]);

  const agentsList: AgentInfo[] = [
    {
      id: 'alpha',
      name: 'Spec & Architecture Agent',
      codename: 'Agent Alpha',
      role: 'Requirements, AST Decomposition & Schema Engineering',
      description: 'Translates natural language prompts into normalized abstract syntax trees (AST), data structures, and component dependency graphs before any code is generated.',
      metrics: '12ms parse latency • 99.8% semantic accuracy',
      status: 'success',
    },
    {
      id: 'beta',
      name: 'Code Synthesis Agent',
      codename: 'Agent Beta',
      role: 'Reactive UI, TypeScript & Tailwind Generation',
      description: 'Synthesizes clean, accessible, modern TypeScript and Tailwind CSS components. Implements functional patterns, type safety, and zero external baggage.',
      metrics: '1,450 tokens/sec synthesis • Strict TypeScript adherence',
      status: 'success',
    },
    {
      id: 'gamma',
      name: 'Diagnostic & Healer Agent',
      codename: 'Agent Gamma',
      role: 'Autonomous Linting & AST Self-Healing',
      description: 'Acts as an automated real-time compiler. Intercepts missing imports, type mismatches, or deprecated hook dependencies and heals them autonomously.',
      metrics: '100% build pass rate on preview runtime',
      status: 'success',
    },
    {
      id: 'delta',
      name: 'Security & RBAC Auditor',
      codename: 'Agent Delta',
      role: 'Vulnerability Scanning & Access Control Validation',
      description: 'Performs static analysis to ensure client-side state is protected, no sensitive credentials are exposed to the browser, and user inputs are strictly sanitized.',
      metrics: 'Zero credential leakage guarantee',
      status: 'success',
    },
    {
      id: 'epsilon',
      name: 'Universal Packaging Agent',
      codename: 'Agent Epsilon',
      role: 'Web, Android APK & Desktop Bundling',
      description: 'Compiles the verified project into native platform bridges. Generates Android Capacitor wrappers ready for APK signing and Tauri desktop binaries.',
      metrics: 'Web + Android APK + Desktop in single compile',
      status: 'success',
    },
  ];

  const handleRunSimulation = () => {
    if (isRunningSimulation) return;
    setIsRunningSimulation(true);
    setSimulationLogs(['[00:00.00] SIMULATION INITIATED: Testing 5-Agent Consensus Pipeline...']);

    setTimeout(() => {
      setSimulationLogs((prev) => [
        ...prev,
        '[00:00.42] [AGENT ALPHA] Prompt ingested: "Build crypto trading platform with live order book"',
        '[00:00.61] [AGENT ALPHA] AST parsed: 4 components, 2 WebSocket feeds, 1 state reducer',
      ]);
    }, 400);

    setTimeout(() => {
      setSimulationLogs((prev) => [
        ...prev,
        '[00:01.12] [AGENT BETA] Synthesizing PriceChart.tsx and OrderBook.tsx in TypeScript',
        '[00:01.35] [AGENT BETA] Generated 328 lines of strict TSX with Tailwind CSS tokens',
      ]);
    }, 900);

    setTimeout(() => {
      setSimulationLogs((prev) => [
        ...prev,
        '[00:01.78] [AGENT GAMMA] Compiler pass initiated: 0 syntax errors, verified types',
        '[00:02.04] [AGENT DELTA] Security audit completed: Sanitized inputs, clean state',
      ]);
    }, 1500);

    setTimeout(() => {
      setSimulationLogs((prev) => [
        ...prev,
        '[00:02.39] [AGENT EPSILON] Universal packaging active: Web bundle & Android APK manifest built',
        '[00:02.50] CONSENSUS VERIFIED: Application deployed to live interactive sandbox at 127.0.0.1:8787/preview',
      ]);
      setIsRunningSimulation(false);
    }, 2100);
  };

  const selectedAgent = agentsList.find((a) => a.id === activeTab) || agentsList[0];

  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16 antialiased">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <Cpu size={13} />
          <span>AUTONOMOUS AGENT FLEET</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          The Autonomous Dev Agents Behind APPMORA
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          Simeon Intelligence coordinates specialized autonomous agents to ensure every synthesized application is architecturally sound, type-safe, and universally deployable.
        </p>
      </div>

      {/* Agents Selector & Details */}
      <div className="grid lg:grid-cols-12 gap-8 items-start">
        {/* Left: Agent Tabs */}
        <div className="lg:col-span-4 space-y-2">
          {agentsList.map((agent) => (
            <button
              key={agent.id}
              onClick={() => setActiveTab(agent.id)}
              className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                activeTab === agent.id
                  ? 'bg-slate-900 text-white border-slate-900 shadow-md'
                  : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-mono font-bold uppercase tracking-wider ${
                    activeTab === agent.id ? 'text-indigo-400' : 'text-slate-400'
                  }`}>
                    {agent.codename}
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                </div>
                <div className="font-extrabold text-sm mt-0.5">{agent.name}</div>
                <div className={`text-xs mt-1 line-clamp-1 ${
                  activeTab === agent.id ? 'text-slate-300' : 'text-slate-500'
                }`}>
                  {agent.role}
                </div>
              </div>

              <span className={`p-1.5 rounded-lg ${activeTab === agent.id ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-400'}`}>
                <Cpu size={16} />
              </span>
            </button>
          ))}
        </div>

        {/* Right: Selected Agent Detail Card */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-3xl p-8 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-6">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-indigo-600 uppercase tracking-wider">
                <span>{selectedAgent.codename}</span>
                <span>•</span>
                <span className="text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 size={13} /> READY
                </span>
              </div>
              <h2 className="text-2xl font-black text-slate-950 mt-1">{selectedAgent.name}</h2>
              <div className="text-xs font-semibold text-slate-500 mt-0.5">{selectedAgent.role}</div>
            </div>

            <button
              onClick={onStartBuilding}
              className="self-start sm:self-auto px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              <span>Build with {selectedAgent.codename}</span>
              <ArrowRight size={14} />
            </button>
          </div>

          <div className="space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Mission & Responsibility</h4>
            <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
              {selectedAgent.description}
            </p>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-between text-xs">
            <span className="text-slate-500 font-medium">Performance Benchmark:</span>
            <span className="font-bold font-mono text-indigo-600">{selectedAgent.metrics}</span>
          </div>
        </div>
      </div>

      {/* Live Agent Console Simulator */}
      <div className="bg-slate-950 text-slate-200 rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-2xl space-y-4 font-mono">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-2.5">
            <Terminal size={18} className="text-indigo-400" />
            <span className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
              Live Multi-Agent Consensus Console
            </span>
          </div>

          <button
            onClick={handleRunSimulation}
            disabled={isRunningSimulation}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl shadow-xs transition flex items-center gap-2"
          >
            {isRunningSimulation ? (
              <>
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                <span>Agents Orchestrating...</span>
              </>
            ) : (
              <>
                <Play size={13} className="fill-white" />
                <span>Simulate Agent Coordination</span>
              </>
            )}
          </button>
        </div>

        {/* Streaming terminal box */}
        <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 h-64 overflow-y-auto text-xs space-y-2 scrollbar-none">
          {simulationLogs.map((log, idx) => (
            <div
              key={idx}
              className={`leading-relaxed ${
                log.includes('CONSENSUS VERIFIED')
                  ? 'text-emerald-400 font-bold'
                  : log.includes('SIMULATION')
                  ? 'text-amber-300 font-bold'
                  : log.includes('AGENT ALPHA')
                  ? 'text-sky-300'
                  : log.includes('AGENT BETA')
                  ? 'text-indigo-300'
                  : log.includes('AGENT GAMMA')
                  ? 'text-emerald-300'
                  : 'text-slate-400'
              }`}
            >
              {log}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
