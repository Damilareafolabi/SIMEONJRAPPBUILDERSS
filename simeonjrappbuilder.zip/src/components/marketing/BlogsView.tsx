import React, { useState } from 'react';
import { 
  Sparkles, BookOpen, Clock, Calendar, ArrowRight, X, 
  User, Tag, Check, Code2, Share2, ExternalLink
} from 'lucide-react';

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  role: string;
  date: string;
  readTime: string;
  tags: string[];
  takeaways: string[];
}

const BLOG_POSTS: BlogPost[] = [
  {
    id: 'post-1',
    title: 'Universal Runtimes: Why Multi-Platform Generation Surpasses Single-Cloud Sandboxes',
    excerpt: 'Traditional developer sandboxes trap software in a browser tab. How Appmazon bridges TypeScript code into native Android APKs, desktop executables, and serverless edge functions in one synthesis pass.',
    author: 'Simeon Jr',
    role: 'Founder & CEO, Simeon Jr Studios & Technologies',
    date: 'February 28, 2026',
    readTime: '5 min read',
    tags: ['Architecture', 'Universal Computing', 'Compilers'],
    takeaways: [
      'Isolated web containers limit real-world deployment and force costly rewrites for mobile.',
      'A universal compiler targets an intermediate AST that binds cleanly to Capacitor (APK) and Tauri (Desktop).',
      'Zero vendor lock-in allows teams to self-host and customize synthesized source code freely.',
    ],
    content: `For the past decade, web-based developer environments have treated the browser tab as the final destination. You write or generate code, preview it in an iframe, and marvel at the speed of iteration. But what happens when you actually want to distribute that software to customers?

In the traditional paradigm, the creator hits an immediate brick wall. You cannot package an iframe into an Android APK on Google Play. You cannot deploy an isolated VM to an offline-first field tablet. You are forced to hire a native mobile engineer or spend weeks untangling proprietary framework bindings.

At Simeon Intelligence / Simeon Jr Studios & Technologies, we took a fundamentally different approach with APPMORA. When our autonomous multi-agent engine synthesizes an application from plain English, it does not merely write a React component. It generates a universal software specification.

By separating the user interface declarations from platform-specific runtime bridges, APPMORA compiles the same core business logic into responsive Web SPAs, signed Android APKs via Capacitor, and cross-platform desktop executables via Tauri and Rust. The result is true software sovereignty: one prompt, every operating system.`,
  },
  {
    id: 'post-2',
    title: 'From Plain English to Signed Android APKs in 45 Seconds',
    excerpt: 'Deep-dive into the mobile compilation pipeline: How APPMORA synthesizes touch-first navigation, offline state caches, and Android Gradle wrappers directly from prompts.',
    author: 'Marcus Aurel',
    role: 'Lead Mobile & APK Systems Engineer',
    date: 'February 24, 2026',
    readTime: '6 min read',
    tags: ['Mobile', 'Android APK', 'Capacitor'],
    takeaways: [
      'Touch targets, status bars, and hardware back buttons require mobile-first design considerations.',
      'APPMORA automatically generates AndroidManifest.xml and Gradle build configs.',
      'Offline-first SQLite and LocalStorage fallbacks guarantee seamless mobile usage without network connectivity.',
    ],
    content: `Building mobile applications has historically required specialized toolchains: Android Studio, Gradle daemons, Java JDKs, and complex device emulators. For non-native developers, generating an installable APK from scratch is often intimidating.

APPMORA completely automates this pipeline. When you prompt: "Build an on-demand courier app with live GPS tracking and customer notifications", our Universal Packaging Agent generates:
1. Touch-optimized layout with 44px+ touch targets and swipeable drawers.
2. Capacitor bridge configuration mapped to Android hardware APIs.
3. Automated build scripts that produce a debug APK ready to side-load onto any Android phone or tablet.

Creators can test the mobile viewport live in our sandbox with our interactive phone frame, and immediately download the compiled repository or trigger an automated mobile APK build.`,
  },
  {
    id: 'post-3',
    title: 'Multi-Agent Consensus: Eliminating Compiler Hallucinations in Code Generation',
    excerpt: 'Why single LLM prompts hallucinate syntax errors, and how Simeon Intelligence designed a multi-agent pipeline with self-healing feedback loops to produce pristine TypeScript.',
    author: 'Dr. Tariq Al-Mansoor',
    role: 'Head of Autonomous AI Research',
    date: 'February 19, 2026',
    readTime: '7 min read',
    tags: ['AI Research', 'Multi-Agent', 'Self-Healing'],
    takeaways: [
      'Single-shot LLMs suffer from a 14-22% syntax error rate when generating complex multi-file projects.',
      'APPMORA uses 5 distinct agent roles: Spec Architect, Synthesizer, Healer, Auditor, and Packager.',
      'The Healer Agent acts as an automatic TypeScript linter that intercepts compiler errors before execution.',
    ],
    content: `The primary reason AI code generation tools struggle with large applications is token isolation. A single language model attempting to simultaneously invent data schemas, write hundred-line UI components, manage state hooks, and write CSS will inevitably make subtle semantic errors—missing imports, incorrect prop types, or broken hook dependency arrays.

To solve this, Simeon Intelligence developed the Multi-Agent Consensus Architecture. Instead of one model doing everything, APPMORA coordinates five specialized agents:

1. **Spec & Architecture Agent**: Outlines the schema, data models, and component tree.
2. **Synthesis Engine Agent**: Writes modular TypeScript and Tailwind CSS code.
3. **Diagnostic & Healer Agent**: Runs a simulated TypeScript compiler pass and fixes broken imports or mismatches instantly.
4. **Security Auditor**: Checks for leaked secrets, sanitized inputs, and RBAC permissions.
5. **Universal Packaging Agent**: Prepares build bundles for Web, APK, and Desktop.

This checks-and-balances pipeline drives build success rates above 99.4%, giving users production-ready software without manual debugging.`,
  },
  {
    id: 'post-4',
    title: 'The Death of Boilerplate: Prompt-to-Production in 60 Seconds',
    excerpt: 'Modern web development requires over 3,000 files of boilerplate before writing a single feature. Here is how modern declarative engines replace setup fatigue.',
    author: 'Elena Vance',
    role: 'Chief Technology Officer',
    date: 'February 15, 2026',
    readTime: '4 min read',
    tags: ['Developer Experience', 'Productivity', 'Future of Dev'],
    takeaways: [
      'Engineers spend up to 40% of project time configuring linters, bundlers, and styling systems.',
      'Instant interactive sandboxes eliminate local environment configuration friction.',
      'Visual Canvas plus Prompt Code synthesis creates a bidirectional workflow for engineers and designers.',
    ],
    content: `Setting up a modern web application in 2026 is exhausting. Even with modern frameworks, a developer must configure Vite or Next.js, set up Tailwind or CSS variables, configure TypeScript paths, configure ESLint and Prettier, set up routing, establish state management, and configure Docker containers.

By the time the first real user feature is coded, hours or days have vanished into configuration files.

APPMORA proves that this boilerplate is completely automatable. By understanding high-level intent, our engine sets up optimal dependencies, generates accessible UI primitives, and wires reactive state variables in seconds. Developers can start directly from a fully functional, live-tested prototype and focus on business value rather than configuration trivia.`,
  },
];

export function BlogsView() {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12 antialiased">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <Sparkles size={13} />
          <span>RESEARCH & INSIGHTS</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          Engineering the Universal Software Frontier
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          Deep-dives into universal software compilation, multi-agent AI consensus, mobile APK synthesis, and the future of software development from Simeon Jr Studios & Technologies.
        </p>
      </div>

      {/* Blog Cards Grid */}
      <div className="grid md:grid-cols-2 gap-8">
        {BLOG_POSTS.map((post) => (
          <article
            key={post.id}
            className="bg-white border border-slate-200 hover:border-indigo-400 rounded-3xl p-7 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group cursor-pointer"
            onClick={() => setSelectedPost(post)}
          >
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                {post.tags.map((t, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100"
                  >
                    {t}
                  </span>
                ))}
              </div>

              <h3 className="text-xl font-extrabold text-slate-900 group-hover:text-indigo-600 transition-colors leading-snug">
                {post.title}
              </h3>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {post.excerpt}
              </p>
            </div>

            <div className="pt-6 border-t border-slate-100 mt-6 flex items-center justify-between text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-slate-900 text-white font-bold flex items-center justify-center text-[10px]">
                  {post.author[0]}
                </div>
                <div>
                  <div className="font-semibold text-slate-900">{post.author}</div>
                  <div className="text-[10px] text-slate-500">{post.date}</div>
                </div>
              </div>

              <span className="flex items-center gap-1 font-semibold text-indigo-600 group-hover:translate-x-1 transition-transform">
                <span>Read Article</span>
                <ArrowRight size={13} />
              </span>
            </div>
          </article>
        ))}
      </div>

      {/* Full Article Reader Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 flex flex-col relative animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-6 sm:p-8 border-b border-slate-200 sticky top-0 bg-white/95 backdrop-blur-md z-10 flex items-start justify-between gap-4">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  {selectedPost.tags.map((t, idx) => (
                    <span key={idx} className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-50 text-indigo-700">
                      {t}
                    </span>
                  ))}
                  <span className="text-xs text-slate-400">• {selectedPost.readTime}</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                  {selectedPost.title}
                </h2>
              </div>

              <button
                onClick={() => setSelectedPost(null)}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition shrink-0"
              >
                <X size={20} />
              </button>
            </div>

            {/* Author info */}
            <div className="px-6 sm:px-8 py-3 bg-slate-50 border-b border-slate-100 flex items-center gap-3 text-xs text-slate-600">
              <div className="w-8 h-8 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                {selectedPost.author[0]}
              </div>
              <div>
                <span className="font-bold text-slate-900">{selectedPost.author}</span>
                <span className="mx-1.5 text-slate-300">|</span>
                <span>{selectedPost.role}</span>
                <span className="mx-1.5 text-slate-300">|</span>
                <span>{selectedPost.date}</span>
              </div>
            </div>

            {/* Content Body */}
            <div className="p-6 sm:p-8 space-y-6 text-slate-800 text-sm sm:text-base leading-relaxed">
              {/* Key Takeaways Box */}
              <div className="bg-indigo-50/70 border border-indigo-200/80 rounded-2xl p-5 space-y-2.5">
                <div className="text-xs font-bold uppercase tracking-wider text-indigo-900 flex items-center gap-1.5">
                  <Sparkles size={14} className="text-indigo-600" />
                  <span>Key Architectural Takeaways</span>
                </div>
                <ul className="space-y-1.5 text-xs sm:text-sm text-indigo-950">
                  {selectedPost.takeaways.map((takeaway, tIdx) => (
                    <li key={tIdx} className="flex items-start gap-2">
                      <Check size={14} className="text-indigo-600 shrink-0 mt-0.5" />
                      <span>{takeaway}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="prose prose-slate max-w-none whitespace-pre-wrap">
                {selectedPost.content}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-6 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Published by Simeon Jr Studios & Technologies
              </span>
              <button
                onClick={() => setSelectedPost(null)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition"
              >
                Close Article
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
