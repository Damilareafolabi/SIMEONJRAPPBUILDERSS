import React, { useState } from 'react';
import { 
  Sparkles, Award, Quote, CheckCircle2, ArrowRight, 
  Send, Mail, Calendar, ShieldCheck, UserCheck, Building
} from 'lucide-react';

export function CeoView() {
  const [briefingName, setBriefingName] = useState('');
  const [briefingEmail, setBriefingEmail] = useState('');
  const [briefingCompany, setBriefingCompany] = useState('');
  const [briefingNote, setBriefingNote] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmitBriefing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!briefingName || !briefingEmail) return;
    setSubmitted(true);
  };

  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16 antialiased">
      {/* Hero Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <UserCheck size={13} />
          <span>EXECUTIVE LEADERSHIP & VISION</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          A Message from Our Founder & CEO
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          The engineering vision, philosophy, and future of universal computing with Simeon Jr, Chief Executive Officer of Simeon Jr Studios & Technologies.
        </p>
      </div>

      {/* CEO Keynote Banner */}
      <div className="bg-linear-to-br from-slate-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl relative overflow-hidden">
        <div className="max-w-4xl mx-auto grid md:grid-cols-12 gap-8 items-center">
          {/* Avatar & Badge */}
          <div className="md:col-span-4 flex flex-col items-center text-center space-y-3">
            <div className="w-32 h-32 rounded-3xl bg-linear-to-tr from-indigo-500 to-violet-600 p-1 shadow-2xl">
              <div className="w-full h-full rounded-[22px] bg-slate-900 flex items-center justify-center text-white">
                <span className="text-4xl font-black tracking-tighter">SJ</span>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-extrabold text-white">Simeon Jr</h3>
              <div className="text-xs text-indigo-400 font-semibold">
                Founder & Chief Executive Officer
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Simeon Jr Studios & Technologies
              </div>
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-900/60 border border-indigo-700/60 text-indigo-300 text-[11px] font-semibold">
              <Sparkles size={12} className="text-amber-300" />
              <span>Architect of Universal Compute</span>
            </div>
          </div>

          {/* Letter / Quote */}
          <div className="md:col-span-8 space-y-4">
            <Quote className="w-8 h-8 text-indigo-400 opacity-60" />
            <h2 className="text-xl sm:text-2xl font-bold text-slate-100 leading-snug">
              "Software should not be locked behind proprietary silos or brittle cloud sandboxes. If you can think it, you should be able to run it everywhere."
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              When we started Simeon Jr Studios & Technologies, we observed that the developer tooling landscape was becoming increasingly fragmented. Web IDEs could only run web apps. Mobile required separate toolchains. Desktop required specialized C++ or Rust bindings.
            </p>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              We built APPMORA as the universal antidote: a single unified software foundry where your prompt yields production-ready code that runs natively across Web, Android APK, iOS, and Desktop. Our goal is to empower every founder, engineer, and organization with autonomous, unconstrained creation.
            </p>
            <div className="pt-2 flex items-center gap-3 text-xs text-indigo-300 font-mono">
              <span>— Simeon Jr, CEO</span>
              <span>•</span>
              <span>Lagos & Global Distributed</span>
            </div>
          </div>
        </div>
      </div>

      {/* CEO's 4 Core Pillars */}
      <div className="space-y-6">
        <h2 className="text-2xl font-extrabold text-slate-900 text-center">
          The CEO's 4 Pillars for the Universal Age
        </h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-sm">
              01
            </div>
            <h3 className="font-bold text-slate-900 text-base">Unbroken Portability</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              No developer should ever have to rewrite an application from scratch just because a customer requested an Android APK or desktop binary.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-sm">
              02
            </div>
            <h3 className="font-bold text-slate-900 text-base">Deterministic Output</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Eliminate AI code hallucination through strict multi-agent consensus and automatic TypeScript compilation checks.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center font-bold text-sm">
              03
            </div>
            <h3 className="font-bold text-slate-900 text-base">True Ownership</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              All generated code is 100% owned by the creator. No hidden subscription fees to access your own source repositories.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-sm">
              04
            </div>
            <h3 className="font-bold text-slate-900 text-base">Human Craftsmanship</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Technology exists to elevate human capability, pairing autonomous speed with deliberate, human-centric design aesthetics.
            </p>
          </div>
        </div>
      </div>

      {/* Schedule Executive Briefing Form */}
      <div className="bg-white border border-slate-200 rounded-3xl p-8 sm:p-12 shadow-sm max-w-3xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 uppercase tracking-wider">
            <Building size={14} />
            <span>Executive Briefing</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900">
            Connect with the Executive Team
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Discuss enterprise deployment, private on-premises installations, or strategic partnerships directly with Simeon Jr Studios leadership.
          </p>
        </div>

        {submitted ? (
          <div className="p-8 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-3 animate-in fade-in duration-300">
            <div className="w-12 h-12 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 size={24} />
            </div>
            <h3 className="text-base font-bold text-emerald-950">Briefing Request Received</h3>
            <p className="text-xs text-emerald-800 max-w-md mx-auto">
              Thank you, {briefingName}. The Office of the CEO at Simeon Jr Studios & Technologies will review your request and reach out to {briefingEmail} within 24 hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmitBriefing} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={briefingName}
                  onChange={(e) => setBriefingName(e.target.value)}
                  placeholder="Jane Doe"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-hidden focus:border-indigo-500 focus:bg-white transition"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">Corporate Email</label>
                <input
                  type="email"
                  required
                  value={briefingEmail}
                  onChange={(e) => setBriefingEmail(e.target.value)}
                  placeholder="jane@company.com"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-hidden focus:border-indigo-500 focus:bg-white transition"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Company / Organization</label>
              <input
                type="text"
                value={briefingCompany}
                onChange={(e) => setBriefingCompany(e.target.value)}
                placeholder="Enterprise Technologies Inc."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-hidden focus:border-indigo-500 focus:bg-white transition"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700">Agenda / Discussion Topic</label>
              <textarea
                rows={3}
                value={briefingNote}
                onChange={(e) => setBriefingNote(e.target.value)}
                placeholder="We would like to explore private cloud multi-agent deployment for our internal engineering teams..."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-hidden focus:border-indigo-500 focus:bg-white transition"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow transition flex items-center justify-center gap-2"
            >
              <Send size={15} />
              <span>Submit Executive Briefing Request</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
