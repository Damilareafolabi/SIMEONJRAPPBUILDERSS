import React, { useState, useRef, useEffect } from 'react';
import { 
  MessageSquare, X, Send, Bot, Sparkles, ArrowRight, 
  RotateCcw, Check, Maximize2, Minimize2, Terminal, Code2, 
  Layers, Smartphone, ExternalLink
} from 'lucide-react';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  suggestedPrompt?: string;
  categoryTag?: string;
}

interface ChatbotWidgetProps {
  isOpen: boolean;
  onToggle: () => void;
  onSendPromptToBuilder: (promptText: string) => void;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'm-1',
    sender: 'bot',
    text: 'Welcome to APPMORA! I am your Software Factory Assistant from Simeon Intelligence. How can I help you design, architect, build, or evolve your next application today?',
    timestamp: 'Just now',
    suggestedPrompt: 'Build a trading platform with live dashboards and user accounts',
    categoryTag: 'Universal Software',
  },
];

const PRESET_CHIPS = [
  'Build a crypto trading app with live charts',
  'Create an AI chat app with multi-model switcher',
  'Design an on-demand food delivery app with GPS',
  'How do I export to an Android APK or iOS?',
  'What makes APPMORA truly universal?',
];

export function ChatbotWidget({ isOpen, onToggle, onSendPromptToBuilder }: ChatbotWidgetProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, isTyping]);

  const handleSend = (textToSend?: string) => {
    const text = textToSend || inputValue;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputValue('');
    setIsTyping(true);

    // AI response simulation with Simeon Intelligence
    setTimeout(() => {
      const lower = text.toLowerCase();
      let botReply = '';
      let promptSnippet: string | undefined = undefined;
      let categoryTag = 'General';

      if (lower.includes('trading') || lower.includes('crypto') || lower.includes('stock')) {
        botReply =
          'For algorithmic & high-frequency trading platforms, APPMORA configures high-speed WebSocket market feeds, SVG candlestick charts, real-time depth order books, and risk-checked order execution panels. I have prepared an optimized prompt for you:';
        promptSnippet = 'Build a high-performance crypto and equities trading terminal with real-time order books, live depth charts, and automated limit order triggers';
        categoryTag = 'Trading Platform';
      } else if (lower.includes('apk') || lower.includes('android') || lower.includes('mobile') || lower.includes('ios')) {
        botReply =
          'APPMORA compiles all generated code into native mobile bundles! Our Universal Packaging Agent generates Capacitor and React Native bridges ready for Android APK signing and iOS IPA packaging. Here is a mobile-ready prompt you can try right now:';
        promptSnippet = 'Build a mobile app and web app for a courier delivery service with live package routing, driver dispatch, and customer notifications';
        categoryTag = 'Mobile / APK';
      } else if (lower.includes('ai') || lower.includes('chat') || lower.includes('llm') || lower.includes('assistant')) {
        botReply =
          'Our multi-model AI studio architecture lets you combine Gemini, Claude, GPT, and custom local models under a single interface with streaming tokens, code sandbox execution, and persistent chat sessions.';
        promptSnippet = 'Create a multi-app AI platform like ChatGPT and Gemini in one app with prompt templates and code playground';
        categoryTag = 'AI Platform';
      } else if (lower.includes('universal') || lower.includes('why') || lower.includes('different') || lower.includes('compare')) {
        botReply =
          'Unlike traditional single-environment platforms that lock you into isolated web containers, APPMORA is universal: a single prompt compiles simultaneously to responsive Web, native Android APK, desktop binaries (Tauri), and backend microservices. Powered by Simeon Intelligence, you get zero vendor lock-in and complete source code ownership.';
        categoryTag = 'APPMORA Architecture';
      } else if (lower.includes('saas') || lower.includes('crm') || lower.includes('dashboard')) {
        botReply =
          'Enterprise SaaS requires clean multi-tenant schemas, billing workflows, team permissions, and real-time revenue analytics. Here is a comprehensive prompt tailored for a production-grade SaaS dashboard:';
        promptSnippet = 'Create a SaaS business app with dashboard, customer CRM, subscription billing tiers, and team role permissions';
        categoryTag = 'SaaS / Enterprise';
      } else {
        botReply = `Great question! The APPMORA engine by Simeon Intelligence can scaffold, test, and deploy this in seconds. I have generated a blueprint prompt ready for our autonomous agents:`;
        promptSnippet = `Build a universal ${text} with responsive UI, real-time data sync, and interactive controls`;
        categoryTag = 'Custom App';
      }

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: botReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedPrompt: promptSnippet,
        categoryTag,
      };

      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 900);
  };

  const handleResetChat = () => {
    setMessages(INITIAL_MESSAGES);
  };

  return (
    <>
      {/* Floating Trigger Button (when closed) */}
      {!isOpen && (
        <button
          id="open-chatbot-btn"
          onClick={onToggle}
          aria-label="Open AI Assistant"
          className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-4 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-2xl transition-all duration-300 hover:scale-105 group border border-indigo-400/40"
        >
          <div className="relative">
            <Bot className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full" />
          </div>
          <div className="text-left hidden sm:block">
            <div className="text-xs font-bold leading-tight">AI Assistant</div>
            <div className="text-[10px] text-indigo-200">Simeon Jr Studios</div>
          </div>
          <Sparkles className="w-4 h-4 text-amber-300 group-hover:rotate-12 transition-transform" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div
          id="appmora-chatbot-drawer"
          className={`fixed z-50 bg-white border border-slate-200 shadow-2xl rounded-2xl flex flex-col transition-all duration-300 overflow-hidden ${
            isExpanded
              ? 'inset-4 sm:inset-10'
              : 'bottom-4 right-4 sm:bottom-6 sm:right-6 w-[95vw] sm:w-[440px] h-[600px] max-h-[85vh]'
          }`}
        >
          {/* Header */}
          <div className="bg-slate-900 text-white px-4 py-3.5 flex items-center justify-between border-b border-slate-800 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-linear-to-tr from-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-xs">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold tracking-tight">APPMORA AI Assistant</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-semibold border border-emerald-500/30">
                    ONLINE
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 flex items-center gap-1">
                  <span>Powered by</span>
                  <span className="text-indigo-300 font-semibold">Simeon Intelligence</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleResetChat}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                title="Reset conversation"
              >
                <RotateCcw size={14} />
              </button>
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                title={isExpanded ? 'Collapse' : 'Expand'}
              >
                {isExpanded ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
              </button>
              <button
                id="close-chatbot-btn"
                onClick={onToggle}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
                title="Close chat"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'bot' && (
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 mt-1 shadow-xs">
                    <Sparkles size={14} />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-indigo-600 text-white rounded-tr-xs shadow-xs'
                      : 'bg-white text-slate-800 border border-slate-200/80 rounded-tl-xs shadow-xs'
                  }`}
                >
                  {msg.categoryTag && (
                    <div className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider mb-1.5 flex items-center gap-1">
                      <Terminal size={11} />
                      <span>{msg.categoryTag}</span>
                    </div>
                  )}

                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  {/* If there's an action prompt to send to builder */}
                  {msg.suggestedPrompt && (
                    <div className="mt-3 pt-3 border-t border-slate-100 space-y-2">
                      <div className="bg-slate-900 text-slate-200 p-2.5 rounded-xl font-mono text-[11px] border border-slate-800 flex items-start gap-2">
                        <Code2 size={13} className="text-indigo-400 shrink-0 mt-0.5" />
                        <span className="flex-1 select-all">{msg.suggestedPrompt}</span>
                      </div>
                      <button
                        onClick={() => {
                          if (msg.suggestedPrompt) {
                            onSendPromptToBuilder(msg.suggestedPrompt);
                          }
                        }}
                        className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-linear-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-xs rounded-xl shadow-xs transition"
                      >
                        <Sparkles size={13} className="text-amber-300" />
                        <span>Send to App Factory & Build</span>
                        <ArrowRight size={13} />
                      </button>
                    </div>
                  )}

                  <div
                    className={`text-[9px] mt-1.5 ${
                      msg.sender === 'user' ? 'text-indigo-200 text-right' : 'text-slate-400'
                    }`}
                  >
                    {msg.timestamp}
                  </div>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-2.5 items-center text-slate-400 text-xs pl-1">
                <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                  <Bot size={13} />
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                  <span className="ml-1 text-[11px] text-slate-500">Simeon Jr Studios AI formulating architecture...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Preset quick prompt chips */}
          <div className="p-2.5 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto shrink-0 scrollbar-none">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0 pl-1">
              Suggestions:
            </span>
            {PRESET_CHIPS.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(chip)}
                className="shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-600 border border-slate-200/60 transition"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Input Footer */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
          >
            <input
              id="chatbot-input-field"
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask anything or request an app architecture..."
              className="flex-1 bg-slate-100 text-slate-900 placeholder:text-slate-400 text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-slate-200 outline-hidden focus:border-indigo-500 focus:bg-white transition"
            />
            <button
              id="chatbot-submit-btn"
              type="submit"
              disabled={!inputValue.trim() || isTyping}
              className="p-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white rounded-xl transition shadow-xs shrink-0"
            >
              <Send size={15} />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
