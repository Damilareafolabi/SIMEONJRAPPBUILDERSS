import React, { useState, useEffect } from 'react';
import { Play, Pause, RefreshCw, Sparkles, ChevronRight, Layers, ExternalLink } from 'lucide-react';
import { DYNAMIC_CONCEPTS, DynamicConcept } from '../../data/dynamicConcepts';

interface ConceptShowcaseBarProps {
  currentConcept: DynamicConcept;
  onSelectConcept: (concept: DynamicConcept) => void;
  isAutoChanging: boolean;
  onToggleAutoChanging: () => void;
}

export function ConceptShowcaseBar({
  currentConcept,
  onSelectConcept,
  isAutoChanging,
  onToggleAutoChanging,
}: ConceptShowcaseBarProps) {
  const [progress, setProgress] = useState(0);

  // Smooth progress bar update
  useEffect(() => {
    if (!isAutoChanging) {
      setProgress(0);
      return;
    }

    const intervalTime = 100; // update every 100ms
    const totalDuration = 10000; // 10s per concept
    const step = (intervalTime / totalDuration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          return 0;
        }
        return prev + step;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isAutoChanging, currentConcept.id]);

  return (
    <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 pt-4 pb-2 antialiased">
      <div className="bg-white/90 backdrop-blur-md border border-slate-200/90 rounded-2xl p-3 sm:p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Left: Concept Info & Status */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Sparkles size={16} className="text-amber-400" />
          </div>
          <div className="truncate">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                Dynamic Concept Engine
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                {currentConcept.badge}
              </span>
            </div>
            <div className="text-xs sm:text-sm font-bold text-slate-900 truncate">
              {currentConcept.name} — <span className="font-medium text-slate-500">{currentConcept.tagline}</span>
            </div>
          </div>
        </div>

        {/* Center: Concept Selector Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          {DYNAMIC_CONCEPTS.map((concept) => {
            const isSelected = concept.id === currentConcept.id;
            return (
              <button
                key={concept.id}
                onClick={() => onSelectConcept(concept)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all shrink-0 flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-xs font-bold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: concept.primaryColor }}
                />
                <span>{concept.name.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Right: Auto-change Controls & Timer Progress */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <div className="flex flex-col items-end gap-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-slate-500">
                {isAutoChanging ? 'Auto-cycling (10s)' : 'Paused'}
              </span>
              <button
                onClick={onToggleAutoChanging}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-700 transition"
                title={isAutoChanging ? 'Pause auto-changing' : 'Resume auto-changing'}
                aria-label="Toggle auto-changing concept"
              >
                {isAutoChanging ? <Pause size={14} /> : <Play size={14} />}
              </button>
            </div>
            {/* Countdown progress bar */}
            <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-600 transition-all duration-100 rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
