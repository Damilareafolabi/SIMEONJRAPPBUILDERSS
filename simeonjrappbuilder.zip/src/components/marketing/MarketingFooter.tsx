import React from 'react';
import { 
  Sparkles, Bot, ShieldCheck, Github, Twitter, Linkedin, 
  ArrowRight, Globe, Smartphone, Monitor, Cpu, Layers 
} from 'lucide-react';
import { MarketingTab } from './MarketingNavbar';

interface MarketingFooterProps {
  onSelectTab: (tab: MarketingTab) => void;
  onOpenChatbot: () => void;
}

export function MarketingFooter({ onSelectTab, onOpenChatbot }: MarketingFooterProps) {
  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 pt-16 pb-12 antialiased">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Top Call to Action Banner */}
        <div className="bg-linear-to-r from-indigo-950 via-slate-900 to-violet-950 border border-indigo-800/50 rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl">
          <div className="absolute -top-24 -left-24 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="max-w-2xl mx-auto space-y-4 relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-900/60 border border-indigo-700/60 text-indigo-300 text-xs font-semibold">
              <Sparkles size={13} className="text-amber-300" />
              <span>Universal App Generation Engine</span>
            </div>

            <h3 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              Ready to build universal applications in seconds?
            </h3>

            <p className="text-sm sm:text-base text-slate-300">
              Create web software, native Android APKs, cross-platform desktop executables, and multi-app suites from natural language prompts.
            </p>

            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => {
                  onSelectTab('home');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-6 py-3 bg-white hover:bg-slate-100 text-slate-950 text-xs sm:text-sm font-bold rounded-xl shadow-lg transition flex items-center gap-2"
              >
                <span>Start Building for Free</span>
                <ArrowRight size={15} />
              </button>

              <button
                onClick={onOpenChatbot}
                className="px-5 py-3 bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs sm:text-sm font-semibold rounded-xl border border-indigo-500/50 transition flex items-center gap-2"
              >
                <Bot size={15} />
                <span>Ask AI Assistant</span>
              </button>
            </div>
          </div>
        </div>

        {/* 4 Navigation Columns */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 pt-4">
          {/* Brand Info */}
          <div className="col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-extrabold shadow-sm">
                <Sparkles size={18} className="text-amber-300" />
              </div>
              <div>
                <span className="text-lg font-black text-white tracking-tight">APPMORA</span>
                <div className="text-[11px] text-indigo-400 font-medium">
                  Simeon Intelligence Software Factory
                </div>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              The universal autonomous software foundry — compiling plain English into production-grade multi-platform applications across Web, Android APK, and Desktop.
            </p>

            <div className="flex items-center gap-3 text-slate-400">
              <span className="text-xs">Supported Targets:</span>
              <div className="flex items-center gap-1.5 text-white">
                <span className="p-1 rounded bg-slate-900 border border-slate-800" title="Web App"><Globe size={14} /></span>
                <span className="p-1 rounded bg-slate-900 border border-slate-800" title="Mobile & APK"><Smartphone size={14} /></span>
                <span className="p-1 rounded bg-slate-900 border border-slate-800" title="Desktop Native"><Monitor size={14} /></span>
                <span className="p-1 rounded bg-slate-900 border border-slate-800" title="Autonomous Multi-Agent"><Cpu size={14} /></span>
              </div>
            </div>
          </div>

          {/* Solutions */}
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-white">Product & Engine</div>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onSelectTab('home')} className="hover:text-white transition">
                  Prompt App Factory
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('pricing')} className="hover:text-white text-indigo-400 font-semibold transition">
                  Pricing Plans
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('others')} className="hover:text-white text-indigo-400 font-semibold transition">
                  Workspace & Others
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('portfolio')} className="hover:text-white transition">
                  Live App Portfolio
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('services')} className="hover:text-white transition">
                  Enterprise Services
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('canvas')} className="hover:text-white transition">
                  Visual Canvas Studio
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('agents')} className="hover:text-white transition">
                  Autonomous AI Agents
                </button>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-white">Company</div>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onSelectTab('about')} className="hover:text-white transition">
                  About Us
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('ceo')} className="hover:text-white transition">
                  CEO Keynote & Vision
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('team')} className="hover:text-white transition">
                  Our Engineering Team
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('style')} className="hover:text-white transition">
                  Style & Design System
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('blogs')} className="hover:text-white transition">
                  Blogs & Research
                </button>
              </li>
            </ul>
          </div>

          {/* Technologies & Workspace */}
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-white">Universal Runtimes</div>
            <ul className="space-y-2 text-xs">
              <li className="text-slate-400">Next.js & Vite Hybrid</li>
              <li className="text-slate-400">Native Android APK Compiler</li>
              <li className="text-slate-400">iOS IPA Bridge</li>
              <li className="text-slate-400">Tauri Cross-Desktop</li>
              <li className="text-slate-400">Simeon Jr Studios Core Engine</li>
            </ul>
          </div>
        </div>

        {/* Bottom Credits & Copyright */}
        <div className="border-t border-slate-800/80 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} APPMORA. Developed and powered by <strong className="text-slate-300 font-semibold">Simeon Intelligence / Simeon Jr Studios & Technologies</strong>. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span>Universal Software Standards</span>
            <span>•</span>
            <span>Zero Lock-in Architecture</span>
            <span>•</span>
            <span>Local & Cloud Multi-Agent</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
