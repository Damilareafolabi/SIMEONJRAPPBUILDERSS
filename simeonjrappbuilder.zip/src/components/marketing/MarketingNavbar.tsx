import React, { useState } from 'react';
import { 
  Sparkles, Layers, Bot, Menu, X, ArrowRight, Code2, 
  Palette, Users, ShieldCheck, Cpu, BookOpen, Briefcase, 
  UserCheck, ExternalLink, Box, TrendingUp, Search, RefreshCw, Zap
} from 'lucide-react';

export type MarketingTab = 
  | 'home'
  | 'about'
  | 'services'
  | 'portfolio'
  | 'projects'
  | 'pricing'
  | 'others'
  | 'blogs'
  | 'style'
  | 'ceo'
  | 'team'
  | 'agents'
  | 'canvas'
  | 'evolve'
  | 'growth'
  | 'scout'
  | 'readiness';

interface MarketingNavbarProps {
  activeTab: MarketingTab;
  onSelectTab: (tab: MarketingTab) => void;
  onOpenChatbot: () => void;
  onStartBuild: () => void;
  onOpenWorkspaceModal?: (tab?: string) => void;
}

export function MarketingNavbar({
  activeTab,
  onSelectTab,
  onOpenChatbot,
  onStartBuild,
  onOpenWorkspaceModal,
}: MarketingNavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: MarketingTab; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Home', icon: <Box size={14} /> },
    { id: 'readiness', label: 'Readiness', icon: <ShieldCheck size={14} /> },
    { id: 'evolve', label: 'Evolve', icon: <RefreshCw size={14} /> },
    { id: 'growth', label: 'Growth', icon: <TrendingUp size={14} /> },
    { id: 'scout', label: 'Scout', icon: <Search size={14} /> },
    { id: 'about', label: 'About', icon: <BookOpen size={14} /> },
    { id: 'services', label: 'Services', icon: <Briefcase size={14} /> },
    { id: 'portfolio', label: 'Portfolio', icon: <Layers size={14} /> },
    { id: 'projects', label: 'Projects', icon: <Code2 size={14} /> },
    { id: 'pricing', label: 'Pricing', icon: <Briefcase size={14} /> },
    { id: 'others', label: 'Others', icon: <Layers size={14} /> },
    { id: 'blogs', label: 'Blogs', icon: <BookOpen size={14} /> },
    { id: 'style', label: 'Style', icon: <Palette size={14} /> },
    { id: 'ceo', label: 'CEO', icon: <UserCheck size={14} /> },
    { id: 'team', label: 'Our Team', icon: <Users size={14} /> },
    { id: 'agents', label: 'Agents', icon: <Cpu size={14} /> },
  ];

  const handleNavClick = (tab: MarketingTab) => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs">
      {/* Top micro-bar for brand identity */}
      <div className="bg-slate-900 text-slate-300 text-[11px] py-1.5 px-4 sm:px-8 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-extrabold text-white tracking-wider">APPMORA</span>
          <span className="text-slate-500">|</span>
          <span className="hidden sm:inline text-slate-300 font-medium">Simeon Intelligence Software Factory — From Idea to Software</span>
          <span className="sm:hidden text-slate-300">Software Factory</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[10px] uppercase font-bold tracking-wider text-indigo-300">
            Simeon Jr Studios & Technologies
          </span>
          <button
            onClick={onOpenChatbot}
            className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-500 text-white px-2.5 py-0.5 rounded font-semibold transition text-[10px]"
          >
            <Bot size={11} />
            <span>AI Bot</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo & Brand */}
        <div 
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-900 via-indigo-900 to-indigo-700 flex items-center justify-center text-white font-extrabold shadow-sm group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5 text-indigo-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black text-slate-950 tracking-tight">APPMORA</span>
              <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                FACTORY
              </span>
            </div>
            <div className="text-[10px] font-medium text-slate-500">
              Simeon Intelligence Software Factory
            </div>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-0.5 overflow-x-auto py-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-link-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Action Buttons */}
        <div className="hidden sm:flex items-center gap-2">
          <button
            onClick={() => onOpenWorkspaceModal ? onOpenWorkspaceModal('pricing') : handleNavClick('pricing')}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 transition flex items-center gap-1.5"
            title="Workspace, Membership & Token Settings"
          >
            <Sparkles size={13} className="text-amber-500" />
            <span>Workspace</span>
            <span className="hidden md:inline text-[10px] bg-white border border-slate-200 text-indigo-700 px-1 py-0.2 rounded font-bold">
              Local
            </span>
          </button>

          <button
            onClick={() => handleNavClick('canvas')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition flex items-center gap-1.5 ${
              activeTab === 'canvas'
                ? 'bg-indigo-50 border-indigo-300 text-indigo-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
            title="Visual Canvas Drag & Drop Studio"
          >
            <Palette size={13} className="text-indigo-600" />
            <span>Visual Canvas</span>
          </button>

          <button
            id="nav-build-cta"
            onClick={onStartBuild}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 group"
          >
            <span>Launch Factory</span>
            <ArrowRight size={13} className="group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Mobile menu toggle */}
        <div className="flex items-center gap-2 xl:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-6 space-y-2 shadow-xl animate-in slide-in-from-top-2 duration-200">
          <div className="grid grid-cols-2 gap-1.5 pt-2">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-2.5 rounded-xl text-xs font-bold text-left flex items-center gap-2 transition ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className={isActive ? 'text-indigo-300' : 'text-slate-400'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 flex flex-col gap-2 border-t border-slate-100">
            <button
              onClick={() => handleNavClick('canvas')}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-slate-100 text-slate-800 flex items-center justify-center gap-2"
            >
              <Palette size={15} className="text-indigo-600" />
              <span>Visual Canvas Drag & Drop</span>
            </button>
            <button
              onClick={() => {
                onStartBuild();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center gap-2 shadow-sm"
            >
              <Sparkles size={15} />
              <span>Launch App Factory & Build</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
