import React from 'react';
import { 
  Sliders, User, CreditCard, Cpu, Layers, Github, ShieldCheck, 
  Smartphone, Terminal, Key, ArrowRight, CheckCircle2, Box, Sparkles 
} from 'lucide-react';
import { WorkspaceTab } from '../pricing/WorkspaceSettingsModal';

interface OthersViewProps {
  onOpenWorkspaceTab: (tab: WorkspaceTab) => void;
}

export function OthersView({ onOpenWorkspaceTab }: OthersViewProps) {
  const sections = [
    {
      tab: 'membership' as WorkspaceTab,
      title: 'Membership & Quotas',
      desc: 'View active subscription tier, monthly credit utilization, rollover balance, and download historic PDF invoices.',
      icon: <ShieldCheck className="w-6 h-6 text-indigo-600" />,
      badge: 'Account Management',
    },
    {
      tab: 'payments' as WorkspaceTab,
      title: 'Payments & Billing',
      desc: 'Configure default payment credit cards, add secondary cards, set VAT / Tax IDs, and manage automated billing contacts.',
      icon: <CreditCard className="w-6 h-6 text-indigo-600" />,
      badge: 'PCI-DSS Compliant',
    },
    {
      tab: 'token' as WorkspaceTab,
      title: 'AI Tokens & Credits',
      desc: 'Monitor token consumption across synthesis, multi-agent consensus, and APK packaging. Buy one-click booster packs.',
      icon: <Cpu className="w-6 h-6 text-indigo-600" />,
      badge: 'Real-time Quota',
    },
    {
      tab: 'profile' as WorkspaceTab,
      title: 'Creator Profile & API Keys',
      desc: 'Manage your creator identity, organization branding, preferred targets, and generate secret CLI developer keys.',
      icon: <User className="w-6 h-6 text-indigo-600" />,
      badge: 'Simeon Jr Studios',
    },
    {
      tab: 'integrations' as WorkspaceTab,
      title: 'Cloud & Database Integrations',
      desc: 'Connect Google Cloud Run, Firebase Firestore, Supabase PostgreSQL, and configure automated build notification webhooks.',
      icon: <Layers className="w-6 h-6 text-indigo-600" />,
      badge: 'Zero Vendor Lock-in',
    },
    {
      tab: 'github' as WorkspaceTab,
      title: 'GitHub CI/CD Sync',
      desc: 'Connect your personal or organization GitHub repositories. Auto-push verified code, generate branch previews, and trigger builds.',
      icon: <Github className="w-6 h-6 text-indigo-600" />,
      badge: 'Git Integrated',
    },
  ];

  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12 antialiased">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <Sliders size={13} />
          <span>WORKSPACE & DEVELOPER TOOLS</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight leading-tight">
          Platform Controls & Ecosystem Settings
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          Access everything that powers your universal software factory. Manage memberships, payments, AI tokens, developer profiles, cloud integrations, and GitHub synchronization.
        </p>
      </div>

      {/* Grid of workspace areas */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {sections.map((sec) => (
          <div
            key={sec.tab}
            onClick={() => onOpenWorkspaceTab(sec.tab)}
            className="bg-white border border-slate-200 hover:border-indigo-400 rounded-2xl p-6 shadow-xs hover:shadow-lg transition-all duration-200 cursor-pointer flex flex-col justify-between group"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="p-2.5 rounded-xl bg-indigo-50 group-hover:bg-indigo-600 group-hover:text-white text-indigo-600 transition-colors">
                  {sec.icon}
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                  {sec.badge}
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-950 group-hover:text-indigo-600 transition-colors">
                  {sec.title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed mt-1.5">
                  {sec.desc}
                </p>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-indigo-600">
              <span>Manage settings</span>
              <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>

      {/* Cross-Platform Architecture Callout */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles size={14} />
            <span>Universal Native Exporter</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            Single Prompt. Web, Android APK, and Desktop Binary.
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
            Every application compiled by Appmazon is 100% owned by you. Export standard React / Vite code, build APKs with the Android Manifest generator, or bundle standalone Tauri desktop applications without platform lock-in.
          </p>
        </div>

        <button
          onClick={() => onOpenWorkspaceTab('pricing')}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm rounded-xl transition shadow-lg shrink-0 flex items-center gap-2"
        >
          <span>View Pricing & Credits</span>
          <ArrowRight size={15} />
        </button>
      </div>
    </div>
  );
}
