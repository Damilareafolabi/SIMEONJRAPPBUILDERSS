import React, { useState } from 'react';
import { 
  Sparkles, Play, Code2, Globe, Smartphone, Monitor, 
  Layers, ArrowRight, ExternalLink, Activity, Database, Check
} from 'lucide-react';
import { GeneratedApp, AppCategory, AppFile } from '../../types/promptBuilder';
import { APP_PRESETS } from '../../data/appPresets';

interface PortfolioViewProps {
  onLaunchInSandbox: (app: GeneratedApp) => void;
  onInspectCode: (file: AppFile) => void;
}

export function PortfolioView({ onLaunchInSandbox, onInspectCode }: PortfolioViewProps) {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');

  const portfolioItems = [
    {
      app: APP_PRESETS.trading,
      category: 'fintech',
      metrics: '48ms trade latency • Sub-second WebSocket order updates',
      platforms: ['Web', 'Desktop', 'APK'],
      tag: 'Fintech & Algo-Trading',
      color: 'indigo',
    },
    {
      app: APP_PRESETS.ai,
      category: 'ai',
      metrics: 'Multi-LLM token streaming • 12+ prompt templates',
      platforms: ['Web', 'Mobile APK', 'Desktop'],
      tag: 'AI Intelligence',
      color: 'violet',
    },
    {
      app: APP_PRESETS.saas,
      category: 'saas',
      metrics: '$84.5k MRR tracked • Multi-tenant role access',
      platforms: ['Web', 'Desktop'],
      tag: 'B2B Enterprise SaaS',
      color: 'emerald',
    },
    {
      app: APP_PRESETS.social,
      category: 'social',
      metrics: 'Instant WebSocket chat • Threaded communities',
      platforms: ['Web', 'Mobile APK', 'iOS'],
      tag: 'Social Platform',
      color: 'sky',
    },
    {
      app: APP_PRESETS.delivery,
      category: 'logistics',
      metrics: 'Real-time driver dispatch • GPS route recalculation',
      platforms: ['Mobile APK', 'iOS', 'Web'],
      tag: 'On-Demand Logistics',
      color: 'amber',
    },
  ];

  const filteredItems = selectedFilter === 'all' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === selectedFilter);

  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12 antialiased">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <Sparkles size={13} />
          <span>PRODUCTION APP PORTFOLIO</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          Universal Applications Built on APPMORA
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          Every application below was synthesized directly from natural language prompts by the Simeon Intelligence engine and runs live in the interactive sandbox.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {[
          { id: 'all', label: 'All Applications' },
          { id: 'fintech', label: 'Fintech & Trading' },
          { id: 'ai', label: 'AI Assistants & LLMs' },
          { id: 'saas', label: 'Enterprise SaaS' },
          { id: 'social', label: 'Social & Chat' },
          { id: 'logistics', label: 'Mobile Logistics' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedFilter(tab.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              selectedFilter === tab.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item, idx) => (
          <div
            key={idx}
            className="bg-white border border-slate-200 hover:border-indigo-400 rounded-3xl p-6 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
          >
            <div className="space-y-4">
              {/* Card top */}
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                  {item.tag}
                </span>
                <div className="flex items-center gap-1.5 text-slate-400 text-xs font-semibold">
                  {item.platforms.map((p, pIdx) => (
                    <span key={pIdx} className="px-1.5 py-0.5 rounded bg-slate-50 border border-slate-200 text-[10px] text-slate-600">
                      {p}
                    </span>
                  ))}
                </div>
              </div>

              {/* Title & Description */}
              <div>
                <h3 className="text-xl font-extrabold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {item.app.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  {item.app.description}
                </p>
              </div>

              {/* Live Metric */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 text-[11px] text-slate-700 font-medium flex items-center gap-2">
                <Activity size={14} className="text-indigo-600 shrink-0" />
                <span>{item.metrics}</span>
              </div>

              {/* Prompt snippet preview */}
              <div className="bg-slate-900 text-slate-300 p-2.5 rounded-xl font-mono text-[10px] border border-slate-800 line-clamp-2">
                <span className="text-indigo-400 font-bold mr-1.5">PROMPT:</span>
                "{item.app.prompt}"
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-6 border-t border-slate-100 mt-6 flex items-center gap-2">
              <button
                onClick={() => onLaunchInSandbox(item.app)}
                className="flex-1 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2"
              >
                <Play size={13} className="fill-white" />
                <span>Launch Live in Sandbox</span>
              </button>

              {item.app.files && item.app.files.length > 0 && (
                <button
                  onClick={() => onInspectCode(item.app.files[0])}
                  className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                  title="Inspect Source Code"
                >
                  <Code2 size={16} />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
