import React, { useState } from 'react';
import { 
  Sparkles, Globe, Smartphone, Monitor, Database, Cpu, 
  ShieldCheck, ArrowRight, Check, Zap, Sliders, Calculator
} from 'lucide-react';

interface ServicesViewProps {
  onStartBuilding: () => void;
  onOpenChatbot: () => void;
}

export function ServicesView({ onStartBuilding, onOpenChatbot }: ServicesViewProps) {
  // Interactive Solution Estimator
  const [platformTargets, setPlatformTargets] = useState<{ [key: string]: boolean }>({
    web: true,
    android: true,
    ios: false,
    desktop: false,
    multiApp: true,
  });
  const [agentTier, setAgentTier] = useState<'standard' | 'turbo' | 'enterprise'>('turbo');
  const [databaseRequirement, setDatabaseRequirement] = useState<'local' | 'cloud' | 'enterprise'>('cloud');

  const togglePlatform = (key: string) => {
    setPlatformTargets((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const calculateScore = () => {
    let baseTimeSec = 2.4;
    let targetCount = Object.values(platformTargets).filter(Boolean).length;
    let time = (baseTimeSec + targetCount * 0.8).toFixed(1);
    return {
      targetCount,
      estimatedCompileTime: `${time}s`,
      readiness: targetCount > 3 ? 'Universal Production Suite' : 'Standard Bundle',
    };
  };

  const score = calculateScore();

  const servicesList = [
    {
      icon: <Globe className="w-6 h-6 text-indigo-600" />,
      title: 'Universal Web Applications',
      desc: 'High-performance React 18, Vite, and Tailwind CSS single-page apps and serverless micro-frontends with sub-second reload times.',
      features: ['TypeScript strict typing', 'Full responsive layout engine', 'Instant SPA router & state', 'Zero-config edge CDN deployment'],
    },
    {
      icon: <Smartphone className="w-6 h-6 text-emerald-600" />,
      title: 'Mobile APK & iOS Frameworks',
      desc: 'Native bridge generation that wraps prompt-synthesized logic into installable Android APKs and iOS Xcode packages ready for app stores.',
      features: ['One-click APK compile', 'Native device API bridges', 'Offline local storage & cache', 'Push notification pipelines'],
    },
    {
      icon: <Monitor className="w-6 h-6 text-violet-600" />,
      title: 'Cross-Platform Desktop Executables',
      desc: 'Lightweight, secure native binaries for macOS, Windows, and Linux powered by high-speed Tauri/Rust native runtimes.',
      features: ['Ultra-low memory footprint', 'Native file system access', 'Custom window frames & menus', 'Auto-update distribution'],
    },
    {
      icon: <Database className="w-6 h-6 text-amber-600" />,
      title: 'Multi-App Enterprise Suites',
      desc: 'Interconnected software platforms with synchronized data schemas, central auth, analytics dashboards, and CRM integrations.',
      features: ['Shared data bus & RPC', 'Multi-tenant database schema', 'Granular RBAC permissions', 'Audit log telemetry'],
    },
    {
      icon: <Cpu className="w-6 h-6 text-sky-600" />,
      title: 'Autonomous AI Dev Agents',
      desc: 'Simeon Jr Studios autonomous agent fleet that handles continuous requirements analysis, code synthesis, automatic lint healing, and security auditing.',
      features: ['Self-healing build pipeline', 'Automated unit test generation', 'Real-time agent activity logs', 'Interactive visual canvas'],
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-rose-600" />,
      title: 'Enterprise Air-Gapped & Cloud',
      desc: 'Deploy APPMORA instances inside your private AWS, Google Cloud, Azure, or air-gapped on-premises data centers with complete sovereignty.',
      features: ['Zero external egress', 'SSO / SAML / Okta compliance', 'Custom internal LLM adapters', '24/7 dedicated engineering SLA'],
    },
  ];

  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16 antialiased">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <Sparkles size={13} />
          <span>CAPABILITIES & ARCHITECTURE</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          Comprehensive Universal Software Services
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          From rapid prototypes to enterprise-grade multi-platform applications, Simeon Jr Studios & Technologies delivers complete end-to-end universal development.
        </p>
      </div>

      {/* Services Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {servicesList.map((srv, idx) => (
          <div
            key={idx}
            className="bg-white border border-slate-200 hover:border-indigo-300 rounded-3xl p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center">
                {srv.icon}
              </div>
              <h3 className="font-bold text-slate-900 text-lg">{srv.title}</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{srv.desc}</p>
            </div>

            <div className="pt-2 border-t border-slate-100 space-y-2">
              {srv.features.map((feat, fIdx) => (
                <div key={fIdx} className="flex items-center gap-2 text-xs text-slate-700">
                  <Check size={14} className="text-emerald-500 shrink-0" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Solution Estimator */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-10 border border-slate-800 shadow-2xl space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-400 uppercase tracking-wider">
              <Calculator size={14} />
              <span>Interactive Architecture Calculator</span>
            </div>
            <h2 className="text-2xl font-black text-white mt-1">Configure Your Universal Deployment</h2>
          </div>
          <button
            onClick={onStartBuilding}
            className="self-start sm:self-auto px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-2"
          >
            <span>Launch in App Factory</span>
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Target Platforms */}
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
              1. Platform Targets
            </label>
            <div className="space-y-2">
              {[
                { id: 'web', label: 'Web Application (React / Vite)' },
                { id: 'android', label: 'Android Native APK (Capacitor)' },
                { id: 'ios', label: 'iOS Native Bundle (Swift bridge)' },
                { id: 'desktop', label: 'Desktop Executable (Tauri / Rust)' },
                { id: 'multiApp', label: 'Multi-App Interlinked Ecosystem' },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => togglePlatform(p.id)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-medium border transition flex items-center justify-between ${
                    platformTargets[p.id]
                      ? 'bg-indigo-950/60 border-indigo-500 text-white'
                      : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span>{p.label}</span>
                  {platformTargets[p.id] && <Check size={14} className="text-indigo-400" />}
                </button>
              ))}
            </div>
          </div>

          {/* Agent Engine Tier */}
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
              2. Agent Intelligence Tier
            </label>
            <div className="space-y-2">
              {[
                { id: 'standard', name: 'Standard Autonomous', desc: 'Single-pass code synthesis' },
                { id: 'turbo', name: 'Turbo Multi-Agent Consensus', desc: '5 coordinated agents with self-healing' },
                { id: 'enterprise', name: 'Dedicated Simeon Jr Engine', desc: 'Deep AST compilation & edge packaging' },
              ].map((tier) => (
                <button
                  key={tier.id}
                  onClick={() => setAgentTier(tier.id as any)}
                  className={`w-full text-left p-3 rounded-xl border transition ${
                    agentTier === tier.id
                      ? 'bg-indigo-950/60 border-indigo-500 text-white'
                      : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-xs font-bold">{tier.name}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{tier.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Results Summary Box */}
          <div className="bg-slate-950 rounded-2xl p-5 border border-slate-800/90 flex flex-col justify-between space-y-4">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Configuration Summary
              </div>
              <div className="mt-4 space-y-3">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Active Targets:</span>
                  <span className="font-bold text-white">{score.targetCount} Platforms</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Estimated Compile:</span>
                  <span className="font-bold text-emerald-400">{score.estimatedCompileTime}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Deployment Tier:</span>
                  <span className="font-bold text-indigo-400">{score.readiness}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Source Ownership:</span>
                  <span className="font-bold text-white">100% Unrestricted</span>
                </div>
              </div>
            </div>

            <button
              onClick={onOpenChatbot}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-indigo-600/90 hover:bg-indigo-600 text-white transition flex items-center justify-center gap-2"
            >
              <span>Consult with Simeon Jr AI</span>
              <ArrowRight size={13} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
