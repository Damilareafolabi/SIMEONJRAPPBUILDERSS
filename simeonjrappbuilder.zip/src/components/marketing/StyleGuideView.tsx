import React from 'react';
import { 
  Sparkles, Palette, Type, Layout, Sliders, Layers, 
  ArrowRight, Check, Eye, Code2
} from 'lucide-react';

interface StyleGuideViewProps {
  onOpenCanvas: () => void;
}

export function StyleGuideView({ onOpenCanvas }: StyleGuideViewProps) {
  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16 antialiased">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <Palette size={13} />
          <span>DESIGN SYSTEM & STYLE ARCHITECTURE</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          The APPMORA Design Language
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          Crafted by Simeon Intelligence / Simeon Jr Studios & Technologies. A rigorous, mathematical design system prioritizing high-contrast typography, harmonious optical radii, and purposeful motion.
        </p>

        <div className="pt-2">
          <button
            onClick={onOpenCanvas}
            className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition"
          >
            <Sliders size={15} />
            <span>Open Visual Canvas & Drag-and-Drop Studio</span>
            <ArrowRight size={15} />
          </button>
        </div>
      </div>

      {/* Color Palette Tokens */}
      <div className="space-y-6">
        <div className="border-b border-slate-200 pb-3">
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-indigo-600" />
            <span>Color Palette & Tonal Range</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Sophisticated neutrals with purposeful chromatic accents. No generic cyan-on-black or oversaturated neon clichés.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4">
          <div className="space-y-2">
            <div className="h-20 rounded-2xl bg-slate-950 border border-slate-800 shadow-xs flex items-end p-2.5">
              <span className="text-[10px] font-mono font-bold text-white">#020617</span>
            </div>
            <div className="text-xs font-bold text-slate-900">Slate 950</div>
            <div className="text-[10px] text-slate-500">Surface Dark</div>
          </div>

          <div className="space-y-2">
            <div className="h-20 rounded-2xl bg-slate-900 border border-slate-700 shadow-xs flex items-end p-2.5">
              <span className="text-[10px] font-mono font-bold text-white">#0f172a</span>
            </div>
            <div className="text-xs font-bold text-slate-900">Slate 900</div>
            <div className="text-[10px] text-slate-500">Card & Terminal</div>
          </div>

          <div className="space-y-2">
            <div className="h-20 rounded-2xl bg-indigo-600 shadow-xs flex items-end p-2.5">
              <span className="text-[10px] font-mono font-bold text-white">#4f46e5</span>
            </div>
            <div className="text-xs font-bold text-slate-900">Indigo 600</div>
            <div className="text-[10px] text-slate-500">Primary Brand Accent</div>
          </div>

          <div className="space-y-2">
            <div className="h-20 rounded-2xl bg-violet-600 shadow-xs flex items-end p-2.5">
              <span className="text-[10px] font-mono font-bold text-white">#7c3aed</span>
            </div>
            <div className="text-xs font-bold text-slate-900">Violet 600</div>
            <div className="text-[10px] text-slate-500">Intelligence / AI Gradient</div>
          </div>

          <div className="space-y-2">
            <div className="h-20 rounded-2xl bg-emerald-500 shadow-xs flex items-end p-2.5">
              <span className="text-[10px] font-mono font-bold text-white">#10b981</span>
            </div>
            <div className="text-xs font-bold text-slate-900">Emerald 500</div>
            <div className="text-[10px] text-slate-500">Success & Online Status</div>
          </div>

          <div className="space-y-2">
            <div className="h-20 rounded-2xl bg-amber-500 shadow-xs flex items-end p-2.5">
              <span className="text-[10px] font-mono font-bold text-white">#f59e0b</span>
            </div>
            <div className="text-xs font-bold text-slate-900">Amber 500</div>
            <div className="text-[10px] text-slate-500">Warning & Highlights</div>
          </div>
        </div>
      </div>

      {/* Typography Scale */}
      <div className="space-y-6">
        <div className="border-b border-slate-200 pb-3">
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <Type size={18} className="text-indigo-600" />
            <span>Typographic Scale & Hierarchy</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Built with strict step ratios (&gt;1.25) to enforce optical balance across screen densities.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xs">
          <div className="border-b border-slate-100 pb-4">
            <div className="text-[10px] font-mono text-slate-400 uppercase">H1 Display / 48px Bold</div>
            <div className="text-3xl sm:text-4xl font-black text-slate-950 tracking-tight mt-1">
              Universal Software Synthesis
            </div>
          </div>

          <div className="border-b border-slate-100 pb-4">
            <div className="text-[10px] font-mono text-slate-400 uppercase">H2 Section Heading / 28px Bold</div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
              Autonomous Multi-Agent Consensus
            </div>
          </div>

          <div className="border-b border-slate-100 pb-4">
            <div className="text-[10px] font-mono text-slate-400 uppercase">H3 Component Header / 20px SemiBold</div>
            <div className="text-lg font-bold text-slate-800 mt-1">
              High-Frequency Algorithmic Order Book
            </div>
          </div>

          <div>
            <div className="text-[10px] font-mono text-slate-400 uppercase">Body Regular / 15px (Line-height 1.6)</div>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-3xl mt-1">
              Engineered with clean typography pairing, optimal line widths (65–75 characters), and ample vertical rhythm. Designed to eliminate cognitive fatigue when reading complex code and architecture logs.
            </p>
          </div>
        </div>
      </div>

      {/* UI Component Tokens */}
      <div className="space-y-6">
        <div className="border-b border-slate-200 pb-3">
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <Layout size={18} className="text-indigo-600" />
            <span>Component Primitives & Tokens</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Buttons, badges, inputs, and containment cards formatted with strict nested corner math.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Buttons */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3 shadow-xs">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Button Styles</div>
            <div className="space-y-2">
              <button className="w-full py-2 px-3 bg-indigo-600 text-white font-bold text-xs rounded-xl shadow-xs">
                Solid Primary
              </button>
              <button className="w-full py-2 px-3 bg-slate-900 text-white font-bold text-xs rounded-xl shadow-xs">
                Dark Surface
              </button>
              <button className="w-full py-2 px-3 bg-white border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50">
                Outline Light
              </button>
            </div>
          </div>

          {/* Badges */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3 shadow-xs">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Status Badges</div>
            <div className="flex flex-wrap gap-2">
              <span className="px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold border border-indigo-200">
                Universal
              </span>
              <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200">
                Live Active
              </span>
              <span className="px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 text-xs font-bold border border-amber-200">
                Warning
              </span>
              <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200">
                v1.0.4
              </span>
            </div>
          </div>

          {/* Form Fields */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3 shadow-xs">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Input Fields</div>
            <input
              type="text"
              readOnly
              value="Prompt: Build a trading dashboard"
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
            />
            <div className="text-[10px] text-slate-400">Border radius: 12px • Internal padding: 8px 12px</div>
          </div>

          {/* Mathematical Radius */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3 shadow-xs">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Nested Radius Math</div>
            <div className="p-3 bg-slate-100 rounded-2xl border border-slate-200">
              <div className="p-2 bg-white rounded-lg border border-slate-200 text-[11px] font-mono text-center font-bold text-indigo-600">
                Inner = Outer - Padding
              </div>
            </div>
            <div className="text-[10px] text-slate-500 leading-tight">
              Calculates optical corner harmony between outer and inner containers automatically.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
