import React from 'react';
import { 
  Sparkles, Users, Award, ShieldCheck, Github, 
  Linkedin, Twitter, Globe, ArrowRight, Heart, Code2
} from 'lucide-react';

interface TeamMember {
  name: string;
  role: string;
  bio: string;
  initials: string;
  color: string;
  focus: string;
}

const TEAM_MEMBERS: TeamMember[] = [
  {
    name: 'Simeon Jr',
    role: 'Founder & Chief Executive Officer',
    bio: 'Pioneered the Universal Compute Mandate at Simeon Jr Studios. Dedicated to dismantling the boundaries between human intent and cross-platform native software.',
    initials: 'SJ',
    color: 'from-indigo-600 to-violet-600',
    focus: 'Executive Vision & Universal Strategy',
  },
  {
    name: 'Elena Vance',
    role: 'Chief Technology Officer',
    bio: 'Former compiler research lead. Architects the AST synthesis pipeline that transforms prompt intents into verified TypeScript and native bridges.',
    initials: 'EV',
    color: 'from-violet-600 to-purple-600',
    focus: 'Compiler Engine & Zero-Error AST',
  },
  {
    name: 'Dr. Tariq Al-Mansoor',
    role: 'Head of Autonomous AI Research',
    bio: 'PhD in Distributed Multi-Agent Systems. Designed the 5-agent consensus model that prevents code hallucinations and performs self-healing linting.',
    initials: 'TA',
    color: 'from-emerald-600 to-teal-600',
    focus: 'Multi-Agent Consensus & Self-Healing',
  },
  {
    name: 'Chloe Zhang',
    role: 'VP of Product Design & HCI',
    bio: 'Leads visual engineering and the Appmazon Design System. Passionate about mathematical radii, accessible contrast, and fluid motion design.',
    initials: 'CZ',
    color: 'from-pink-600 to-rose-600',
    focus: 'Design Systems & Visual Canvas',
  },
  {
    name: 'Marcus Aurel',
    role: 'Lead Mobile & Native APK Systems',
    bio: 'Mobile runtime specialist. Oversees automated Capacitor Gradle packaging, Android APK signing, and low-latency native hardware bridges.',
    initials: 'MA',
    color: 'from-amber-600 to-orange-600',
    focus: 'Android APK & Native Device Bridges',
  },
  {
    name: 'Samantha Reyes',
    role: 'Head of Cloud & Enterprise Security',
    bio: 'Secures the multi-tenant sandbox container infrastructure. Ensures complete code sandboxing, air-gapped deployment, and zero token leakage.',
    initials: 'SR',
    color: 'from-sky-600 to-blue-600',
    focus: 'Container Isolation & Air-Gapped Security',
  },
];

export function TeamView() {
  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16 antialiased">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <Users size={13} />
          <span>MEET THE BUILDERS</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          The Minds Behind Simeon Jr Studios
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          A world-class collective of compiler engineers, distributed AI researchers, and systems designers united by a single goal: making universal software creation instantaneous.
        </p>
      </div>

      {/* Team Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {TEAM_MEMBERS.map((member, idx) => (
          <div
            key={idx}
            className="bg-white border border-slate-200 hover:border-indigo-400 rounded-3xl p-6 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
          >
            <div className="space-y-4">
              {/* Avatar */}
              <div className="flex items-center gap-3">
                <div className={`w-14 h-14 rounded-2xl bg-linear-to-tr ${member.color} flex items-center justify-center text-white font-extrabold text-lg shadow-sm`}>
                  {member.initials}
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-950 text-base group-hover:text-indigo-600 transition-colors">
                    {member.name}
                  </h3>
                  <div className="text-xs font-semibold text-indigo-600">
                    {member.role}
                  </div>
                </div>
              </div>

              {/* Focus Badge */}
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 text-slate-700 text-[10px] font-bold uppercase tracking-wider">
                <Sparkles size={11} className="text-indigo-500" />
                <span>{member.focus}</span>
              </div>

              {/* Bio */}
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {member.bio}
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 mt-4 text-[11px] text-slate-400 font-medium">
              Simeon Jr Studios & Technologies
            </div>
          </div>
        ))}
      </div>

      {/* Company Culture & Values */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 shadow-2xl space-y-6">
        <div className="max-w-3xl mx-auto text-center space-y-3">
          <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider">Our Culture</div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Engineering Principles That Guide Every Commit
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            At Simeon Jr Studios & Technologies, we reject unnecessary complexity and artificial walled gardens. We build tools that grant developers total ownership and genuine agency.
          </p>
        </div>

        <div className="grid sm:grid-cols-3 gap-6 pt-4">
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-2">
            <h4 className="font-bold text-white text-sm">Extreme Craftsmanship</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every pixel, line of code, and API contract is measured with deliberate care. We build for endurance, not shortcuts.
            </p>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-2">
            <h4 className="font-bold text-white text-sm">Universal Access</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Software generation should never be restricted to elite specialized silos. Natural language democratizes creation for everyone.
            </p>
          </div>

          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-2">
            <h4 className="font-bold text-white text-sm">Radical Sovereignty</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              You own your software. No platform lock-in, no hostage code, and no opaque proprietary runtime constraints.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
