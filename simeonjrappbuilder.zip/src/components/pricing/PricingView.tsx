import React, { useState } from 'react';
import { 
  Check, Info, ChevronDown, Sparkles, ShieldCheck, 
  Cpu, ArrowRight, Zap, RefreshCw, CreditCard, Building2, HelpCircle 
} from 'lucide-react';

interface PricingViewProps {
  onOpenWorkspaceModal: (tab?: string) => void;
  onSelectPlan?: (planName: string, credits: number) => void;
}

export function PricingView({ onOpenWorkspaceModal, onSelectPlan }: PricingViewProps) {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [maxCreditsTier, setMaxCreditsTier] = useState<number>(24000);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleChoosePlan = (plan: string, credits: number) => {
    showToast(`Selected ${plan} (${credits.toLocaleString()} credits)`);
    if (onSelectPlan) {
      onSelectPlan(plan, credits);
    }
    onOpenWorkspaceModal('pricing');
  };

  return (
    <div className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16 antialiased">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-950 text-white text-xs font-semibold px-4 py-2 rounded-full shadow-2xl flex items-center gap-2 border border-indigo-500/40 animate-in fade-in">
          <Sparkles size={14} className="text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
          <CreditCard size={13} />
          <span>TRANSPARENT USAGE-BASED TIERS</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-950 tracking-tight leading-tight">
          Scale Universal Software Generation
        </h1>

        <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
          From solo hackers to enterprise engineering fleets. Predictable pricing with monthly credit rollovers, zero locked code, and instant native APK downloads.
        </p>

        {/* Monthly / Annual switch */}
        <div className="pt-2 flex justify-center">
          <div className="bg-slate-100 p-1.5 rounded-full border border-slate-200/90 inline-flex items-center text-xs font-semibold shadow-2xs">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-6 py-2 rounded-full transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-white text-slate-950 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`px-6 py-2 rounded-full transition-all flex items-center gap-1.5 ${
                billingCycle === 'annual'
                  ? 'bg-white text-slate-950 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Annual Billing</span>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                Save 20%
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Pricing Cards Grid matching image */}
      <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto items-stretch">
        {/* CARD 1: Lite 6k */}
        <div className="bg-white border border-slate-200 hover:border-indigo-300 rounded-3xl p-8 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group relative">
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-black text-slate-950 group-hover:text-indigo-600 transition-colors">
                Lite 6k
              </h3>
              <p className="text-xs text-slate-500 mt-1">For more projects and usage</p>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-black text-slate-950">
                {billingCycle === 'annual' ? '$14' : '$17'}
              </span>
              <div className="flex flex-col">
                <span className="inline-block bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-bold px-2 py-0.5 rounded-md self-start">
                  Save $36
                </span>
                <span className="text-xs text-slate-500 mt-0.5">/ month</span>
              </div>
            </div>

            <button
              onClick={() => handleChoosePlan('Lite 6k', 6000)}
              className="w-full py-3 bg-[#5e55e3] hover:bg-[#4d44cf] text-white font-bold text-sm rounded-xl shadow-xs transition transform active:scale-95"
            >
              Upgrade to Lite 6k
            </button>

            <div className="pt-2 space-y-3">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Everything in Free, plus:
              </div>
              <ul className="space-y-2.5 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Up to 6,000 credits / month</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Advanced AI coding models</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Private projects</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Remove platform badge</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Custom domains</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>APK download</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Fast track generation</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span className="flex items-center gap-1">
                    Credit rollovers <Info size={12} className="text-slate-400" />
                  </span>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 text-[11px] text-slate-400">
            Rollover up to 12,000 unused credits
          </div>
        </div>

        {/* CARD 2: Plus 12k (POPULAR) */}
        <div className="bg-white border-2 border-indigo-500/80 rounded-3xl p-8 shadow-xl transition-all duration-300 flex flex-col justify-between relative group">
          {/* Popular Badge */}
          <span className="absolute -top-3.5 right-6 bg-[#ff3b69] text-white text-[11px] font-extrabold px-3 py-1 rounded-full shadow-md uppercase tracking-wider">
            Popular
          </span>

          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-black text-slate-950 group-hover:text-indigo-600 transition-colors">
                Plus 12k
              </h3>
              <p className="text-xs text-slate-500 mt-1">For more projects and usage</p>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-black text-slate-950">
                {billingCycle === 'annual' ? '$26' : '$31'}
              </span>
              <div className="flex flex-col">
                <span className="inline-block bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-bold px-2 py-0.5 rounded-md self-start">
                  Save $60
                </span>
                <span className="text-xs text-slate-500 mt-0.5">/ month</span>
              </div>
            </div>

            <button
              onClick={() => handleChoosePlan('Plus 12k', 12000)}
              className="w-full py-3 bg-[#5e55e3] hover:bg-[#4d44cf] text-white font-bold text-sm rounded-xl shadow-md transition transform active:scale-95"
            >
              Upgrade to Plus 12k
            </button>

            <div className="pt-2 space-y-3">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Everything in Free, plus:
              </div>
              <ul className="space-y-2.5 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Up to 12,000 credits / month</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Advanced AI coding models</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Private projects</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Remove platform badge</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Custom domains</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>APK download</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Fast track generation</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span className="flex items-center gap-1">
                    Credit rollovers <Info size={12} className="text-slate-400" />
                  </span>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 text-[11px] text-indigo-600 font-semibold">
            Most selected by growth teams & creators
          </div>
        </div>

        {/* CARD 3: Max 24k (DROPDOWN TIER) */}
        <div className="bg-white border border-slate-200 hover:border-indigo-300 rounded-3xl p-8 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group relative">
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-black text-slate-950 group-hover:text-indigo-600 transition-colors">
                Max 24k
              </h3>
              <p className="text-xs text-slate-500 mt-1">For more projects and usage</p>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-black text-slate-950">
                {maxCreditsTier === 24000
                  ? billingCycle === 'annual' ? '$50' : '$61'
                  : maxCreditsTier === 48000
                  ? billingCycle === 'annual' ? '$98' : '$119'
                  : billingCycle === 'annual' ? '$189' : '$229'}
              </span>
              <div className="flex flex-col">
                <span className="inline-block bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-bold px-2 py-0.5 rounded-md self-start">
                  {maxCreditsTier === 24000 ? 'Save $132' : 'Save $240'}
                </span>
                <span className="text-xs text-slate-500 mt-0.5">/ month</span>
              </div>
            </div>

            <button
              onClick={() => handleChoosePlan(`Max ${maxCreditsTier / 1000}k`, maxCreditsTier)}
              className="w-full py-3 bg-[#5e55e3] hover:bg-[#4d44cf] text-white font-bold text-sm rounded-xl shadow-xs transition transform active:scale-95"
            >
              Upgrade to Max {maxCreditsTier / 1000}k
            </button>

            {/* Dropdown selector matching screenshot */}
            <div className="relative">
              <select
                value={maxCreditsTier}
                onChange={(e) => setMaxCreditsTier(Number(e.target.value))}
                className="w-full appearance-none bg-white border border-slate-300 rounded-xl px-4 py-2.5 text-xs font-semibold text-slate-800 pr-8 outline-hidden focus:border-indigo-500 cursor-pointer shadow-2xs"
              >
                <option value={24000}>24000 credits/month</option>
                <option value={48000}>48000 credits/month ($119)</option>
                <option value={96000}>96000 credits/month ($229)</option>
              </select>
              <ChevronDown size={14} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
            </div>

            <div className="pt-2 space-y-3">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Everything in Free, plus:
              </div>
              <ul className="space-y-2.5 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Up to {maxCreditsTier.toLocaleString()} credits / month</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Advanced AI coding models</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Private projects</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Remove platform badge</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Custom domains</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>APK download</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span>Fast track generation</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check size={14} className="text-slate-500 shrink-0" />
                  <span className="flex items-center gap-1">
                    Credit rollovers <Info size={12} className="text-slate-400" />
                  </span>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 text-[11px] text-slate-400">
            Dedicated multi-agent queue & SLA
          </div>
        </div>
      </div>

      {/* Quick Launch Workspace & Account Settings Banner */}
      <div className="bg-linear-to-r from-slate-900 to-indigo-950 text-white rounded-3xl p-8 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-indigo-400 uppercase tracking-wider">
            <Sparkles size={14} />
            <span>Workspace & Developer Settings</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-extrabold text-white">
            Need to manage Membership, Payments, AI Tokens, or GitHub Sync?
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Open your dedicated Workspace Settings drawer to inspect invoices, top-up tokens, configure API keys, and link your repositories.
          </p>
        </div>

        <button
          onClick={() => onOpenWorkspaceModal('membership')}
          className="px-6 py-3 bg-white hover:bg-slate-100 text-slate-950 font-bold text-xs sm:text-sm rounded-xl shadow-lg transition flex items-center gap-2 shrink-0"
        >
          <span>Open Workspace Settings</span>
          <ArrowRight size={15} />
        </button>
      </div>
    </div>
  );
}
