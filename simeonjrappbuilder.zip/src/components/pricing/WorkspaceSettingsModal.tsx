import React, { useState } from 'react';
import { 
  X, Check, Info, ChevronDown, CreditCard, ShieldCheck, 
  Cpu, User, Layers, Github, Sparkles, Download, Plus, 
  ExternalLink, ArrowRight, Zap, RefreshCw, Key, CheckCircle2,
  Trash2, Sliders, AlertCircle
} from 'lucide-react';

export type WorkspaceTab = 
  | 'pricing' 
  | 'membership' 
  | 'payments' 
  | 'token' 
  | 'profile' 
  | 'integrations' 
  | 'github';

interface WorkspaceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: WorkspaceTab;
  onUpgradePlan?: (planName: string, credits: number) => void;
}

export function WorkspaceSettingsModal({
  isOpen,
  onClose,
  initialTab = 'pricing',
  onUpgradePlan,
}: WorkspaceSettingsModalProps) {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>(initialTab);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [maxCreditsTier, setMaxCreditsTier] = useState<number>(24000);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Profile state
  const [displayName, setDisplayName] = useState('Simeon Jr');
  const [companyName, setCompanyName] = useState('Simeon Jr Studios & Technologies');
  const [userEmail] = useState('simeonjrpictures123@gmail.com');
  const [apiKeys, setApiKeys] = useState([
    { id: 'key_live_1', name: 'Production App Factory Key', prefix: 'sk_appmazon_live_9f82••••••••', created: 'Aug 2026' },
  ]);

  // AI Token top-up state
  const [autoReload, setAutoReload] = useState(true);

  if (!isOpen) return null;

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleUpgrade = (planName: string, credits: number) => {
    triggerToast(`Upgraded to ${planName} (${credits.toLocaleString()} credits/mo)!`);
    if (onUpgradePlan) {
      onUpgradePlan(planName, credits);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto animate-in fade-in duration-200">
      {/* Toast Notification inside modal */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-60 bg-slate-900 text-white text-xs font-semibold px-4 py-2 rounded-full shadow-2xl flex items-center gap-2 border border-indigo-500/40 animate-in slide-in-from-top-2">
          <CheckCircle2 size={14} className="text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xl w-full max-w-6xl max-h-[94vh] flex flex-col md:flex-row overflow-hidden relative antialiased">
        {/* Close Button matching screenshot */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition"
          aria-label="Close modal"
        >
          <X size={20} />
        </button>

        {/* LEFT SIDEBAR navigation matching screenshot */}
        <div className="w-full md:w-60 bg-white border-r border-slate-200/80 p-5 flex flex-col justify-between shrink-0">
          <div className="space-y-6">
            {/* Group: Workspace */}
            <div className="space-y-1">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3 pb-1">
                Workspace
              </div>
              <button
                onClick={() => setActiveTab('pricing')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-2.5 ${
                  activeTab === 'pricing'
                    ? 'bg-neutral-950 text-white shadow-xs'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>Pricing</span>
              </button>

              <button
                onClick={() => setActiveTab('membership')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-2.5 ${
                  activeTab === 'membership'
                    ? 'bg-neutral-950 text-white shadow-xs'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>Membership</span>
              </button>

              <button
                onClick={() => setActiveTab('payments')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-2.5 ${
                  activeTab === 'payments'
                    ? 'bg-neutral-950 text-white shadow-xs'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>Payments</span>
              </button>

              <button
                onClick={() => setActiveTab('token')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-2.5 ${
                  activeTab === 'token'
                    ? 'bg-neutral-950 text-white shadow-xs'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>AI Token</span>
              </button>
            </div>

            {/* Group: Account */}
            <div className="space-y-1">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3 pb-1">
                Account
              </div>
              <button
                onClick={() => setActiveTab('profile')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-2.5 ${
                  activeTab === 'profile'
                    ? 'bg-neutral-950 text-white shadow-xs'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>Profile</span>
              </button>
            </div>

            {/* Group: Integrations */}
            <div className="space-y-1">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3 pb-1">
                Integrations
              </div>
              <button
                onClick={() => setActiveTab('integrations')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-2.5 ${
                  activeTab === 'integrations'
                    ? 'bg-neutral-950 text-white shadow-xs'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>Integrations</span>
              </button>

              <button
                onClick={() => setActiveTab('github')}
                className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-2.5 ${
                  activeTab === 'github'
                    ? 'bg-neutral-950 text-white shadow-xs'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span>GitHub</span>
              </button>
            </div>
          </div>

          {/* Bottom user card */}
          <div className="pt-4 border-t border-slate-100 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-linear-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
              SJ
            </div>
            <div className="truncate">
              <div className="text-xs font-bold text-slate-900 truncate">Simeon Jr</div>
              <div className="text-[10px] text-slate-400 truncate">simeonjrpictures123@gmail.com</div>
            </div>
          </div>
        </div>

        {/* RIGHT MAIN VIEW */}
        <div className="flex-1 p-6 sm:p-8 md:p-10 overflow-y-auto bg-white flex flex-col">
          {/* TAB 1: PRICING (EXACT REPLICA OF SCREENSHOT) */}
          {activeTab === 'pricing' && (
            <div className="space-y-8 max-w-4xl mx-auto w-full">
              {/* Top Monthly / Annual switch */}
              <div className="flex justify-center">
                <div className="bg-slate-100 p-1 rounded-full border border-slate-200/80 inline-flex items-center text-xs font-semibold">
                  <button
                    onClick={() => setBillingCycle('monthly')}
                    className={`px-5 py-1.5 rounded-full transition-all ${
                      billingCycle === 'monthly'
                        ? 'bg-white text-slate-950 shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Monthly
                  </button>
                  <button
                    onClick={() => setBillingCycle('annual')}
                    className={`px-5 py-1.5 rounded-full transition-all ${
                      billingCycle === 'annual'
                        ? 'bg-white text-slate-950 shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Annual
                  </button>
                </div>
              </div>

              {/* 3 Pricing Cards matching the screenshot */}
              <div className="grid md:grid-cols-3 gap-6 items-stretch">
                {/* CARD 1: Lite 6k */}
                <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-7 shadow-xs flex flex-col justify-between hover:border-slate-300 transition relative">
                  <div className="space-y-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-950">Lite 6k</h3>
                      <p className="text-xs text-slate-500 mt-1">For more projects and usage</p>
                    </div>

                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-black text-slate-950">
                        {billingCycle === 'annual' ? '$14' : '$17'}
                      </span>
                      <div className="flex flex-col">
                        <span className="inline-block bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-bold px-1.5 py-0.5 rounded-md self-start">
                          Save $36
                        </span>
                        <span className="text-xs text-slate-500 mt-0.5">/ month</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleUpgrade('Lite 6k', 6000)}
                      className="w-full py-2.5 bg-[#5e55e3] hover:bg-[#4d44cf] text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition"
                    >
                      Upgrade
                    </button>

                    <div className="pt-2 space-y-2.5">
                      <div className="text-xs font-semibold text-slate-800">
                        Everything in Free, plus:
                      </div>
                      <ul className="space-y-2 text-xs text-slate-600">
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Up to 6,000 credits / month</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Advanced AI coding models</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Private projects</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Remove platform badge</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Custom domains</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>APK download</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Fast track generation</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span className="flex items-center gap-1">
                            Credit rollovers <Info size={12} className="text-slate-400" />
                          </span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* CARD 2: Plus 12k (POPULAR) */}
                <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-7 shadow-xs flex flex-col justify-between hover:border-slate-300 transition relative">
                  {/* Pink Popular badge */}
                  <span className="absolute -top-3 right-5 bg-[#ff3b69] text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full shadow-xs uppercase tracking-wider">
                    Popular
                  </span>

                  <div className="space-y-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-950">Plus 12k</h3>
                      <p className="text-xs text-slate-500 mt-1">For more projects and usage</p>
                    </div>

                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-black text-slate-950">
                        {billingCycle === 'annual' ? '$26' : '$31'}
                      </span>
                      <div className="flex flex-col">
                        <span className="inline-block bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-bold px-1.5 py-0.5 rounded-md self-start">
                          Save $60
                        </span>
                        <span className="text-xs text-slate-500 mt-0.5">/ month</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleUpgrade('Plus 12k', 12000)}
                      className="w-full py-2.5 bg-[#5e55e3] hover:bg-[#4d44cf] text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition"
                    >
                      Upgrade
                    </button>

                    <div className="pt-2 space-y-2.5">
                      <div className="text-xs font-semibold text-slate-800">
                        Everything in Free, plus:
                      </div>
                      <ul className="space-y-2 text-xs text-slate-600">
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Up to 12,000 credits / month</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Advanced AI coding models</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Private projects</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Remove platform badge</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Custom domains</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>APK download</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Fast track generation</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span className="flex items-center gap-1">
                            Credit rollovers <Info size={12} className="text-slate-400" />
                          </span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* CARD 3: Max 24k (WITH DROPDOWN) */}
                <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-7 shadow-xs flex flex-col justify-between hover:border-slate-300 transition relative">
                  <div className="space-y-5">
                    <div>
                      <h3 className="text-xl font-bold text-slate-950">Max 24k</h3>
                      <p className="text-xs text-slate-500 mt-1">For more projects and usage</p>
                    </div>

                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-black text-slate-950">
                        {maxCreditsTier === 24000
                          ? billingCycle === 'annual' ? '$50' : '$61'
                          : maxCreditsTier === 48000
                          ? billingCycle === 'annual' ? '$98' : '$119'
                          : billingCycle === 'annual' ? '$189' : '$229'}
                      </span>
                      <div className="flex flex-col">
                        <span className="inline-block bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-bold px-1.5 py-0.5 rounded-md self-start">
                          {maxCreditsTier === 24000 ? 'Save $132' : 'Save $240'}
                        </span>
                        <span className="text-xs text-slate-500 mt-0.5">/ month</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleUpgrade(`Max ${maxCreditsTier / 1000}k`, maxCreditsTier)}
                      className="w-full py-2.5 bg-[#5e55e3] hover:bg-[#4d44cf] text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition"
                    >
                      Upgrade
                    </button>

                    {/* Tier selector dropdown matching screenshot */}
                    <div className="relative">
                      <select
                        value={maxCreditsTier}
                        onChange={(e) => setMaxCreditsTier(Number(e.target.value))}
                        className="w-full appearance-none bg-white border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-800 pr-8 outline-hidden focus:border-indigo-500 cursor-pointer shadow-2xs"
                      >
                        <option value={24000}>24000 credits/month</option>
                        <option value={48000}>48000 credits/month</option>
                        <option value={96000}>96000 credits/month</option>
                      </select>
                      <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
                    </div>

                    <div className="pt-1 space-y-2.5">
                      <div className="text-xs font-semibold text-slate-800">
                        Everything in Free, plus:
                      </div>
                      <ul className="space-y-2 text-xs text-slate-600">
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Up to {maxCreditsTier.toLocaleString()} credits / month</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Advanced AI coding models</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Private projects</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Remove platform badge</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Custom domains</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>APK download</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span>Fast track generation</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check size={14} className="text-slate-500 shrink-0" />
                          <span className="flex items-center gap-1">
                            Credit rollovers <Info size={12} className="text-slate-400" />
                          </span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MEMBERSHIP */}
          {activeTab === 'membership' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Membership & Usage</h2>
                <p className="text-xs sm:text-sm text-slate-500">Manage your active tier, billing interval, and monthly credit allocations.</p>
              </div>

              {/* Active Plan Overview */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">Active Plan</span>
                    <h3 className="text-lg font-bold text-slate-900 mt-1">Lite 6k Developer</h3>
                    <p className="text-xs text-slate-500">Renews on October 3, 2026 • Monthly billing</p>
                  </div>
                  <button
                    onClick={() => setActiveTab('pricing')}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition"
                  >
                    Change Plan
                  </button>
                </div>

                {/* Credit usage meter */}
                <div className="space-y-2 pt-2">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-slate-700">Monthly Credits Used</span>
                    <span className="text-indigo-600 font-bold">1,180 / 6,000 (80% remaining)</span>
                  </div>
                  <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-linear-to-r from-indigo-500 to-emerald-500 rounded-full w-[20%]" />
                  </div>
                  <p className="text-[11px] text-slate-400">Unused credits rollover into your next cycle automatically.</p>
                </div>
              </div>

              {/* Past Invoices */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Billing History & Invoices</h4>
                <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden text-xs">
                  <div className="p-3.5 flex items-center justify-between bg-white">
                    <div>
                      <div className="font-bold text-slate-900">Invoice #SJ-2026-0814</div>
                      <div className="text-[11px] text-slate-400">August 3, 2026 • Lite 6k Tier</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-slate-900">$17.00 USD</span>
                      <button
                        onClick={() => triggerToast('Downloaded receipt PDF')}
                        className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600"
                        title="Download Receipt"
                      >
                        <Download size={14} />
                      </button>
                    </div>
                  </div>

                  <div className="p-3.5 flex items-center justify-between bg-white">
                    <div>
                      <div className="font-bold text-slate-900">Invoice #SJ-2026-0711</div>
                      <div className="text-[11px] text-slate-400">July 3, 2026 • Lite 6k Tier</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-slate-900">$17.00 USD</span>
                      <button
                        onClick={() => triggerToast('Downloaded receipt PDF')}
                        className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600"
                        title="Download Receipt"
                      >
                        <Download size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PAYMENTS */}
          {activeTab === 'payments' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Payment Methods</h2>
                <p className="text-xs sm:text-sm text-slate-500">Manage saved credit cards, billing addresses, and invoices.</p>
              </div>

              {/* Saved Cards */}
              <div className="space-y-3">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-7 bg-slate-900 text-white rounded-md flex items-center justify-center font-black text-xs">
                      VISA
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 flex items-center gap-2">
                        <span>Visa ending in 4242</span>
                        <span className="bg-slate-200 text-slate-700 text-[10px] font-bold px-1.5 py-0.5 rounded">Default</span>
                      </div>
                      <div className="text-[11px] text-slate-500">Expires 09/28 • Cardholder: Simeon Jr</div>
                    </div>
                  </div>

                  <button
                    onClick={() => triggerToast('Payment method is already default')}
                    className="text-xs font-semibold text-slate-500 hover:text-slate-800"
                  >
                    Edit
                  </button>
                </div>

                <button
                  onClick={() => triggerToast('Card setup modal ready')}
                  className="w-full py-2.5 border-2 border-dashed border-slate-200 hover:border-indigo-400 rounded-2xl text-xs font-bold text-slate-600 hover:text-indigo-600 transition flex items-center justify-center gap-2"
                >
                  <Plus size={14} />
                  <span>Add New Payment Method</span>
                </button>
              </div>

              {/* Billing Info Form */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Tax & Billing Address</h4>
                <div className="grid sm:grid-cols-2 gap-3 text-xs">
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700">Company Name</label>
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700">VAT / Tax ID</label>
                    <input
                      type="text"
                      defaultValue="US-942819481"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: AI TOKEN */}
          {activeTab === 'token' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">AI Tokens & Credits</h2>
                <p className="text-xs sm:text-sm text-slate-500">Monitor token consumption across synthesis, multi-agent consensus, and APK packaging.</p>
              </div>

              {/* Token Stats */}
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Available Credits</div>
                  <div className="text-2xl font-black text-slate-900 mt-1">4,820</div>
                  <div className="text-[11px] text-emerald-600 font-semibold mt-0.5">+1,200 rollover</div>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Synthesized Lines</div>
                  <div className="text-2xl font-black text-slate-900 mt-1">184,200</div>
                  <div className="text-[11px] text-indigo-600 font-semibold mt-0.5">Strict TypeScript</div>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Pass Rate</div>
                  <div className="text-2xl font-black text-slate-900 mt-1">99.8%</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Zero compiler warnings</div>
                </div>
              </div>

              {/* Instant Credit Boosters */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Top-Up Credit Boosters</h4>
                <div className="grid sm:grid-cols-2 gap-3">
                  <div className="border border-slate-200 rounded-2xl p-4 flex items-center justify-between hover:border-indigo-400 transition">
                    <div>
                      <div className="font-bold text-xs text-slate-900">+2,500 Credits Pack</div>
                      <div className="text-[11px] text-slate-500">$7 one-time purchase</div>
                    </div>
                    <button
                      onClick={() => triggerToast('Added 2,500 credits to balance!')}
                      className="px-3 py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg text-xs font-bold transition"
                    >
                      Buy Pack
                    </button>
                  </div>

                  <div className="border border-slate-200 rounded-2xl p-4 flex items-center justify-between hover:border-indigo-400 transition">
                    <div>
                      <div className="font-bold text-xs text-slate-900">+10,000 Credits Pack</div>
                      <div className="text-[11px] text-slate-500">$25 one-time purchase (Save $3)</div>
                    </div>
                    <button
                      onClick={() => triggerToast('Added 10,000 credits to balance!')}
                      className="px-3 py-1.5 bg-indigo-600 text-white hover:bg-indigo-500 rounded-lg text-xs font-bold transition"
                    >
                      Buy Pack
                    </button>
                  </div>
                </div>
              </div>

              {/* Auto Reload Toggle */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-900">Auto-Reload Credits</div>
                  <div className="text-[11px] text-slate-500">Automatically purchase 2,500 credits when balance drops below 500</div>
                </div>
                <button
                  onClick={() => {
                    setAutoReload(!autoReload);
                    triggerToast(autoReload ? 'Auto-reload disabled' : 'Auto-reload enabled');
                  }}
                  className={`w-11 h-6 rounded-full transition-colors relative ${autoReload ? 'bg-indigo-600' : 'bg-slate-300'}`}
                >
                  <span className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${autoReload ? 'left-6' : 'left-1'}`} />
                </button>
              </div>
            </div>
          )}

          {/* TAB 5: PROFILE */}
          {activeTab === 'profile' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Account Profile</h2>
                <p className="text-xs sm:text-sm text-slate-500">Manage creator identity, organization settings, and developer API keys.</p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-linear-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center font-black text-xl shadow-md">
                    SJ
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-base">{displayName}</h3>
                    <p className="text-xs text-slate-500">{userEmail}</p>
                    <span className="inline-block mt-1 bg-indigo-50 border border-indigo-200 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                      Founder & CEO
                    </span>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4 text-xs pt-2">
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700">Display Name</label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700">Organization Name</label>
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>
              </div>

              {/* Developer API Keys */}
              <div className="space-y-3 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Developer API Keys</h4>
                    <p className="text-[11px] text-slate-400">Use secret keys to call the Appmazon synthesis CLI and serverless endpoints.</p>
                  </div>
                  <button
                    onClick={() => {
                      const newKey = {
                        id: `key_${Date.now()}`,
                        name: 'CLI Deployment Token',
                        prefix: `sk_appmazon_live_${Math.random().toString(36).substring(2, 6)}••••••••`,
                        created: 'Just now',
                      };
                      setApiKeys([...apiKeys, newKey]);
                      triggerToast('Generated new secret API key');
                    }}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                  >
                    <Plus size={13} />
                    <span>Generate Key</span>
                  </button>
                </div>

                <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden text-xs">
                  {apiKeys.map((k) => (
                    <div key={k.id} className="p-3.5 flex items-center justify-between bg-white">
                      <div className="flex items-center gap-2.5">
                        <Key size={15} className="text-indigo-600 shrink-0" />
                        <div>
                          <div className="font-bold text-slate-900">{k.name}</div>
                          <div className="font-mono text-[11px] text-slate-500">{k.prefix}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => triggerToast('Copied secret token to clipboard')}
                          className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition"
                        >
                          Copy
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: INTEGRATIONS */}
          {activeTab === 'integrations' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Ecosystem Integrations</h2>
                <p className="text-xs sm:text-sm text-slate-500">Connect cloud container runtimes, databases, and deployment webhooks.</p>
              </div>

              <div className="space-y-3">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                      GCR
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900">Google Cloud Run & Artifact Registry</div>
                      <div className="text-[11px] text-slate-500">Automated multi-arch container deployment on port 3000</div>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    Connected
                  </span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                      FB
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900">Firebase & Firestore Auth</div>
                      <div className="text-[11px] text-slate-500">Real-time user authorization and document store</div>
                    </div>
                  </div>
                  <button
                    onClick={() => triggerToast('Firebase sync connected')}
                    className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg text-xs font-semibold text-slate-700 transition"
                  >
                    Configure
                  </button>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                      SUPA
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-900">Supabase / PostgreSQL</div>
                      <div className="text-[11px] text-slate-500">Relational data synchronization with RLS security policies</div>
                    </div>
                  </div>
                  <button
                    onClick={() => triggerToast('Supabase linked')}
                    className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg text-xs font-semibold text-slate-700 transition"
                  >
                    Configure
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: GITHUB */}
          {activeTab === 'github' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">GitHub Synchronization</h2>
                <p className="text-xs sm:text-sm text-slate-500">Push generated code repositories directly to GitHub with automated CI/CD.</p>
              </div>

              <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Github size={24} className="text-indigo-400" />
                    <div>
                      <div className="font-bold text-sm text-white">@simeonjr-studios</div>
                      <div className="text-xs text-slate-400">Connected to GitHub Organization</div>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-950 border border-emerald-700 text-emerald-300 text-[10px] font-bold">
                    ACTIVE SYNC
                  </span>
                </div>

                <div className="pt-2 grid sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase font-bold">Target Repository</span>
                    <div className="font-mono text-indigo-300 font-bold mt-0.5">simeonjr/appmazon-production</div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase font-bold">Default Branch</span>
                    <div className="font-mono text-emerald-400 font-bold mt-0.5">main (auto-deploy)</div>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between text-xs text-slate-300 border-t border-slate-800/80">
                  <span>Auto-commit on verified compile:</span>
                  <span className="font-bold text-emerald-400">ENABLED</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
