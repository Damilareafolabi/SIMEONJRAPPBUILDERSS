import React, { useState } from 'react';
import { 
  Search, Target, TrendingUp, Sparkles, ArrowRight, 
  CheckCircle, Globe, ShieldCheck, X, Zap, Building2, 
  DollarSign, BarChart2
} from 'lucide-react';
import { ScoutOpportunity } from '../../types/promptBuilder';

interface ScoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectOpportunityForBuild: (prompt: string, category: string) => void;
}

const SCOUT_OPPORTUNITIES: ScoutOpportunity[] = [
  {
    id: 'scout-1',
    title: 'Autonomous Multi-Cloud FinOps Cloud Cost Auditor',
    category: 'B2B SaaS',
    marketNeed: 'Startups burning $10K-$80K/mo on AWS/GCP without real-time idle resource shutdown or egress waste tracking.',
    competitorGap: 'Existing tools (CloudZero, Datadog) are enterprise-priced at $25k/yr and require lengthy sales calls.',
    recommendedApp: 'Lightweight local CLI + web dashboard that parses billing CSVs and suggests instant 30% savings actions.',
    targetAudience: 'Early-stage CTOs, DevOps leads, bootstrapping SaaS founders.',
    estimatedTam: '$4.2B Global Cloud Cost Management',
  },
  {
    id: 'scout-2',
    title: 'HIPAA-Compliant Remote Pediatric Speech Therapy Portal',
    category: 'Healthcare Tech',
    marketNeed: 'Pediatric speech clinics have 6-month waitlists and lack interactive gamified video exercise platforms for children.',
    competitorGap: 'Generic Zoom/Teams lack speech-recognition interactive scoring and parental progress dashboards.',
    recommendedApp: 'Browser-based video consultation app with interactive sound games, parent milestone tracking, and insurance invoicing.',
    targetAudience: 'Private speech pathology clinics, pediatric therapists, parents.',
    estimatedTam: '$6.8B Telehealth Speech Market',
  },
  {
    id: 'scout-3',
    title: 'Local Craft Brewery & Micro-Distillery Inventory ERP',
    category: 'Vertical SaaS',
    marketNeed: 'Craft beverage makers track fermentation batches and excise tax keg deposits on sticky notes and Excel spreadsheets.',
    competitorGap: 'SAP and NetSuite are too complex and expensive; generic POS systems do not calculate tank volume or TTB excise tax formulas.',
    recommendedApp: 'Offline-first tablet app for cellar tanks, keg tracking via QR codes, and automated tax reporting.',
    targetAudience: 'Independent brewers, craft cideries, distillers.',
    estimatedTam: '$1.4B Craft Beverage Software',
  },
  {
    id: 'scout-4',
    title: 'AI Architectural Drawing Compliance & Code Reviewer',
    category: 'PropTech / AEC',
    marketNeed: 'Architects spend 40 hours per permit checking city zoning bylaws, egress widths, and parking ratios.',
    competitorGap: 'Manual plan checkers take 6-12 weeks; current BIM tools do not auto-verify municipal zoning ordinances.',
    recommendedApp: 'CAD/PDF vector plan parser that flags zoning infractions, fire code discrepancies, and accessibility violations.',
    targetAudience: 'Architecture firms, structural engineers, municipal permitting offices.',
    estimatedTam: '$3.1B AEC Regulatory Automation',
  },
  {
    id: 'scout-5',
    title: 'Cross-Border Contractor Payroll with Local Stablecoin Off-Ramp',
    category: 'Fintech',
    marketNeed: 'Remote teams in LATAM and Southeast Asia lose 6-10% to SWIFT wire fees and 4-day bank delays.',
    competitorGap: 'Deel and Remote charge high employer-of-record markups and enforce rigid localized banking rails.',
    recommendedApp: 'Unified contractor payment portal supporting instant USDC payouts and local fiat bank deposits.',
    targetAudience: 'Global tech companies hiring remote engineers worldwide.',
    estimatedTam: '$8.5B Cross-Border Payroll',
  },
];

export function ScoutModal({
  isOpen,
  onClose,
  onSelectOpportunityForBuild,
}: ScoutModalProps) {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const categories = ['All', 'B2B SaaS', 'Healthcare Tech', 'Vertical SaaS', 'PropTech / AEC', 'Fintech'];

  const filteredOpportunities = SCOUT_OPPORTUNITIES.filter((opp) => {
    const matchesCategory = activeCategory === 'All' || opp.category === activeCategory;
    const matchesSearch =
      opp.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      opp.marketNeed.toLowerCase().includes(searchQuery.toLowerCase()) ||
      opp.competitorGap.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                APPMORA Scout Agent
              </span>
              <span className="text-xs text-slate-400 font-mono">Autonomous Market Intelligence</span>
            </div>
            <h2 className="text-2xl font-black text-slate-950 tracking-tight flex items-center gap-2">
              <Search className="text-indigo-600 w-6 h-6" />
              <span>Scout — Business & Opportunity Discovery</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Discover real underserved software markets, analyze competitor gaps, and build solutions where actual paying demand exists.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                  activeCategory === cat
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search markets or gaps..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:outline-indigo-600 bg-slate-50/50"
            />
          </div>
        </div>

        {/* Opportunity Cards List */}
        <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1 text-left">
          {filteredOpportunities.map((opp) => (
            <div
              key={opp.id}
              className="p-5 rounded-2xl bg-white border border-slate-200/90 hover:border-indigo-300 transition shadow-2xs space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                <div>
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 mr-2">
                    {opp.category}
                  </span>
                  <span className="font-bold text-sm text-slate-900">{opp.title}</span>
                </div>
                <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 shrink-0">
                  <BarChart2 size={12} />
                  <span>TAM: {opp.estimatedTam}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="space-y-1">
                  <div className="font-semibold text-slate-800 flex items-center gap-1">
                    <Target size={13} className="text-amber-500" />
                    <span>Real Market Pain</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">{opp.marketNeed}</p>
                </div>

                <div className="space-y-1">
                  <div className="font-semibold text-slate-800 flex items-center gap-1">
                    <Zap size={13} className="text-indigo-500" />
                    <span>Competitor Blindspot / Gap</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">{opp.competitorGap}</p>
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-0.5">
                  <div className="text-[11px] font-bold text-indigo-900">Recommended Software Blueprint:</div>
                  <div className="text-slate-700 leading-snug">{opp.recommendedApp}</div>
                </div>

                <button
                  onClick={() => {
                    onSelectOpportunityForBuild(
                      `Build ${opp.title}: ${opp.recommendedApp}. Target audience: ${opp.targetAudience}.`,
                      opp.category
                    );
                    onClose();
                  }}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 shadow-xs transition active:scale-95"
                >
                  <span>Build with APPMORA</span>
                  <ArrowRight size={13} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
