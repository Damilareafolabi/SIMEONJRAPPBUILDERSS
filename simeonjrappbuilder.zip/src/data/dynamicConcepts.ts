export interface DynamicConcept {
  id: string;
  name: string;
  tagline: string;
  description: string;
  badge: string;
  primaryColor: string;
  gradient: string;
  glowClass: string;
  accentBorder: string;
  heroImage: string;
  stats: { label: string; value: string }[];
}

export const DYNAMIC_CONCEPTS: DynamicConcept[] = [
  {
    id: 'titanium',
    name: 'Titanium Sovereign',
    tagline: 'Universal Multi-Platform Foundry',
    description: 'Cross-platform synthesis generating verified TypeScript, native Android APK manifests, and Tauri desktop binaries in a single compile pass.',
    badge: 'Universal Architecture',
    primaryColor: '#6366f1',
    gradient: 'from-indigo-600 via-indigo-700 to-violet-800',
    glowClass: 'from-indigo-500/15 via-violet-500/10 to-transparent',
    accentBorder: 'border-indigo-500/30',
    heroImage: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=900&auto=format&fit=crop&q=80',
    stats: [
      { label: 'Compile Speed', value: '380ms AST' },
      { label: 'Platforms', value: 'Web + APK + Desktop' },
      { label: 'Source Sovereignty', value: '100% Owned' },
    ],
  },
  {
    id: 'aurora',
    name: 'Aurora Neural Matrix',
    tagline: 'Autonomous 5-Agent Consensus',
    description: 'Specialized autonomous dev agents orchestrating schema design, reactive UI synthesis, AST self-healing, and security auditing before deployment.',
    badge: 'Multi-Agent AI',
    primaryColor: '#8b5cf6',
    gradient: 'from-purple-600 via-violet-600 to-pink-600',
    glowClass: 'from-purple-500/15 via-pink-500/10 to-transparent',
    accentBorder: 'border-purple-500/30',
    heroImage: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=900&auto=format&fit=crop&q=80',
    stats: [
      { label: 'Consensus Rate', value: '99.9% Pass' },
      { label: 'Active Agents', value: '5 Autonomous' },
      { label: 'Self-Healing', value: 'Instant Lint' },
    ],
  },
  {
    id: 'emerald',
    name: 'Emerald Quantum Foundry',
    tagline: 'High-Frequency Realtime Systems',
    description: 'Engineered for financial tickers, live streaming telemetry, WebSocket aggregation, and low-latency interactive applications with zero lag.',
    badge: 'Realtime & FinTech',
    primaryColor: '#10b981',
    gradient: 'from-emerald-600 via-teal-600 to-cyan-700',
    glowClass: 'from-emerald-500/15 via-teal-500/10 to-transparent',
    accentBorder: 'border-emerald-500/30',
    heroImage: 'https://images.unsplash.com/photo-1642543492481-44e81e3914a7?w=900&auto=format&fit=crop&q=80',
    stats: [
      { label: 'WebSocket Latency', value: '< 18ms' },
      { label: 'Order Execution', value: 'Sub-second' },
      { label: 'Memory Footprint', value: '24MB Lean' },
    ],
  },
  {
    id: 'solar',
    name: 'Solar Precision Studio',
    tagline: 'Human-Centric Craft & Visual Canvas',
    description: 'Mathematical spacing, optical border-radius calculations, high-contrast accessible typography, and drag-and-drop design system synchronization.',
    badge: 'Design System & UX',
    primaryColor: '#f59e0b',
    gradient: 'from-amber-600 via-orange-600 to-rose-700',
    glowClass: 'from-amber-500/15 via-orange-500/10 to-transparent',
    accentBorder: 'border-amber-500/30',
    heroImage: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=900&auto=format&fit=crop&q=80',
    stats: [
      { label: 'Accessibility', value: 'WCAG AA Compliant' },
      { label: 'Radius Math', value: 'Inner = Outer - Pad' },
      { label: 'Visual Canvas', value: 'Drag & Drop' },
    ],
  },
];
