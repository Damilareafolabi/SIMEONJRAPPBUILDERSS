import { AppProject } from './types';

export const STARTER_TEMPLATES: Record<string, AppProject> = {
  ecommerce: {
    id: 'ecommerce-store',
    name: 'Simeon Jr Storefront',
    description: 'Modern mobile commerce shop with product discovery and cart preview',
    primaryColor: '#4f46e5',
    activeScreenId: 'home',
    updatedAt: Date.now(),
    screens: [
      {
        id: 'home',
        name: 'Home Store',
        bgColor: '#f8fafc',
        elements: [
          {
            id: 'hdr-1',
            type: 'header',
            name: 'Store Header',
            props: {
              title: 'Simeon Jr Store',
              subtitle: 'Discover Premium Lifestyle Products',
              align: 'left',
              colorScheme: 'indigo',
              variant: 'solid',
            },
          },
          {
            id: 'srch-1',
            type: 'search',
            name: 'Search Bar',
            props: {
              placeholder: 'Search sneakers, gadgets, apparel...',
              padding: 'sm',
              borderRadius: 'lg',
            },
          },
          {
            id: 'tabs-1',
            type: 'tabs',
            name: 'Category Tabs',
            props: {
              tabs: ['Trending', 'Apparel', 'Tech Gear', 'Home'],
              activeTabIndex: 0,
              colorScheme: 'indigo',
            },
          },
          {
            id: 'hero-1',
            type: 'hero',
            name: 'Summer Flash Sale',
            props: {
              title: 'Summer Collection 50% Off',
              subtitle: 'Handpicked handcrafted items ready for fast delivery.',
              buttonText: 'Shop New Arrivals',
              colorScheme: 'indigo',
              actionType: 'toast',
              actionMessage: 'Opening New Arrivals collection!',
              borderRadius: 'xl',
            },
          },
          {
            id: 'stats-1',
            type: 'stats',
            name: 'Store Highlights',
            props: {
              items: [
                { id: '1', title: 'Top Rated', value: '4.9 ★' },
                { id: '2', title: 'Free Delivery', value: 'Over $50' },
                { id: '3', title: 'Orders Today', value: '1.2k+' },
              ],
              colorScheme: 'indigo',
            },
          },
          {
            id: 'card-1',
            type: 'card',
            name: 'Featured Sneakers',
            props: {
              title: 'AeroGlide Pro Runners',
              subtitle: 'Ultra-cushioned carbon plate performance shoes.',
              buttonText: 'View Details',
              imageUrl: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80',
              actionType: 'navigate',
              targetScreenId: 'details',
              borderRadius: 'xl',
              shadow: 'md',
              colorScheme: 'indigo',
            },
          },
          {
            id: 'btn-1',
            type: 'button',
            name: 'Checkout Button',
            props: {
              buttonText: 'Go to Cart & Checkout ($149.00)',
              colorScheme: 'indigo',
              variant: 'solid',
              actionType: 'navigate',
              targetScreenId: 'details',
              borderRadius: 'lg',
              padding: 'md',
            },
          },
        ],
      },
      {
        id: 'details',
        name: 'Product Details',
        bgColor: '#ffffff',
        elements: [
          {
            id: 'dtl-hdr',
            type: 'header',
            name: 'Details Header',
            props: {
              title: 'AeroGlide Pro Sneakers',
              subtitle: 'Series X edition in Flame Crimson',
              align: 'left',
              colorScheme: 'indigo',
            },
          },
          {
            id: 'dtl-img',
            type: 'image',
            name: 'Product Image',
            props: {
              imageUrl: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80',
              borderRadius: 'xl',
            },
          },
          {
            id: 'dtl-banner',
            type: 'banner',
            name: 'Stock Status',
            props: {
              title: 'Limited Stock: Only 4 pairs remaining!',
              colorScheme: 'amber',
              variant: 'outline',
            },
          },
          {
            id: 'dtl-list',
            type: 'list',
            name: 'Product Specs',
            props: {
              items: [
                { id: '1', title: 'Sole Tech', subtitle: 'Dual Density Zoom Foam', value: 'Aerodynamic' },
                { id: '2', title: 'Weight', subtitle: 'Lightweight sprint mesh', value: '210 grams' },
                { id: '3', title: 'Warranty', subtitle: '1 year worldwide replacement', value: 'Included' },
              ],
            },
          },
          {
            id: 'dtl-btn-cart',
            type: 'button',
            name: 'Add To Cart Button',
            props: {
              buttonText: 'Add to Cart • $149.00',
              colorScheme: 'emerald',
              variant: 'solid',
              actionType: 'toast',
              actionMessage: 'Added AeroGlide Pro to your shopping cart!',
              borderRadius: 'lg',
            },
          },
          {
            id: 'dtl-btn-back',
            type: 'button',
            name: 'Back to Shop',
            props: {
              buttonText: '← Back to Storefront',
              variant: 'outline',
              actionType: 'navigate',
              targetScreenId: 'home',
              borderRadius: 'lg',
            },
          },
        ],
      },
    ],
  },
  productivity: {
    id: 'productivity-app',
    name: 'Task Flow Workspace',
    description: 'Daily planner and team sprint tracker',
    primaryColor: '#059669',
    activeScreenId: 'tasks',
    updatedAt: Date.now(),
    screens: [
      {
        id: 'tasks',
        name: 'Tasks Board',
        bgColor: '#f0fdf4',
        elements: [
          {
            id: 'p-hdr',
            type: 'header',
            name: 'App Header',
            props: {
              title: 'TaskFlow Planner',
              subtitle: 'Track your daily milestones & priorities',
              colorScheme: 'emerald',
            },
          },
          {
            id: 'p-stats',
            type: 'stats',
            name: 'Today Overview',
            props: {
              items: [
                { id: '1', title: 'Pending', value: '5 tasks' },
                { id: '2', title: 'Done', value: '12 done' },
                { id: '3', title: 'Streak', value: '14 Days' },
              ],
              colorScheme: 'emerald',
            },
          },
          {
            id: 'p-input',
            type: 'input',
            name: 'Quick Add Field',
            props: {
              label: 'New Task',
              placeholder: 'Type a new high priority item...',
              borderRadius: 'lg',
            },
          },
          {
            id: 'p-btn',
            type: 'button',
            name: 'Add Task Button',
            props: {
              buttonText: '+ Create New Task',
              colorScheme: 'emerald',
              variant: 'solid',
              actionType: 'toast',
              actionMessage: 'New task created successfully!',
              borderRadius: 'lg',
            },
          },
          {
            id: 'p-list',
            type: 'list',
            name: 'Active Tasks List',
            props: {
              items: [
                { id: '1', title: 'Finalize UI Component system', subtitle: 'Design sprint 4', badge: 'High' },
                { id: '2', title: 'Review pull request from dev', subtitle: 'SIMEONJRAPPBUILDER migration', badge: 'Urgent' },
                { id: '3', title: 'Publish production release build', subtitle: 'Deployment to Cloud Run', badge: 'Medium' },
              ],
            },
          },
        ],
      },
    ],
  },
  blank: {
    id: 'blank-app',
    name: 'Untitled App',
    description: 'Clean project ready for custom visual composition',
    primaryColor: '#6366f1',
    activeScreenId: 'home',
    updatedAt: Date.now(),
    screens: [
      {
        id: 'home',
        name: 'Main Screen',
        bgColor: '#ffffff',
        elements: [
          {
            id: 'b-hdr',
            type: 'header',
            name: 'Welcome Header',
            props: {
              title: 'Welcome to Your App',
              subtitle: 'Built with Simeon Jr App Builder',
              align: 'center',
              colorScheme: 'indigo',
            },
          },
          {
            id: 'b-hero',
            type: 'hero',
            name: 'Callout Hero',
            props: {
              title: 'Start Composing Your App',
              subtitle: 'Select components from the left catalog and customize styling on the right inspector.',
              buttonText: 'Get Started',
              actionType: 'toast',
              actionMessage: 'Ready to build!',
              colorScheme: 'indigo',
              borderRadius: 'xl',
            },
          },
        ],
      },
    ],
  },
};
