export type ElementType =
  | 'header'
  | 'hero'
  | 'card'
  | 'button'
  | 'input'
  | 'search'
  | 'stats'
  | 'list'
  | 'badge'
  | 'image'
  | 'divider'
  | 'tabs'
  | 'toggle'
  | 'banner';

export interface ListItem {
  id: string;
  title: string;
  subtitle?: string;
  badge?: string;
  value?: string;
  icon?: string;
}

export interface ElementProps {
  title?: string;
  subtitle?: string;
  content?: string;
  label?: string;
  placeholder?: string;
  buttonText?: string;
  imageUrl?: string;
  iconName?: string;
  
  // Styling
  bgColor?: string; // hex or tailwind token
  textColor?: 'dark' | 'light' | 'muted' | 'indigo' | 'emerald' | 'rose' | 'amber';
  align?: 'left' | 'center' | 'right';
  fontSize?: 'sm' | 'base' | 'lg' | 'xl' | '2xl';
  borderRadius?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
  padding?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  shadow?: 'none' | 'sm' | 'md' | 'lg';
  variant?: 'solid' | 'outline' | 'ghost' | 'glass';
  colorScheme?: 'indigo' | 'emerald' | 'rose' | 'amber' | 'sky' | 'neutral' | 'purple';

  // Interaction
  actionType?: 'none' | 'navigate' | 'toast' | 'alert' | 'openUrl';
  targetScreenId?: string;
  actionMessage?: string;
  actionUrl?: string;

  // Multi-item configs
  items?: ListItem[];
  tabs?: string[];
  activeTabIndex?: number;
  checked?: boolean;
}

export interface AppElement {
  id: string;
  type: ElementType;
  name: string;
  props: ElementProps;
}

export interface AppScreen {
  id: string;
  name: string;
  elements: AppElement[];
  bgColor?: string;
}

export interface AppProject {
  id: string;
  name: string;
  description: string;
  primaryColor: string;
  screens: AppScreen[];
  activeScreenId: string;
  updatedAt: number;
}

export type DeviceType = 'mobile' | 'tablet' | 'desktop';

export interface DeviceConfig {
  id: DeviceType;
  name: string;
  width: number;
  height: number;
  frameClass: string;
}
