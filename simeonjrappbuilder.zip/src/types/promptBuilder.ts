export type AppCategory =
  | 'Web App'
  | 'Mobile App'
  | 'Desktop App'
  | 'APK / Android App'
  | 'AI Chat App'
  | 'Trading Platform'
  | 'SaaS Dashboard'
  | 'Multi-App Suite'
  | 'Social Platform'
  | 'E-Commerce'
  | 'Corporate Portal'
  | 'AI Assistant'
  | 'Other';

export type BuildMode = 'prototype' | 'production';

export type BuildType =
  | 'Web'
  | 'Mobile'
  | 'Android APK'
  | 'Desktop'
  | 'AI App'
  | 'SaaS'
  | 'Multi-App'
  | 'Other';

export type BuildAction =
  | 'build_new'
  | 'transform'
  | 'clone'
  | 'import'
  | 'deploy'
  | 'evolve';

export interface AppFile {
  name: string;
  path: string;
  language: string;
  content: string;
  size?: string;
}

export interface AgentActivityStep {
  id: string;
  title: string;
  detail?: string;
  timestamp: string;
  status: 'pending' | 'active' | 'completed';
}

export type PipelineStepId =
  | 'understand'
  | 'plan'
  | 'architect'
  | 'build'
  | 'install'
  | 'test'
  | 'fix'
  | 'preview'
  | 'security'
  | 'production_build'
  | 'package'
  | 'deploy'
  | 'monitor'
  | 'evolve';

export interface PipelineStep {
  id: PipelineStepId;
  stepNum: string;
  name: string;
  desc: string;
  status: 'idle' | 'running' | 'done';
}

export interface ReadinessCheckItem {
  id: string;
  name: string;
  category: 'Build' | 'Testing' | 'Security' | 'Architecture' | 'Runtime';
  status: 'pass' | 'fail' | 'running';
  details: string;
}

export interface ProductionReadinessReport {
  score: number;
  isReady: boolean;
  buildStatus: 'PASS' | 'FAIL';
  testsStatus: 'PASS' | 'FAIL';
  securityStatus: 'PASS' | 'FAIL';
  productionBuildStatus: 'PASS' | 'FAIL';
  checks: ReadinessCheckItem[];
}

export interface RestorePoint {
  id: string;
  timestamp: string;
  label: string;
  prompt: string;
  filesCount: number;
  readinessScore: number;
}

export interface EvolveRecommendation {
  id: string;
  title: string;
  category: 'Performance' | 'Feature' | 'Dependency' | 'UX' | 'Error Pattern' | 'Accessibility';
  description: string;
  riskLevel: 'LOW RISK' | 'MEDIUM RISK' | 'HIGH RISK';
  applied: boolean;
  timestamp: string;
  impact: string;
  testsPerformed: string;
}

export interface ScoutOpportunity {
  id: string;
  companyOrTarget: string;
  industry: string;
  opportunity: string;
  reason: string;
  potentialSolution: string;
  complianceStatus: 'PASS' | 'FLAGGED';
  recommendedAction: string;
  status: 'new' | 'drafted' | 'approved_sent' | 'ignored';
  draftMessage?: string;
}

export interface DynamicAppIdea {
  id: string;
  title: string;
  prompt: string;
  category: BuildType;
  badge: string;
  type: 'popular' | 'dynamic';
}

export interface GeneratedApp {
  id: string;
  title: string;
  type: string;
  category: AppCategory;
  buildType?: BuildType;
  buildMode: BuildMode;
  prompt: string;
  description: string;
  previewUrl: string;
  files: AppFile[];
  createdAt: number;
  readinessReport?: ProductionReadinessReport;
  restorePoints?: RestorePoint[];
}
